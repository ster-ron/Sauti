# Sauti v2

A **Digital Civic Infrastructure System for Governance Transparency and Participation** — not just an app.

It combines a government reporting system, citizen watchdog network, civic deliberation platform, election integrity monitoring layer, and a USSD/SMS gateway (stub) for low-internet access.

---

## Stack

| Layer | Tech |
|---|---|
| Core DB | PostgreSQL via Prisma |
| Flexible data | MongoDB via Mongoose (Forum, Town Halls) |
| API | Express + JWT |
| Frontend | Next.js (pages router) |
| AI (optional) | Anthropic Claude (Civic Intelligence narrative) |

---

## Setup

### 1. Backend
```bash
cd backend
cp .env.example .env          # fill in DATABASE_URL, MONGO_URL, JWT_SECRET
npm install
npm run prisma:migrate
npm run dev                   # http://localhost:5000
```

MongoDB must be reachable at `MONGO_URL` for forum and town hall routes.  
The server boots without it — only those two engines error until it's available.

### 2. Frontend
```bash
cd frontend
cp .env.local.example .env.local
npm install
npm run dev                   # http://localhost:3000
```

---

## Roles

| Role | What they can do |
|---|---|
| `citizen` | submit reports (optionally anonymous), post/reply in forum, ask questions at town halls |
| `leader` | everything citizens can do + create/update projects, schedule town halls, answer Q&A, see Civic Intelligence |
| `election_stakeholder` | read Civic Intelligence, publish oversight reports, see corruption audit trail |
| `admin` | full access — moderation, audit logs, all engines |

---

## Core Engines (v2)

| Engine | Location | What it does |
|---|---|---|
| **Accountability Core** | `routes/projects.js` | leader-posted projects, budgets, budget-vs-spend tracking, ward/geo fields |
| **Verification Engine** | `services/verificationEngine.js` | keyword analysis of reports → verified/partial/disputed + confidence score; expanded signal dictionary |
| **Corruption Signal Engine** | `services/verificationEngine.js` | scans every report for governance red-flags (ghost projects, fund diversion, inflated costs, election projects, etc.); assigns risk level none→critical; fires `corruption.flagged` audit events |
| **Civic Forum Engine** | `routes/forum.js` + `models/ForumThread.js` | topic threads, replies, admin moderation |
| **Town Hall Engine** | `routes/townhall.js` + `models/TownHall.js` | live sessions, agenda voting, leader Q&A |
| **Civic Intelligence Layer** | `services/intelligenceEngine.js` | stats by region/category/status; corruption aggregation; stalled project detection; budget absorption rate; optional Claude narrative |
| **Leaders Registry** | `routes/leaders.js` | public leader profiles + computed accountability scores; filterable by constituency/ward |
| **Election Oversight** | `routes/oversight.js` | election_stakeholder oversight reports; structured findings; publish/draft workflow |
| **USSD Gateway (stub)** | `routes/ussd.js` | Africa's Talking / Safaricom callback format; report-via-keypad flow; project status lookup; channel = "ussd" stamped on all USSD reports |
| **Audit Trail** | `routes/audit.js` + `services/auditLogger.js` | immutable record; pagination; channel filter; `/audit/corruption` fast-path for election stakeholders |

---

## API Reference

### Auth
| Method | Route | Auth | Notes |
|---|---|---|---|
| POST | `/auth/register` | none | |
| POST | `/auth/login` | none | |

### Projects (Accountability Core)
| Method | Route | Auth | Notes |
|---|---|---|---|
| GET | `/projects` | public | filter: region, status, ward, category, corruptionRiskLevel |
| GET | `/projects/:id` | public | |
| POST | `/projects` | leader/admin | now includes ward, latitude, longitude, startDate, endDate, budgetSpent |
| PATCH | `/projects/:id` | leader(own)/admin | |
| POST | `/projects/:id/recompute-verification` | any auth | runs Verification + Corruption engines |

### Reports (Evidence Layer)
| Method | Route | Auth | Notes |
|---|---|---|---|
| GET | `/reports` | public | filter: projectId, channel |
| POST | `/reports` | any auth | supports videoUrl, latitude/longitude, channel (web/mobile/ussd/sms) |
| POST | `/reports/:id/upvote` | any auth | community verification signal |

### Leaders Registry
| Method | Route | Auth | Notes |
|---|---|---|---|
| GET | `/leaders` | public | filter: constituency, ward |
| GET | `/leaders/:id` | public | full profile + project breakdown |
| PATCH | `/leaders/me` | leader | update own bio, title, ward |

### Forum (Civic Forum Engine)
| Method | Route | Auth | Notes |
|---|---|---|---|
| GET | `/forum/threads` | public | filter: topic, projectId |
| POST | `/forum/threads` | any auth | |
| GET | `/forum/threads/:id` | public | |
| POST | `/forum/threads/:id/replies` | any auth | |
| PATCH | `/forum/threads/:id/moderate` | admin | hide/unhide |

### Town Hall Engine
| Method | Route | Auth | Notes |
|---|---|---|---|
| GET | `/townhall` | public | filter: region, status |
| POST | `/townhall` | leader/admin | |
| PATCH | `/townhall/:id/status` | leader/admin | scheduled → live → completed |
| POST | `/townhall/:id/agenda` | any auth | propose agenda item |
| POST | `/townhall/:id/agenda/:itemId/vote` | any auth | toggle upvote |
| POST | `/townhall/:id/qa` | any auth | |
| PATCH | `/townhall/:id/qa/:qaId/answer` | leader/admin | |

### Civic Intelligence Layer
| Method | Route | Auth | Notes |
|---|---|---|---|
| GET | `/intelligence/summary` | leader/stakeholder/admin | filter: region, ward |
| GET | `/intelligence/corruption-overview` | public | aggregate counts only |

### Election Oversight
| Method | Route | Auth | Notes |
|---|---|---|---|
| GET | `/oversight` | any auth | citizens see published only |
| POST | `/oversight` | stakeholder/admin | |
| PATCH | `/oversight/:id` | stakeholder/admin | |

### Audit Trail
| Method | Route | Auth | Notes |
|---|---|---|---|
| GET | `/audit` | admin | filter: entityType, action, userId, channel; paginated |
| GET | `/audit/corruption` | stakeholder/admin | corruption.flagged events only |

### USSD Gateway
| Method | Route | Auth | Notes |
|---|---|---|---|
| POST | `/ussd` | none (aggregator) | Africa's Talking / Safaricom callback format |

---

## What's new in v2 (vs v1)

| Area | Change |
|---|---|
| **Schema** | Added `ward`, `latitude/longitude`, `startDate/endDate`, `budgetSpent` to Projects; `videoUrl`, `latitude/longitude`, `channel`, `upvotes` to Reports; `title/constituency/ward/bio/phone/accountabilityScore` to Users (Leaders profile); new `OversightReport` model; `channel`/`ipAddress` on AuditLog |
| **Corruption Signal Engine** | New engine in `verificationEngine.js` — 15 red-flag phrases, five risk tiers (none→critical), auto-runs on every `POST /reports`, fires `corruption.flagged` audit events |
| **Verification Engine** | Expanded signal dictionaries (inaugurated, crew missing, ghost project, etc.) |
| **Intelligence Engine** | Added corruption aggregation, stalled-project detection, budget absorption rate, richer LLM prompt |
| **Leaders Registry** | New `/leaders` route + frontend page with computed accountability scores |
| **Oversight** | New `/oversight` route + frontend page for election stakeholders |
| **USSD Gateway** | New `/ussd` stub implementing the full Africa's Talking callback flow |
| **Audit** | Pagination, channel filter, `/audit/corruption` fast-path |
| **Frontend** | Leaders page, Oversight page, USSD teaser in sidebar, Oversight + Leaders in nav, corruption risk badges on leader cards |

---

## What's intentionally simplified vs. the full target architecture

This is a single-service MVP. The USSD route is a functional stub — wire a real aggregator (Africa's Talking `npm i africastalking`) by replacing the inline session logic. PostGIS, S3/Azure Blob for media evidence, a learned NLP verification model, and the Flutter mobile app are all left as future work — but every model field and route boundary is drawn so they can be swapped in without reshaping the rest of the system.

---

## Media Evidence Layer (v3)

### Setup

1. Sign up at [cloudinary.com](https://cloudinary.com) — free tier (25 GB storage / 25 GB bandwidth/month)
2. Copy your credentials from the Cloudinary dashboard → API Keys
3. Add to `backend/.env`:

```
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
```

4. Run the new migration: `npm run prisma:migrate`
5. Install the new dependency: `npm install` (adds `cloudinary@^2.4.0`)

### How it works

| Step | What happens |
|---|---|
| Citizen opens Report modal | EvidenceUpload component renders a drag-drop zone |
| File selected | Frontend reads file as base64 data URI |
| GPS auto-attach | Browser requests location; if granted, coordinates are embedded in the upload |
| Upload | `POST /upload` sends base64 → Cloudinary; progress bar shown |
| Cloudinary response | `MediaEvidence` record created in Postgres with URL, dimensions, GPS, moderation status |
| Report submitted | `POST /reports` body includes `mediaIds[]`; backend links them |
| Verification Engine | Reports with media evidence (detected via `media` relation) are weighted more heavily |

### Endpoints

| Method | Route | Auth | Notes |
|---|---|---|---|
| POST | `/upload` | any auth | base64 data URI, max 10 MB — for images and short clips |
| POST | `/upload/sign` | any auth | returns signed params for direct browser → Cloudinary upload (large video) |
| POST | `/upload/confirm` | any auth | register a direct upload result |
| GET  | `/upload/media/:reportId` | public | all non-removed media for a report |
| GET  | `/upload/project-media/:projectId` | public | all media attached to a project |
| PATCH | `/upload/moderate/:id` | admin | approve / flag / remove; removes from Cloudinary on `removed` |

### Trust scoring

Each `Report` now stores `reporterTrustWeight` (0–100), copied from the submitting user's `trustScore` at the time of submission.

- New users start at 50 (neutral)
- Each upvote on a report nudges the reporter's score up +0.5 (max 100)
- Future: disputes reduce score; verified reports increase it faster

The `trustScore` is used by the Verification Engine to weight conflicting reports — a citizen with a history of accurate reports carries more signal than a new account.

### New schema models

- `MediaEvidence` — one record per uploaded file; linked to `Report` and/or `Project`
- `User.trustScore` — float 0–100, starts at 50
- `User.reportCount` / `verifiedReportCount` — for trust computation
- `Report.reporterTrustWeight` — stamped at submit time

