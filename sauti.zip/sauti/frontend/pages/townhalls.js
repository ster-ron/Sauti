import { useEffect, useState } from "react";
import { getTownHalls, createTownHall, voteAgendaItem, submitQuestion } from "../lib/api";

const STATUS_COLORS = { live: "#1A7A4A", scheduled: "#185FA5", ended: "#6b7280" };

function CreateTownHallModal({ onClose, onSubmit }) {
  const [form, setForm] = useState({ title: "", region: "Westlands", scheduledFor: "", agenda: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async () => {
    if (!form.title.trim() || !form.scheduledFor) { setError("Title and date are required."); return; }
    setLoading(true);
    try {
      const agendaItems = form.agenda.split("\n").filter(Boolean).map(title => ({ title }));
      await onSubmit({ title: form.title, region: form.region, scheduledFor: form.scheduledFor, agendaItems });
      onClose();
    } catch (e) { setError(e.message); setLoading(false); }
  };

  return (
    <div className="cm-modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="cm-modal">
        <div className="cm-modal-title">Schedule town hall</div>
        <div className="cm-form-grid">
          <div className="cm-field"><label className="cm-label">Title *</label><input className="cm-input" value={form.title} onChange={e => setForm({...form, title: e.target.value})} placeholder="e.g. Q2 Budget Accountability Review" /></div>
          <div className="cm-form-row">
            <div className="cm-field"><label className="cm-label">Region</label><input className="cm-input" value={form.region} onChange={e => setForm({...form, region: e.target.value})} /></div>
            <div className="cm-field"><label className="cm-label">Date & Time *</label><input className="cm-input" type="datetime-local" value={form.scheduledFor} onChange={e => setForm({...form, scheduledFor: e.target.value})} /></div>
          </div>
          <div className="cm-field"><label className="cm-label">Agenda items (one per line)</label><textarea className="cm-input cm-textarea" value={form.agenda} onChange={e => setForm({...form, agenda: e.target.value})} placeholder={"Roads & infrastructure update\nWater supply briefing\nHealth centre progress"} /></div>
        </div>
        {error && <p className="cm-error">{error}</p>}
        <div className="cm-modal-footer">
          <button className="cm-btn-ghost" onClick={onClose}>Cancel</button>
          <button className="cm-btn-primary" onClick={handleSubmit} disabled={loading}>{loading ? "Scheduling…" : "Schedule"}</button>
        </div>
      </div>
    </div>
  );
}

export default function TownHallsPage() {
  const [townHalls, setTownHalls] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [expanded, setExpanded] = useState(null);
  const [questionDrafts, setQuestionDrafts] = useState({});
  const [error, setError] = useState("");

  const load = () => getTownHalls().then(setTownHalls).catch(console.error).finally(() => setLoading(false));
  useEffect(() => { load(); }, []);

  const handleCreate = async (form) => { await createTownHall(form); load(); };
  const handleVote = async (thId, itemId) => { try { await voteAgendaItem(thId, itemId); load(); } catch(e) { setError(e.message); } };
  const handleAsk = async (thId) => {
    const q = questionDrafts[thId];
    if (!q?.trim()) return;
    try { await submitQuestion(thId, q); setQuestionDrafts({...questionDrafts, [thId]: ""}); load(); }
    catch(e) { setError(e.message); }
  };

  return (
    <main className="cm-page">
      <div className="cm-header-row">
        <div>
          <div className="cm-page-title">Town Halls</div>
          <div className="cm-page-sub">Scheduled civic accountability sessions with elected leaders</div>
        </div>
        <button className="cm-btn-primary" onClick={() => setShowCreate(true)}>
          <i className="ti ti-calendar-plus" /> Schedule
        </button>
      </div>

      {error && <p className="cm-error">{error}</p>}

      {loading ? <div className="cm-loading">Loading town halls…</div> : townHalls.length === 0 ? (
        <>
          {/* Demo card when no data */}
          <div className="cm-townhall-card" style={{ maxWidth: 460 }}>
            <div className="cm-townhall-live"><div className="cm-live-dot" /> Live now</div>
            <div className="cm-townhall-title" style={{ fontSize: 15, marginBottom: 4 }}>Budget accountability town hall — Q2 2025</div>
            <div className="cm-townhall-sub">MP Kamau Ngugi · Westlands</div>
            <button className="cm-btn-join"><i className="ti ti-player-play" /> Join session</button>
            <div className="cm-attendees">
              {[["JM","#1A7A4A"],["AK","#378ADD"],["WN","#E8A020"],["PO","#C1392B"]].map(([l,bg],i) => (
                <div key={l} className="cm-avatar" style={{ background:bg, color:"#fff", marginLeft:i>0?-8:0 }}>{l}</div>
              ))}
              <span className="cm-attendee-count">+318 attending</span>
            </div>
          </div>
          <div className="cm-empty" style={{ marginTop: 8 }}>
            <i className="ti ti-calendar-off" />No town halls scheduled yet. Leaders can create the first one.
          </div>
        </>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {townHalls.map(th => {
            const isLive = th.status === "live";
            const isExpanded = expanded === th._id;
            return (
              <div key={th._id} className="cm-card" style={{ padding: 0, overflow: "hidden" }}>
                <div style={{ padding: "14px 16px", cursor: "pointer" }} onClick={() => setExpanded(isExpanded ? null : th._id)}>
                  <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12 }}>
                    <div style={{ flex: 1 }}>
                      {isLive && (
                        <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 10, fontWeight: 600, letterSpacing: "0.8px", textTransform: "uppercase", color: "#1A7A4A", marginBottom: 4 }}>
                          <div className="cm-live-dot" /> Live now
                        </div>
                      )}
                      <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 3 }}>{th.title}</div>
                      <div style={{ fontSize: 12, color: "var(--color-text-secondary)", display: "flex", gap: 12, flexWrap: "wrap" }}>
                        <span><i className="ti ti-map-pin" /> {th.region}</span>
                        <span><i className="ti ti-calendar" /> {new Date(th.scheduledFor).toLocaleString()}</span>
                        <span><i className="ti ti-user" /> {th.leaderName}</span>
                      </div>
                    </div>
                    <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                      <span className={`cm-status ${isLive ? "status-verified" : th.status === "ended" ? "status-unverified" : "status-ongoing"}`} style={{ textTransform: "uppercase", fontSize: 10 }}>{th.status}</span>
                      <i className={`ti ${isExpanded ? "ti-chevron-up" : "ti-chevron-down"}`} style={{ color: "var(--color-text-tertiary)", fontSize: 14 }} />
                    </div>
                  </div>
                </div>

                {isExpanded && (
                  <div style={{ borderTop: "0.5px solid var(--color-border-tertiary)", padding: "14px 16px" }}>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
                      <div>
                        <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 8, color: "var(--color-text-secondary)", textTransform: "uppercase", letterSpacing: "0.5px" }}>Agenda</div>
                        {th.agendaItems?.length > 0 ? th.agendaItems.map(item => (
                          <div key={item._id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 0", borderBottom: "0.5px solid var(--color-border-tertiary)" }}>
                            <span style={{ fontSize: 13 }}>{item.title}</span>
                            <button className="cm-btn-ghost" style={{ fontSize: 11, padding: "3px 8px" }} onClick={() => handleVote(th._id, item._id)}>
                              <i className="ti ti-thumb-up" /> {item.upvotes?.length || 0}
                            </button>
                          </div>
                        )) : <p style={{ fontSize: 13, color: "var(--color-text-tertiary)" }}>No agenda items yet.</p>}
                      </div>
                      <div>
                        <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 8, color: "var(--color-text-secondary)", textTransform: "uppercase", letterSpacing: "0.5px" }}>Q&A</div>
                        <div style={{ maxHeight: 180, overflowY: "auto", marginBottom: 10 }}>
                          {th.qa?.map(q => (
                            <div key={q._id} style={{ fontSize: 12, marginBottom: 8 }}>
                              <div style={{ fontWeight: 500, marginBottom: 2 }}><i className="ti ti-question-mark" style={{ fontSize: 11 }} /> {q.question}</div>
                              <div style={{ color: "var(--color-text-secondary)" }}>— {q.askedByName}</div>
                              {q.answer && <div style={{ marginTop: 4, color: "#0F6E56", borderLeft: "2px solid #1A7A4A", paddingLeft: 8 }}>{q.answer}</div>}
                            </div>
                          ))}
                          {(!th.qa || th.qa.length === 0) && <p style={{ fontSize: 13, color: "var(--color-text-tertiary)" }}>No questions yet.</p>}
                        </div>
                        <div style={{ display: "flex", gap: 6 }}>
                          <input className="cm-input" style={{ flex: 1, fontSize: 12 }} placeholder="Ask a question…"
                            value={questionDrafts[th._id] || ""}
                            onChange={e => setQuestionDrafts({...questionDrafts, [th._id]: e.target.value})}
                            onKeyDown={e => e.key === "Enter" && handleAsk(th._id)}
                          />
                          <button className="cm-btn-primary" style={{ fontSize: 12, padding: "7px 10px" }} onClick={() => handleAsk(th._id)}>Ask</button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {showCreate && <CreateTownHallModal onClose={() => setShowCreate(false)} onSubmit={handleCreate} />}
    </main>
  );
}
