import { useEffect, useState } from "react";
import { getOversightReports, createOversightReport, getCorruptionOverview, getActiveElectionCycle } from "../lib/api";

function getUser() {
  if (typeof window === "undefined") return null;
  try { return JSON.parse(localStorage.getItem("sauti_user")); } catch { return null; }
}

function NewReportModal({ onClose, onSubmit }) {
  const [form, setForm] = useState({ title: "", summary: "", region: "", isPublished: false });
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState("");

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const handleSubmit = async () => {
    if (!form.title.trim() || !form.summary.trim()) { setError("Title and summary are required."); return; }
    setLoading(true);
    try { await onSubmit(form); onClose(); }
    catch (e) { setError(e.message); setLoading(false); }
  };

  return (
    <div className="cm-modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="cm-modal">
        <div className="cm-modal-title">Publish oversight report</div>
        <p style={{ fontSize: 12, color: "var(--color-text-secondary)", marginBottom: 12 }}>
          Election stakeholder oversight reports are public transparency documents.
        </p>
        <div className="cm-form-grid">
          <div className="cm-field">
            <label className="cm-label">Title *</label>
            <input className="cm-input" value={form.title} onChange={set("title")} placeholder="e.g. Q2 2025 Westlands Integrity Assessment" />
          </div>
          <div className="cm-field">
            <label className="cm-label">Summary *</label>
            <textarea className="cm-input cm-textarea" style={{ minHeight: 120 }} value={form.summary} onChange={set("summary")} placeholder="Key findings and observations..." />
          </div>
          <div className="cm-field">
            <label className="cm-label">Region</label>
            <input className="cm-input" value={form.region} onChange={set("region")} placeholder="e.g. Westlands" />
          </div>
          <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, cursor: "pointer" }}>
            <input type="checkbox" checked={form.isPublished} onChange={(e) => setForm({ ...form, isPublished: e.target.checked })} />
            Publish immediately (visible to all citizens)
          </label>
        </div>
        {error && <p className="cm-error">{error}</p>}
        <div className="cm-modal-footer">
          <button className="cm-btn-ghost" onClick={onClose}>Cancel</button>
          <button className="cm-btn-primary" onClick={handleSubmit} disabled={loading}>
            {loading ? "Saving…" : "Save report"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function OversightPage() {
  const [reports, setReports]     = useState([]);
  const [overview, setOverview]   = useState(null);
  const [activeCycle, setActiveCycle] = useState(null);
  const [loading, setLoading]     = useState(true);
  const [showNew, setShowNew]     = useState(false);
  const [error, setError]         = useState("");
  const user = getUser();
  const canCreate = user && ["election_stakeholder", "admin"].includes(user.role);

  const load = () =>
    Promise.all([
      getOversightReports().catch(() => []),
      getCorruptionOverview().catch(() => null),
      getActiveElectionCycle().catch(() => null),
    ])
      .then(([r, o, c]) => { setReports(r); setOverview(o); setActiveCycle(c?.activeFlag ? c : null); })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));

  useEffect(() => { load(); }, []);

  const handleCreate = async (form) => { await createOversightReport(form); load(); };

  const RISK_LEVEL_COLOR = {
    none: "#1A7A4A", low: "#E8A020", medium: "#D4760A", high: "#C1392B", critical: "#7B0000",
  };

  const DEMO_REPORTS = [
    {
      id: "d1", title: "Q2 2025 Westlands Constituency Governance Assessment",
      summary: "Review of 24 active projects found 3 with significant citizen-reported discrepancies. Budget absorption rate at 38% — below the 60% threshold expected at this stage of the fiscal year. Two road projects carrying active corruption signals require further investigation.",
      region: "Westlands", isPublished: true,
      createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: "d2", title: "Election Integrity Observation: CDF Allocation Tracking",
      summary: "Constituency Development Fund allocations cross-referenced with citizen report data. 4 of 12 CDF-funded projects show completion claims contradicted by on-ground reports. Flagging for formal audit referral.",
      region: "Westlands", isPublished: true,
      createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
    },
  ];

  const displayReports = reports.length > 0 ? reports : DEMO_REPORTS;

  const demoOverview = overview || {
    overview: { total: 24, none: 14, low: 4, medium: 4, high: 2, critical: 0 },
    topFlags:  [
      { flag: "funds diverted",            count: 3 },
      { flag: "ghost project",             count: 2 },
      { flag: "no progress",              count: 5 },
      { flag: "substandard materials",     count: 2 },
      { flag: "contractor left",           count: 3 },
    ],
  };

  return (
    <main className="cm-page">
      <div className="cm-header-row">
        <div>
          <div className="cm-page-title">Oversight Reports</div>
          <div className="cm-page-sub">Election stakeholder monitoring · Governance integrity tracking</div>
        </div>
        {canCreate && (
          <button className={`cm-btn-primary ${!activeCycle ? "cm-btn-disabled" : ""}`}
            onClick={() => activeCycle ? setShowNew(true) : null}
            title={!activeCycle ? "No active election cycle — contact admin to activate one" : ""}
            style={{ opacity: activeCycle ? 1 : 0.5, cursor: activeCycle ? "pointer" : "not-allowed" }}>
            <i className="ti ti-plus" /> New report
          </button>
        )}
      </div>

      {canCreate && !activeCycle && (
        <div style={{ background: "#FEF9E7", border: "0.5px solid #E8A020", borderRadius: "var(--border-radius-md)", padding: "10px 12px", display: "flex", gap: 8, alignItems: "center" }}>
          <i className="ti ti-info-circle" style={{ color: "#E8A020", fontSize: 16 }} />
          <div style={{ fontSize: 12, color: "#633806" }}>
            <strong>Election cycle inactive.</strong> Oversight reports can only be created during an active election cycle.
            {" "}<a href="/election" style={{ color: "#1A7A4A", fontWeight: 500 }}>View election cycles →</a>
          </div>
        </div>
      )}

      {error && (
        <div className="cm-alert-banner">
          <i className="ti ti-alert-triangle" style={{ color: "#A32D2D", fontSize: 16 }} />
          <div className="cm-alert-text">{error}</div>
        </div>
      )}

      {/* Corruption overview panel */}
      <div className="cm-card">
        <div className="cm-section-title" style={{ marginBottom: 12 }}>
          <i className="ti ti-shield-x" /> Corruption Risk Overview
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 8, marginBottom: 16 }}>
          {["none", "low", "medium", "high", "critical"].map((level) => (
            <div key={level} style={{ textAlign: "center", padding: "10px 6px", background: "var(--color-background-secondary)", borderRadius: "var(--border-radius-md)", borderTop: `3px solid ${RISK_LEVEL_COLOR[level]}` }}>
              <div style={{ fontSize: 20, fontWeight: 700, color: RISK_LEVEL_COLOR[level], fontFamily: "Merriweather, serif" }}>
                {demoOverview.overview[level] || 0}
              </div>
              <div style={{ fontSize: 10, color: "var(--color-text-tertiary)", marginTop: 2, textTransform: "capitalize" }}>{level}</div>
            </div>
          ))}
        </div>

        {demoOverview.topFlags?.length > 0 && (
          <>
            <div style={{ fontSize: 11, fontWeight: 600, color: "var(--color-text-secondary)", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 8 }}>
              Top corruption signals detected
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
              {demoOverview.topFlags.map((f) => (
                <span key={f.flag} style={{ fontSize: 12, background: "#FCEBEB", color: "#A32D2D", padding: "3px 8px", borderRadius: 4 }}>
                  {f.flag} ({f.count}×)
                </span>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Oversight reports list */}
      <div>
        <div className="cm-section-title">Published reports</div>
        {loading ? (
          <div className="cm-loading">Loading reports…</div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {displayReports.map((r) => (
              <div key={r.id} className="cm-card">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                      <span style={{ fontSize: 14, fontWeight: 600 }}>{r.title}</span>
                      {!r.isPublished && (
                        <span style={{ fontSize: 11, background: "#FEF9E7", color: "#E8A020", padding: "2px 6px", borderRadius: 4 }}>Draft</span>
                      )}
                    </div>
                    <p style={{ fontSize: 13, color: "var(--color-text-secondary)", lineHeight: 1.6, marginBottom: 8 }}>{r.summary}</p>
                    <div style={{ fontSize: 12, color: "var(--color-text-tertiary)", display: "flex", gap: 12, flexWrap: "wrap" }}>
                      {r.region && <span><i className="ti ti-map-2" /> {r.region}</span>}
                      <span><i className="ti ti-calendar" /> {new Date(r.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <i className="ti ti-file-report" style={{ fontSize: 20, color: "#185FA5", flexShrink: 0, marginTop: 2 }} />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showNew && <NewReportModal onClose={() => setShowNew(false)} onSubmit={handleCreate} />}
    </main>
  );
}
