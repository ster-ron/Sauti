import "../styles/globals.css";
import { useState, useEffect } from "react";
import { useRouter } from "next/router";
import Head from "next/head";
import Link from "next/link";
import { getMyReports, getLeader } from "../lib/api";
import { getStoredTheme, setTheme, THEME_INIT_SCRIPT } from "../lib/theme";
import { savedCount } from "../lib/saved";
import VerifyClaimModal from "../components/VerifyClaimModal";
import ReportIssueModal from "../components/ReportIssueModal";

function getUser() {
  if (typeof window === "undefined") return null;
  try { return JSON.parse(localStorage.getItem("sauti_user")); } catch { return null; }
}

function Sidebar({ activePath, user }) {
  const [score, setScore] = useState(null);
  const [myReportCount, setMyReportCount] = useState(null);
  const [savedTotal, setSavedTotal] = useState(0);
  const [verifyOpen, setVerifyOpen] = useState(false);
  const [reportIssueOpen, setReportIssueOpen] = useState(false);

  useEffect(() => {
    if (!user) {
      setMyReportCount(null);
      return;
    }
    let cancelled = false;
    getMyReports()
      .then((reports) => { if (!cancelled) setMyReportCount(reports.length); })
      .catch(() => { if (!cancelled) setMyReportCount(null); }); // fail quietly, badge just won't render
    return () => { cancelled = true; };
  }, [user]);

  // The accountability score card only makes sense for a leader looking at
  // their own standing — pulling their real, SautiCore-maintained
  // score rather than a hardcoded placeholder.
  useEffect(() => {
    if (user?.role !== "leader" || !user?.id) { setScore(null); return; }
    let cancelled = false;
    getLeader(user.id)
      .then((l) => { if (!cancelled) setScore(l.accountabilityScore ?? null); })
      .catch(() => { if (!cancelled) setScore(null); });
    return () => { cancelled = true; };
  }, [user]);

  useEffect(() => {
    const refresh = () => setSavedTotal(savedCount());
    refresh();
    window.addEventListener("sauti-saved-changed", refresh);
    return () => window.removeEventListener("sauti-saved-changed", refresh);
  }, []);

  const navItems = [
    { href: "/dashboard", icon: "ti-layout-dashboard",  label: "Dashboard" },
    { href: "/projects",  icon: "ti-building-community",label: "Projects" },
    { href: "/map",       icon: "ti-map-2",             label: "Map" },
    { href: "/leaders",   icon: "ti-id-badge-2",        label: "Leaders" },
    { href: "/forums",    icon: "ti-message-circle-2",  label: "Forum" },
    { href: "/townhalls", icon: "ti-users",             label: "Town Halls" },
    { href: "/election",  icon: "ti-calendar-event",    label: "Election Cycle" },
    { href: "/oversight", icon: "ti-shield-check",      label: "Oversight", roles: ["election_stakeholder", "admin", "leader"] },
    { href: "/intelligence", icon: "ti-chart-bar",      label: "Intelligence", roles: ["leader", "admin", "election_stakeholder"] },
  ];

  return (
    <aside className="cm-sidebar">
      {score !== null && (
        <div className="cm-score-card">
          <div className="cm-score-label">Your accountability score</div>
          <div className="cm-score-ring-wrap">
            <div>
              <div className="cm-score-number">{score}</div>
              <div className="cm-score-sub">out of 100</div>
            </div>
            <svg width="50" height="50" viewBox="0 0 50 50">
              <circle cx="25" cy="25" r="20" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="4"/>
              <circle cx="25" cy="25" r="20" fill="none" stroke="#1A7A4A" strokeWidth="4"
                strokeDasharray={`${score * 1.257} ${(100 - score) * 1.257}`}
                strokeLinecap="round" transform="rotate(-90 25 25)"/>
            </svg>
          </div>
          <div className="cm-score-bar-track">
            <div className="cm-score-bar-fill" style={{ width: `${score}%` }} />
          </div>
        </div>
      )}

      <div className="cm-sidebar-section">
        <div className="cm-sidebar-label">Navigate</div>
        {navItems.map((item) => {
          if (item.roles && user && !item.roles.includes(user.role)) return null;
          const isActive = activePath === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div className={`cm-sidebar-item ${isActive ? "active" : ""}`}>
                <i className={`ti ${item.icon}`} style={{ fontSize: 16 }} />
                {item.label}
              </div>
            </Link>
          );
        })}
      </div>

      <div className="cm-sidebar-section">
        <div className="cm-sidebar-label">My activity</div>
        <Link href="/my-reports">
          <div className={`cm-sidebar-item ${activePath === "/my-reports" ? "active" : ""}`}>
            <i className="ti ti-file-description" style={{ fontSize: 16 }} />
            My reports
            {myReportCount !== null && myReportCount > 0 && (
              <span className="cm-sidebar-badge">{myReportCount}</span>
            )}
          </div>
        </Link>
        <Link href="/saved">
          <div className={`cm-sidebar-item ${activePath === "/saved" ? "active" : ""}`}>
            <i className="ti ti-bookmark" style={{ fontSize: 16 }} />
            Saved
            {savedTotal > 0 && <span className="cm-sidebar-badge">{savedTotal}</span>}
          </div>
        </Link>
      </div>

      <div className="cm-sidebar-section">
        <div className="cm-sidebar-label">Tools</div>
        <div className="cm-sidebar-item" onClick={() => setVerifyOpen(true)} style={{ cursor: "pointer" }}>
          <i className="ti ti-shield-check" style={{ fontSize: 16 }} />
          Verify a claim
        </div>
        <div className="cm-sidebar-item" onClick={() => setReportIssueOpen(true)} style={{ cursor: "pointer" }}>
          <i className="ti ti-alert-triangle" style={{ fontSize: 16 }} />
          Report issue
        </div>
        {user?.role === "admin" && (
          <Link href="/audit">
            <div className={`cm-sidebar-item ${activePath === "/audit" ? "active" : ""}`}>
              <i className="ti ti-lock" style={{ fontSize: 16 }} />
              Audit log
            </div>
          </Link>
        )}
      </div>

      {/* USSD access teaser */}
      <div style={{ margin: "12px 10px 0", padding: "10px", background: "rgba(26,122,74,0.08)", borderRadius: "var(--border-radius-md)", fontSize: 11, color: "var(--color-text-secondary)", lineHeight: 1.5 }}>
        <i className="ti ti-device-mobile" style={{ marginRight: 5 }} />
        <strong>No internet?</strong> Dial <strong>*384#</strong> to report via USSD
      </div>

      {verifyOpen && <VerifyClaimModal onClose={() => setVerifyOpen(false)} />}
      {reportIssueOpen && <ReportIssueModal onClose={() => setReportIssueOpen(false)} />}
    </aside>
  );
}

function SettingsModal({ onClose }) {
  const [theme, setThemeChoice] = useState(getStoredTheme());

  const THEME_OPTIONS = [
    { value: "light",  label: "Light",  icon: "ti-sun" },
    { value: "dark",   label: "Dark",   icon: "ti-moon" },
    { value: "system", label: "System", icon: "ti-device-desktop" },
  ];

  const choose = (value) => {
    setThemeChoice(value);
    setTheme(value);
  };

  return (
    <div className="cm-modal-overlay" onClick={onClose}>
      <div className="cm-modal" onClick={(e) => e.stopPropagation()}>
        <div className="cm-modal-title">Settings</div>

        <div className="cm-field">
          <label className="cm-label">Theme</label>
          <div className="cm-chips">
            {THEME_OPTIONS.map((opt) => (
              <div
                key={opt.value}
                className={`cm-chip ${theme === opt.value ? "active" : ""}`}
                onClick={() => choose(opt.value)}
              >
                <i className={`ti ${opt.icon}`} style={{ marginRight: 5 }} />
                {opt.label}
              </div>
            ))}
          </div>
        </div>

        <div className="cm-modal-footer">
          <button className="cm-btn-ghost" onClick={onClose}>Done</button>
        </div>
      </div>
    </div>
  );
}



const PUBLIC_PATHS = ["/", "/login"];

export default function App({ Component, pageProps }) {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [settingsOpen, setSettingsOpen] = useState(false);

  useEffect(() => { setUser(getUser()); }, [router.pathname]);
  useEffect(() => { setTheme(getStoredTheme()); }, []); // re-apply in case OS theme changed since last visit

  const isPublic = PUBLIC_PATHS.includes(router.pathname);

  const initials = user?.name
    ? user.name.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase()
    : "?";

  const handleLogout = () => {
    localStorage.removeItem("sauti_token");
    localStorage.removeItem("sauti_user");
    router.push("/login");
  };

  const topNav = [
    { href: "/dashboard", icon: "ti-layout-dashboard",  label: "Dashboard" },
    { href: "/projects",  icon: "ti-building-community",label: "Projects" },
    { href: "/map",       icon: "ti-map-2",             label: "Map" },
    { href: "/leaders",   icon: "ti-id-badge-2",        label: "Leaders" },
    { href: "/forums",    icon: "ti-message-circle-2",  label: "Forum" },
    { href: "/townhalls", icon: "ti-users",             label: "Town Halls" },
  ];

  return (
    <>
      <Head>
        <title>Sauti</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <script dangerouslySetInnerHTML={{ __html: THEME_INIT_SCRIPT }} />
      </Head>

      {isPublic ? (
        <Component {...pageProps} />
      ) : (
        <>
          <header className="cm-topbar">
            <Link href="/dashboard">
              <div className="cm-logo">
                <div className="cm-logo-dot" />
                Sauti
              </div>
            </Link>
            <nav className="cm-nav">
              {topNav.map(({ href, icon, label }) => (
                <Link key={href} href={href}>
                  <button className={`cm-nav-btn ${router.pathname === href ? "active" : ""}`}>
                    <i className={`ti ${icon}`} />
                    {label}
                  </button>
                </Link>
              ))}
            </nav>
            <div className="cm-topbar-right">
              <div className="cm-avatar-sm" style={{ background: "transparent", color: "var(--color-text-secondary)" }} onClick={() => setSettingsOpen(true)} title="Settings">
                <i className="ti ti-settings" style={{ fontSize: 17 }} />
              </div>
              {user && (
                <>
                  <span className="cm-badge-role">{user.role}</span>
                  <div className="cm-avatar-sm" onClick={handleLogout} title="Logout">
                    {initials}
                  </div>
                </>
              )}
              {!user && (
                <Link href="/login">
                  <button className="cm-btn-ghost" style={{ fontSize: 12, padding: "5px 10px" }}>Login</button>
                </Link>
              )}
            </div>
          </header>

          {settingsOpen && <SettingsModal onClose={() => setSettingsOpen(false)} />}

          <div className={router.pathname === "/dashboard" ? "cm-shell-3col" : "cm-shell"}>
            <Sidebar activePath={router.pathname} user={user} />
            <div className="cm-main-scroll">
              <Component {...pageProps} />
            </div>
            {router.pathname === "/dashboard" && <DashboardRightPanel />}
          </div>
        </>
      )}
    </>
  );
}

function DashboardRightPanel() {
  return (
    <aside className="cm-right-panel">
      <div className="cm-panel-section">
        <div className="cm-townhall-card">
          <div className="cm-townhall-live">
            <div className="cm-live-dot" /> Live now
          </div>
          <div className="cm-townhall-title">Budget accountability town hall — Q2 2025</div>
          <div className="cm-townhall-sub">MP Kamau Ngugi · Westlands</div>
          <Link href="/townhalls">
            <button className="cm-btn-join">
              <i className="ti ti-player-play" /> Join session
            </button>
          </Link>
          <div className="cm-attendees">
            {[["JM","#1A7A4A"],["AK","#378ADD"],["WN","#E8A020"],["PO","#C1392B"]].map(([label, bg], i) => (
              <div key={label} className="cm-avatar" style={{ background: bg, color: "#fff", marginLeft: i > 0 ? -8 : 0 }}>{label}</div>
            ))}
            <span className="cm-attendee-count">+318 attending</span>
          </div>
        </div>
      </div>

      <div className="cm-panel-section">
        <div className="cm-section-title" style={{ marginBottom: 12 }}>Recent citizen reports</div>
        {[
          { dot: "dot-red",   content: "Road work on Waiyaki Way has completely stopped. No crew on site for 11 days.", meta: "Kangemi · 45 min ago",   priority: "High priority", color: "#C1392B" },
          { dot: "dot-amber", content: "Borehole at Loresho completed but water pump not yet installed.",              meta: "Loresho · 2h ago",        priority: "Medium",        color: "#E8A020" },
          { dot: "dot-green", content: "Kangemi market renovation phase 1 looks excellent — stalls are operational.", meta: "Kangemi · 4h ago",        priority: "Positive",      color: "#1A7A4A" },
          { dot: "dot-red",   content: "Health centre exterior painted but interior construction has not resumed.",    meta: "Westlands ward · 6h ago", priority: "High priority", color: "#C1392B" },
          { dot: "dot-blue",  content: "New streetlights installed along Peponi Road. Community appreciates this.",   meta: "Parklands · 1d ago",      priority: "Info",          color: "#185FA5" },
        ].map((r, i) => (
          <div key={i} className="cm-report-item">
            <div className={`cm-report-dot ${r.dot}`} />
            <div>
              <div className="cm-report-content">{r.content}</div>
              <div className="cm-report-time">{r.meta} · <span style={{ color: r.color }}>{r.priority}</span></div>
            </div>
          </div>
        ))}
      </div>

      <div>
        <div className="cm-section-title" style={{ marginBottom: 10 }}>
          Leaders in this constituency
          <Link href="/leaders"><span className="cm-section-link">View all →</span></Link>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {[
            { initials: "KN", name: "Kamau Ngugi", role: "MP · Westlands",      score: 67, color: "#0D1B2A", scoreColor: "#E8A020", flags: 1 },
            { initials: "AM", name: "Aisha Mwangi", role: "MCA · Kangemi ward", score: 84, color: "#1A7A4A", scoreColor: "#1A7A4A", flags: 0 },
          ].map((l) => (
            <Link key={l.initials} href="/leaders">
              <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 10px", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-md)", cursor: "pointer" }}>
                <div style={{ width: 32, height: 32, borderRadius: "50%", background: l.color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 600, color: "#fff" }}>{l.initials}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 500, display: "flex", alignItems: "center", gap: 6 }}>
                    {l.name}
                    {l.flags > 0 && <i className="ti ti-alert-triangle" style={{ fontSize: 11, color: "#D4760A" }} />}
                  </div>
                  <div style={{ fontSize: 11, color: "var(--color-text-secondary)" }}>{l.role}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: l.scoreColor }}>{l.score}</div>
                  <div style={{ fontSize: 10, color: "var(--color-text-tertiary)" }}>score</div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </aside>
  );
}
