import { useState } from "react";
import { useRouter } from "next/router";
import { login, register } from "../lib/api";

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "citizen" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(""); setLoading(true);
    try {
      const data = mode === "login" ? await login(form) : await register(form);
      localStorage.setItem("sauti_token", data.token);
      localStorage.setItem("sauti_user", JSON.stringify(data.user));
      router.push("/dashboard");
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  };

  return (
    <div className="cm-login-page">
      <div className="cm-login-box">
        <div className="cm-login-logo">
          <div className="cm-logo-dot" />
          Sauti
        </div>
        <div className="cm-login-tabs">
          <button className={`cm-login-tab ${mode === "login" ? "active" : ""}`} onClick={() => setMode("login")}>Login</button>
          <button className={`cm-login-tab ${mode === "register" ? "active" : ""}`} onClick={() => setMode("register")}>Register</button>
        </div>

        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {mode === "register" && (
            <div className="cm-field"><label className="cm-label">Full name</label><input className="cm-input" name="name" placeholder="Jane Mwangi" value={form.name} onChange={set("name")} required /></div>
          )}
          <div className="cm-field"><label className="cm-label">Email</label><input className="cm-input" name="email" type="email" placeholder="you@example.com" value={form.email} onChange={set("email")} required /></div>
          <div className="cm-field"><label className="cm-label">Password</label><input className="cm-input" name="password" type="password" placeholder="••••••••" value={form.password} onChange={set("password")} required /></div>
          {mode === "register" && (
            <div className="cm-field">
              <label className="cm-label">Role</label>
              <select className="cm-select" name="role" value={form.role} onChange={set("role")}>
                <option value="citizen">Citizen</option>
                <option value="leader">Leader</option>
              </select>
            </div>
          )}
          {error && <p className="cm-error">{error}</p>}
          <button type="submit" className="cm-btn-primary" disabled={loading} style={{ width: "100%", justifyContent: "center", marginTop: 4 }}>
            {loading ? "Please wait…" : mode === "login" ? "Login" : "Create account"}
          </button>
        </form>

        <p style={{ fontSize: 12, color: "var(--color-text-tertiary)", marginTop: 16, textAlign: "center", lineHeight: 1.5 }}>
          Track public projects. Submit evidence.<br />Hold leaders accountable.
        </p>
      </div>
    </div>
  );
}
