import { useEffect, useState } from "react";
import { getThreads, createThread, replyToThread } from "../lib/api";

const TOPICS = ["water", "roads", "health", "education", "security", "other"];
const TAG_MAP = { water:"tag-water", roads:"tag-roads", health:"tag-health", education:"tag-edu", security:"tag-security", other:"tag-other" };

function NewThreadModal({ onClose, onSubmit }) {
  const [form, setForm] = useState({ topic: "other", title: "", content: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async () => {
    if (!form.title.trim() || !form.content.trim()) { setError("Title and content are required."); return; }
    setLoading(true);
    try { await onSubmit(form); onClose(); }
    catch (e) { setError(e.message); setLoading(false); }
  };

  return (
    <div className="cm-modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="cm-modal">
        <div className="cm-modal-title">Start new discussion</div>
        <div className="cm-form-grid">
          <div className="cm-field">
            <label className="cm-label">Topic</label>
            <select className="cm-select" value={form.topic} onChange={e => setForm({...form, topic: e.target.value})}>
              {TOPICS.map(t => <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>)}
            </select>
          </div>
          <div className="cm-field"><label className="cm-label">Title *</label><input className="cm-input" value={form.title} onChange={e => setForm({...form, title: e.target.value})} placeholder="What's the issue?" /></div>
          <div className="cm-field"><label className="cm-label">Content *</label><textarea className="cm-input cm-textarea" style={{ minHeight: 120 }} value={form.content} onChange={e => setForm({...form, content: e.target.value})} placeholder="Describe the situation in detail…" /></div>
        </div>
        {error && <p className="cm-error">{error}</p>}
        <div className="cm-modal-footer">
          <button className="cm-btn-ghost" onClick={onClose}>Cancel</button>
          <button className="cm-btn-primary" onClick={handleSubmit} disabled={loading}>{loading ? "Posting…" : "Post thread"}</button>
        </div>
      </div>
    </div>
  );
}

export default function ForumsPage() {
  const [threads, setThreads] = useState([]);
  const [topicFilter, setTopicFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);
  const [expanded, setExpanded] = useState(null);
  const [replyDrafts, setReplyDrafts] = useState({});
  const [error, setError] = useState("");

  const load = (topic) =>
    getThreads(topic ? { topic } : {}).then(setThreads).catch(console.error).finally(() => setLoading(false));

  useEffect(() => { load(topicFilter); }, [topicFilter]);

  const handleCreate = async (form) => { await createThread(form); load(topicFilter); };

  const handleReply = async (threadId) => {
    const content = replyDrafts[threadId];
    if (!content?.trim()) return;
    try { await replyToThread(threadId, content); setReplyDrafts({...replyDrafts, [threadId]: ""}); load(topicFilter); }
    catch (e) { setError(e.message); }
  };

  return (
    <main className="cm-page">
      <div className="cm-header-row">
        <div>
          <div className="cm-page-title">Civic Forum</div>
          <div className="cm-page-sub">Structured, topic-based discussion — not a free-for-all feed</div>
        </div>
        <button className="cm-btn-primary" onClick={() => setShowNew(true)}>
          <i className="ti ti-plus" /> New thread
        </button>
      </div>

      <div className="cm-chips">
        {["", ...TOPICS].map(t => (
          <button key={t} className={`cm-chip ${topicFilter === t ? "active" : ""}`} onClick={() => setTopicFilter(t)}>
            {t || "All topics"}
          </button>
        ))}
      </div>

      {error && <p className="cm-error">{error}</p>}

      {loading ? <div className="cm-loading">Loading threads…</div> : threads.length === 0 ? (
        <div className="cm-empty"><i className="ti ti-message-off" />No threads yet. Be the first to start a discussion.</div>
      ) : (
        <div className="cm-card" style={{ padding: "0 14px" }}>
          {threads.map((t) => (
            <div key={t._id}>
              <div className="cm-forum-item" onClick={() => setExpanded(expanded === t._id ? null : t._id)}>
                <div className="cm-forum-title">{t.title}</div>
                <div className="cm-forum-meta">
                  <span className={`cm-tag ${TAG_MAP[t.topic] || "tag-other"}`}>{t.topic}</span>
                  <span><i className="ti ti-message" style={{ fontSize: 11 }} /> {t.replies?.length || 0} replies</span>
                  <span>by {t.userName}</span>
                  {t.createdAt && <span>{new Date(t.createdAt).toLocaleDateString()}</span>}
                </div>
              </div>

              {expanded === t._id && (
                <div style={{ padding: "0 0 14px 0" }}>
                  <p style={{ fontSize: 13, color: "var(--color-text-secondary)", lineHeight: 1.6, marginBottom: 14, padding: "10px 0", borderTop: "0.5px solid var(--color-border-tertiary)" }}>
                    {t.content}
                  </p>

                  {t.replies?.length > 0 && (
                    <div style={{ marginBottom: 12 }}>
                      {t.replies.map((r) => (
                        <div key={r._id} style={{ display: "flex", gap: 10, padding: "8px 0", borderTop: "0.5px solid var(--color-border-tertiary)" }}>
                          <div style={{ width: 26, height: 26, borderRadius: "50%", background: "#1A7A4A", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 600, color: "#fff", flexShrink: 0 }}>
                            {(r.userName || "?")[0].toUpperCase()}
                          </div>
                          <div>
                            <div style={{ fontSize: 12, fontWeight: 500, marginBottom: 2 }}>{r.userName}</div>
                            <div style={{ fontSize: 13, color: "var(--color-text-secondary)", lineHeight: 1.5 }}>{r.content}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  <div style={{ display: "flex", gap: 8 }}>
                    <input className="cm-input" style={{ flex: 1 }} placeholder="Write a reply…"
                      value={replyDrafts[t._id] || ""}
                      onChange={e => setReplyDrafts({...replyDrafts, [t._id]: e.target.value})}
                      onKeyDown={e => e.key === "Enter" && handleReply(t._id)}
                    />
                    <button className="cm-btn-primary" onClick={() => handleReply(t._id)}>
                      <i className="ti ti-send" /> Reply
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {showNew && <NewThreadModal onClose={() => setShowNew(false)} onSubmit={handleCreate} />}
    </main>
  );
}
