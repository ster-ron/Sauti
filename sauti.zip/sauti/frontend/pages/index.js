import { useEffect } from "react";
import { useRouter } from "next/router";

export default function Home() {
  const router = useRouter();
  useEffect(() => {
    const token = typeof window !== "undefined" ? localStorage.getItem("sauti_token") : null;
    router.replace(token ? "/dashboard" : "/login");
  }, []);
  return null;
}
