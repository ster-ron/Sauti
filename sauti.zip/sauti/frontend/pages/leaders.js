import { useEffect, useState } from "react";
import Link from "next/link";
import { getLeaders } from "../lib/api";

const RISK_COLORS = {
  none:     { bg: "#E1F5EE", color: "#0F6E56" },
  low:      { bg: "#FEF9E7", color: "#E8A020" },
  medium:   { bg: "#FEF0DC", color: "#D4760A" },
  high:     { bg: "#FCEBEB", color: "#C1392B" },
  critical: { bg: "#3D0000", color: "#FF6B6B" },
};

function ScoreRing({ score }) {
  const r = 18;
  const circ = 2 * Math.PI * r;
  const pct  = Math.max(0, Math.min(100, score));
  const dash  = (pct / 100) * circ;
  const color = pct >= 70 ? "#1A7A4A" : pct >= 45 ? "#E8A020" : "#C1392B";

  return (
    <svg width="44" height="44" viewBox="0 0 44 44">
      <circle cx="22" cy="22" r={r} fill="none" stroke="var(--color-border-tertiary)" strokeWidth="3.5" />
      <circle cx="22" cy="22" r={r} fill="none" stroke={color} strokeWidth="3.5"
        strokeDasharray={`${dash} ${circ - dash}`}
        strokeLinecap="round" transform="rotate(-90 22 22)" />
      <text x="22" y="26" textAnchor="middle" fontSize="10" fontWeight="700" fill={color}>{pct}</text>
    </svg>
  );
}

export default function LeadersPage() {
  const [leaders, setLeaders]           = useState([]);
  const [loading, setLoading]           = useState(true);
  const [constituency, setConstituency] = useState("");
  const [selected, setSelected]         = useState(null);
  const [error, setError]               = useState("");

  const load = (params = {}) =>
    getLeaders(params)
      .then(setLeaders)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));

  useEffect(() => { load(); }, []);

  const handleSearch = () => load(constituency ? { constituency } : {});

  const DEMO_LEADERS = [
    {
      id: "demo-1", name: "Kamau Ngugi", title: "MP", constituency: "Westlands",
      ward: null, bio: "Member of Parliament for Westlands Constituency since 2022.",
      accountabilityScore: 67, projectCount: 12, reportCount: 214,
      disputedCount: 3, corruptionFlags: 1,
    },
    {
      id: "demo-2", name: "Aisha Mwangi", title: "MCA", constituency: "Westlands",
      ward: "Kangemi ward", bio: "Ward Representative committed to community-led development.",
      accountabilityScore: 84, projectCount: 6, reportCount: 89,
      disputedCount: 0, corruptionFlags: 0,
    },
    {
      id: "demo-3", name: "Peter Otieno", title: "MCA", constituency: "Westlands",
      ward: "Loresho ward", bio: "Ward rep focusing on water access and road infrastructure.",
      accountabilityScore: 42, projectCount: 4, reportCount: 57,
      disputedCount: 2, corruptionFlags: 2,
    },
  ];

  const display = leaders.length > 0 ? leaders : DEMO_LEADERS;

  return (
    <main className="cm-page">
      <div className="cm-header-row">
        <div>
          <div className="cm-page-title">Leaders Registry</div>
          <div className="cm-page-sub">Public accountability scores for elected representatives</div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <input
            className="cm-input" style={{ width: 200 }}
            placeholder="Filter by constituency"
            value={constituency}
            onChange={(e) => setConstituency(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          />
          <button className="cm-btn-primary" onClick={handleSearch}>
            <i className="ti ti-search" /> Search
          </button>
        </div>
      </div>

      {error && (
        <div className="cm-alert-banner">
          <i className="ti ti-alert-triangle" style={{ color: "#A32D2D", fontSize: 16 }} />
          <div className="cm-alert-text">{error}</div>
        </div>
      )}

      {loading ? (
        <div className="cm-loading">Loading leaders registry…</div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {display.map((l) => {
            const riskStyle = l.corruptionFlags > 0
              ? (l.corruptionFlags >= 3 ? RISK_COLORS.high : RISK_COLORS.medium)
              : RISK_COLORS.none;
            const isOpen = selected === l.id;

            return (
              <div key={l.id} className="cm-card" style={{ padding: 0, overflow: "hidden" }}>
                {/* Header row */}
                <div
                  style={{ padding: "14px 16px", cursor: "pointer", display: "grid", gridTemplateColumns: "44px 1fr auto", gap: 14, alignItems: "center" }}
                  onClick={() => setSelected(isOpen ? null : l.id)}
                >
                  <ScoreRing score={l.accountabilityScore} />

                  <div>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 3 }}>
                      <span style={{ fontSize: 14, fontWeight: 600 }}>{l.name}</span>
                      {l.title && (
                        <span style={{ fontSize: 11, fontWeight: 500, background: "#E1F5EE", color: "#0F6E56", padding: "2px 6px", borderRadius: 4 }}>
                          {l.title}
                        </span>
                      )}
                      {l.corruptionFlags > 0 && (
                        <span style={{ fontSize: 11, fontWeight: 500, background: riskStyle.bg, color: riskStyle.color, padding: "2px 6px", borderRadius: 4 }}>
                          <i className="ti ti-alert-triangle" style={{ fontSize: 10 }} /> {l.corruptionFlags} corruption signal{l.corruptionFlags > 1 ? "s" : ""}
                        </span>
                      )}
                    </div>
                    <div style={{ fontSize: 12, color: "var(--color-text-secondary)", display: "flex", gap: 12, flexWrap: "wrap" }}>
                      {l.constituency && <span><i className="ti ti-map-2" /> {l.constituency}</span>}
                      {l.ward         && <span><i className="ti ti-map-pin" /> {l.ward}</span>}
                      <span><i className="ti ti-building-community" /> {l.projectCount} projects</span>
                      <span><i className="ti ti-file-description" /> {l.reportCount} citizen reports</span>
                      {l.disputedCount > 0 && (
                        <span style={{ color: "#C1392B" }}>
                          <i className="ti ti-alert-circle" /> {l.disputedCount} disputed
                        </span>
                      )}
                    </div>
                  </div>

                  <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}>
                    <div style={{ fontSize: 11, color: "var(--color-text-tertiary)" }}>Accountability</div>
                    <div style={{ fontSize: 20, fontWeight: 700, fontFamily: "Merriweather, serif",
                      color: l.accountabilityScore >= 70 ? "#1A7A4A" : l.accountabilityScore >= 45 ? "#E8A020" : "#C1392B" }}>
                      {l.accountabilityScore}
                      <span style={{ fontSize: 11, fontWeight: 400, color: "var(--color-text-tertiary)" }}>/100</span>
                    </div>
                    <i className={`ti ${isOpen ? "ti-chevron-up" : "ti-chevron-down"}`} style={{ color: "var(--color-text-tertiary)", fontSize: 14 }} />
                  </div>
                </div>

                {/* Expanded: bio + project breakdown */}
                {isOpen && (
                  <div style={{ borderTop: "0.5px solid var(--color-border-tertiary)", padding: "14px 16px" }}>
                    {l.bio && (
                      <p style={{ fontSize: 13, color: "var(--color-text-secondary)", marginBottom: 14, lineHeight: 1.6 }}>
                        {l.bio}
                      </p>
                    )}
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
                      {[
                        { label: "Total projects", value: l.projectCount, color: "var(--color-text-primary)" },
                        { label: "Disputed projects", value: l.disputedCount, color: l.disputedCount > 0 ? "#C1392B" : "var(--color-text-primary)" },
                        { label: "Corruption signals", value: l.corruptionFlags, color: l.corruptionFlags > 0 ? "#D4760A" : "#1A7A4A" },
                      ].map((stat) => (
                        <div key={stat.label} style={{ textAlign: "center", padding: "10px", background: "var(--color-background-secondary)", borderRadius: "var(--border-radius-md)" }}>
                          <div style={{ fontSize: 20, fontWeight: 700, color: stat.color, fontFamily: "Merriweather, serif" }}>{stat.value}</div>
                          <div style={{ fontSize: 11, color: "var(--color-text-tertiary)", marginTop: 2 }}>{stat.label}</div>
                        </div>
                      ))}
                    </div>
                    <div style={{ marginTop: 12, display: "flex", gap: 8 }}>
                      <Link className="cm-btn-ghost" style={{ fontSize: 12, display: "inline-flex", alignItems: "center", gap: 6 }}
                        href={`/projects?createdBy=${l.id}`}>
                        <i className="ti ti-building-community" /> View projects
                      </Link>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </main>
  );
}
