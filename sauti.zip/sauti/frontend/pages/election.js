/**
 * Election Cycle + Manifesto Tracking Page
 *
 * Architecture role: the dedicated UI for the Election Stakeholder module.
 *
 * Three panels, gated by role and cycle state:
 *   1. Active Cycle Banner  — always visible; shows current phase + days remaining
 *   2. Manifesto Tracker   — public read; leaders add promises; all can track delivery
 *   3. Cycle Admin         — admin only; create / activate / phase-advance cycles
 */

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  getElectionCycles,
  getActiveElectionCycle,
  createElectionCycle,
  activateElectionCycle,
  deactivateElectionCycle,
  updateElectionCycle,
  getManifestoPromises,
  createManifestoPromise,
  updateManifestoPromise,
  getElectionCycleSummary,
} from "../lib/api";

function getUser() {
  if (typeof window === "undefined") return null;
  try { return JSON.parse(localStorage.getItem("sauti_user")); } catch { return null; }
}

// ── Design constants ──────────────────────────────────────────────────────────
const PHASES = ["pre_election", "campaign", "polling", "post_election", "transition"];
const PHASE_COLORS = {
  pre_election:  { bg: "#E6F1FB", color: "#0C447C", label: "Pre-Election" },
  campaign:      { bg: "#FAEEDA", color: "#633806", label: "Campaign" },
  polling:       { bg: "#FCEBEB", color: "#A32D2D", label: "Polling" },
  post_election: { bg: "#E1F5EE", color: "#085041", label: "Post-Election" },
  transition:    { bg: "#EEEDFE", color: "#3C3489", label: "Transition" },
};
const STATUS_COLORS = {
  promised:             { bg: "#F3F4F6", color: "#374151", label: "Promised" },
  in_progress:          { bg: "#E6F1FB", color: "#0C447C", label: "In Progress" },
  partially_delivered:  { bg: "#FAEEDA", color: "#633806", label: "Partial" },
  delivered:            { bg: "#E1F5EE", color: "#085041", label: "Delivered" },
  broken:               { bg: "#FCEBEB", color: "#A32D2D", label: "Broken" },
};
const CATEGORIES = ["water", "roads", "health", "education", "security", "other"];

// ── Modals ────────────────────────────────────────────────────────────────────
function CreateCycleModal({ onClose, onSubmit }) {
  const [form, setForm] = useState({ name: "", region: "", startDate: "", endDate: "", phase: "pre_election", description: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const handleSubmit = async () => {
    if (!form.name || !form.startDate || !form.endDate) { setError("Name, start and end dates are required."); return; }
    setLoading(true);
    try { await onSubmit(form); onClose(); }
    catch (e) { setError(e.message); setLoading(false); }
  };

  return (
    <div className="cm-modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="cm-modal">
        <div className="cm-modal-title">Create election cycle</div>
        <div className="cm-form-grid">
          <div className="cm-field"><label className="cm-label">Cycle name *</label><input className="cm-input" value={form.name} onChange={set("name")} placeholder="e.g. Kenyan General Election 2027" /></div>
          <div className="cm-form-row">
            <div className="cm-field"><label className="cm-label">Start date *</label><input className="cm-input" type="date" value={form.startDate} onChange={set("startDate")} /></div>
            <div className="cm-field"><label className="cm-label">End date *</label><input className="cm-input" type="date" value={form.endDate} onChange={set("endDate")} /></div>
          </div>
          <div className="cm-form-row">
            <div className="cm-field">
              <label className="cm-label">Initial phase</label>
              <select className="cm-select" value={form.phase} onChange={set("phase")}>
                {PHASES.map(p => <option key={p} value={p}>{PHASE_COLORS[p].label}</option>)}
              </select>
            </div>
            <div className="cm-field"><label className="cm-label">Region (optional)</label><input className="cm-input" value={form.region} onChange={set("region")} placeholder="e.g. Westlands" /></div>
          </div>
          <div className="cm-field"><label className="cm-label">Description</label><textarea className="cm-input cm-textarea" value={form.description} onChange={set("description")} placeholder="Brief description of the cycle scope…" /></div>
        </div>
        {error && <p className="cm-error">{error}</p>}
        <div className="cm-modal-footer">
          <button className="cm-btn-ghost" onClick={onClose}>Cancel</button>
          <button className="cm-btn-primary" onClick={handleSubmit} disabled={loading}>{loading ? "Creating…" : "Create cycle"}</button>
        </div>
      </div>
    </div>
  );
}

function CreatePromiseModal({ activeCycle, onClose, onSubmit }) {
  const [form, setForm] = useState({ title: "", description: "", category: "other", region: "", targetDate: "", budgetCommitted: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const handleSubmit = async () => {
    if (!form.title || !form.description) { setError("Title and description are required."); return; }
    setLoading(true);
    try { await onSubmit(form); onClose(); }
    catch (e) { setError(e.message); setLoading(false); }
  };

  return (
    <div className="cm-modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="cm-modal">
        <div className="cm-modal-title">Add manifesto promise</div>
        {activeCycle && (
          <div style={{ fontSize: 12, background: "#E1F5EE", color: "#085041", padding: "6px 10px", borderRadius: 6, marginBottom: 4 }}>
            <i className="ti ti-check" /> Linked to: <strong>{activeCycle.name}</strong> · {PHASE_COLORS[activeCycle.phase]?.label}
          </div>
        )}
        <div className="cm-form-grid">
          <div className="cm-field"><label className="cm-label">Promise title *</label><input className="cm-input" value={form.title} onChange={set("title")} placeholder="e.g. Tarmac all roads in Kangemi ward" /></div>
          <div className="cm-field"><label className="cm-label">Description *</label><textarea className="cm-input cm-textarea" value={form.description} onChange={set("description")} placeholder="Specific commitment and delivery plan…" /></div>
          <div className="cm-form-row">
            <div className="cm-field">
              <label className="cm-label">Category</label>
              <select className="cm-select" value={form.category} onChange={set("category")}>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="cm-field"><label className="cm-label">Region</label><input className="cm-input" value={form.region} onChange={set("region")} placeholder="e.g. Kangemi ward" /></div>
          </div>
          <div className="cm-form-row">
            <div className="cm-field"><label className="cm-label">Target delivery date</label><input className="cm-input" type="date" value={form.targetDate} onChange={set("targetDate")} /></div>
            <div className="cm-field"><label className="cm-label">Budget committed (KSh)</label><input className="cm-input" type="number" value={form.budgetCommitted} onChange={set("budgetCommitted")} placeholder="e.g. 45000000" /></div>
          </div>
        </div>
        {error && <p className="cm-error">{error}</p>}
        <div className="cm-modal-footer">
          <button className="cm-btn-ghost" onClick={onClose}>Cancel</button>
          <button className="cm-btn-primary" onClick={handleSubmit} disabled={loading}>{loading ? "Saving…" : "Add promise"}</button>
        </div>
      </div>
    </div>
  );
}

// ── Sub-components ────────────────────────────────────────────────────────────
function CycleBanner({ cycle, onPhaseChange, isAdmin }) {
  if (!cycle || !cycle.activeFlag) {
    return (
      <div style={{ background: "var(--color-background-secondary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-lg)", padding: "14px 16px", display: "flex", alignItems: "center", gap: 12 }}>
        <i className="ti ti-calendar-off" style={{ fontSize: 22, color: "var(--color-text-tertiary)" }} />
        <div>
          <div style={{ fontSize: 14, fontWeight: 500, color: "var(--color-text-secondary)" }}>No active election cycle</div>
          <div style={{ fontSize: 12, color: "var(--color-text-tertiary)" }}>Election stakeholder features are disabled. {isAdmin ? "Create and activate a cycle below." : "Contact an admin to activate an election cycle."}</div>
        </div>
      </div>
    );
  }

  const phaseStyle = PHASE_COLORS[cycle.phase] || PHASE_COLORS.pre_election;
  const daysTotal = Math.max(1, Math.ceil((new Date(cycle.endDate) - new Date(cycle.startDate)) / 86400000));
  const daysGone  = Math.ceil((new Date() - new Date(cycle.startDate)) / 86400000);
  const pct       = Math.min(100, Math.max(0, Math.round((daysGone / daysTotal) * 100)));
  const daysLeft  = Math.max(0, Math.ceil((new Date(cycle.endDate) - new Date()) / 86400000));

  return (
    <div className="cm-townhall-card" style={{ display: "block" }}>
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12, marginBottom: 10 }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
            <div className="cm-live-dot" />
            <span style={{ fontSize: 10, fontWeight: 600, letterSpacing: "0.8px", textTransform: "uppercase", color: "#1A7A4A" }}>Active election cycle</span>
          </div>
          <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 2 }}>{cycle.name}</div>
          {cycle.region && <div style={{ fontSize: 12, color: "rgba(255,255,255,0.5)" }}>{cycle.region}</div>}
        </div>
        <span style={{ fontSize: 11, fontWeight: 600, padding: "4px 10px", borderRadius: 6, background: phaseStyle.bg, color: phaseStyle.color, whiteSpace: "nowrap" }}>
          {phaseStyle.label}
        </span>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 12 }}>
        {[
          { label: "Start", value: new Date(cycle.startDate).toLocaleDateString() },
          { label: "End", value: new Date(cycle.endDate).toLocaleDateString() },
          { label: "Days remaining", value: `${daysLeft}d` },
        ].map(s => (
          <div key={s.label} style={{ background: "rgba(255,255,255,0.06)", borderRadius: 6, padding: "8px 10px" }}>
            <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 2 }}>{s.label}</div>
            <div style={{ fontSize: 13, fontWeight: 600 }}>{s.value}</div>
          </div>
        ))}
      </div>

      <div style={{ marginBottom: isAdmin ? 12 : 0 }}>
        <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", marginBottom: 4 }}>Cycle progress — {pct}%</div>
        <div style={{ height: 4, background: "rgba(255,255,255,0.1)", borderRadius: 2, overflow: "hidden" }}>
          <div style={{ height: 4, width: `${pct}%`, background: "#1A7A4A", borderRadius: 2 }} />
        </div>
      </div>

      {isAdmin && (
        <div style={{ marginTop: 12 }}>
          <div style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.5px" }}>Advance phase</div>
          <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
            {PHASES.map(p => (
              <button key={p} onClick={() => onPhaseChange(cycle.id, p)}
                style={{ fontSize: 11, padding: "4px 8px", borderRadius: 4, border: "none", cursor: "pointer",
                  background: cycle.phase === p ? phaseStyle.bg : "rgba(255,255,255,0.08)",
                  color: cycle.phase === p ? phaseStyle.color : "rgba(255,255,255,0.6)",
                  fontWeight: cycle.phase === p ? 600 : 400 }}>
                {PHASE_COLORS[p].label}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ManifestoTable({ promises, user, onUpdateStatus }) {
  if (promises.length === 0) {
    return <div className="cm-empty"><i className="ti ti-list-check" />No manifesto promises yet.</div>;
  }

  const STATUSES = ["promised", "in_progress", "partially_delivered", "delivered", "broken"];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      {promises.map(p => {
        const st = STATUS_COLORS[p.status] || STATUS_COLORS.promised;
        const score = Math.round((p.computedDeliveryScore || 0) * 100);
        const overdue = p.targetDate && new Date(p.targetDate) < new Date() && p.status !== "delivered";

        return (
          <div key={p.id} className="cm-card">
            <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 12, alignItems: "start" }}>
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                  <span style={{ fontSize: 14, fontWeight: 500 }}>{p.title}</span>
                  <span style={{ fontSize: 11, padding: "2px 7px", borderRadius: 4, background: st.bg, color: st.color, fontWeight: 500 }}>{st.label}</span>
                  {overdue && <span style={{ fontSize: 11, padding: "2px 7px", borderRadius: 4, background: "#FCEBEB", color: "#A32D2D", fontWeight: 500 }}><i className="ti ti-clock-x" style={{ fontSize: 10 }} /> Overdue</span>}
                </div>
                <p style={{ fontSize: 12, color: "var(--color-text-secondary)", lineHeight: 1.5, marginBottom: 8 }}>{p.description}</p>
                <div style={{ fontSize: 12, color: "var(--color-text-secondary)", display: "flex", gap: 12, flexWrap: "wrap" }}>
                  {p.category && <span className={`cm-tag tag-${p.category}`}>{p.category}</span>}
                  {p.region && <span><i className="ti ti-map-pin" /> {p.region}</span>}
                  {p.targetDate && <span><i className="ti ti-calendar" /> {new Date(p.targetDate).toLocaleDateString()}</span>}
                  {p.budgetCommitted && <span><i className="ti ti-coin" /> KSh {(p.budgetCommitted / 1e6).toFixed(1)}M committed</span>}
                  {p.electionCycle && <span><i className="ti ti-refresh" /> {p.electionCycle.name}</span>}
                </div>
                <div style={{ marginTop: 8 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "var(--color-text-tertiary)", marginBottom: 3 }}>
                    <span>Delivery score</span><span style={{ fontWeight: 600, color: score >= 70 ? "#1A7A4A" : score >= 40 ? "#E8A020" : "#C1392B" }}>{score}%</span>
                  </div>
                  <div className="cm-progress-bar">
                    <div className="cm-progress-fill" style={{ width: `${score}%`, background: score >= 70 ? "#1A7A4A" : score >= 40 ? "#E8A020" : "#C1392B" }} />
                  </div>
                </div>
              </div>

              {/* Status changer — leader (own) or admin */}
              {user && (user.role === "admin" || (user.role === "leader" && p.leaderId === user.id)) && (
                <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                  <div style={{ fontSize: 10, color: "var(--color-text-tertiary)", textTransform: "uppercase", letterSpacing: "0.5px" }}>Update</div>
                  <select className="cm-select" style={{ fontSize: 11, padding: "4px 6px", width: 140 }}
                    value={p.status}
                    onChange={e => onUpdateStatus(p.id, e.target.value)}>
                    {STATUSES.map(s => <option key={s} value={s}>{STATUS_COLORS[s].label}</option>)}
                  </select>
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────
export default function ElectionPage() {
  const user = getUser();
  const isAdmin       = user?.role === "admin";
  const isLeader      = user?.role === "leader";
  const isStakeholder = user?.role === "election_stakeholder";

  const [activeCycle,  setActiveCycle]  = useState(null);
  const [allCycles,    setAllCycles]    = useState([]);
  const [promises,     setPromises]     = useState([]);
  const [cycleSummary, setCycleSummary] = useState(null);
  const [loading,      setLoading]      = useState(true);
  const [tab,          setTab]          = useState("tracker"); // tracker | cycles | admin
  const [filterStatus, setFilterStatus] = useState("");
  const [filterCat,    setFilterCat]    = useState("");
  const [showCycleModal,   setShowCycleModal]   = useState(false);
  const [showPromiseModal, setShowPromiseModal] = useState(false);
  const [error, setError] = useState("");

  const load = async () => {
    setLoading(true);
    try {
      const [cycle, cycles, proms] = await Promise.all([
        getActiveElectionCycle().catch(() => null),
        getElectionCycles().catch(() => []),
        getManifestoPromises({ ...(filterStatus ? { status: filterStatus } : {}), ...(filterCat ? { category: filterCat } : {}) }).catch(() => []),
      ]);
      setActiveCycle(cycle?.activeFlag ? cycle : null);
      setAllCycles(Array.isArray(cycles) ? cycles : []);
      setPromises(Array.isArray(proms) ? proms : []);

      if (cycle?.activeFlag && cycle.id) {
        getElectionCycleSummary(cycle.id).then(setCycleSummary).catch(() => {});
      }
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [filterStatus, filterCat]);

  const handleCreateCycle   = async (form) => { await createElectionCycle(form); load(); };
  const handleActivate      = async (id) => { try { await activateElectionCycle(id); load(); } catch(e) { setError(e.message); } };
  const handleDeactivate    = async (id) => { try { await deactivateElectionCycle(id); load(); } catch(e) { setError(e.message); } };
  const handlePhaseChange   = async (id, phase) => { try { await updateElectionCycle(id, { phase }); load(); } catch(e) { setError(e.message); } };
  const handleCreatePromise = async (form) => { await createManifestoPromise(form); load(); };
  const handleUpdateStatus  = async (id, status) => { try { await updateManifestoPromise(id, { status }); load(); } catch(e) { setError(e.message); } };

  const DEMO_PROMISES = [
    { id: "d1", title: "Tarmac all roads in Kangemi ward within 18 months", description: "Complete tarmacking of 12 km of murram roads identified during ward visit.", category: "roads", region: "Kangemi ward", targetDate: new Date(Date.now() + 30 * 86400000).toISOString(), budgetCommitted: 45000000, status: "in_progress", computedDeliveryScore: 0.4, leaderId: "demo", electionCycle: { name: "General Election 2027" } },
    { id: "d2", title: "Construct 3 new boreholes in Loresho", description: "Solve chronic water shortage affecting 4,000 households.", category: "water", region: "Loresho ward", targetDate: new Date(Date.now() - 10 * 86400000).toISOString(), budgetCommitted: 9000000, status: "promised", computedDeliveryScore: 0, leaderId: "demo", electionCycle: { name: "General Election 2027" } },
    { id: "d3", title: "Hire 20 additional teachers for public schools", description: "Address teacher shortage in 8 primary schools.", category: "education", region: "Westlands", targetDate: new Date(Date.now() + 90 * 86400000).toISOString(), budgetCommitted: 24000000, status: "delivered", computedDeliveryScore: 1.0, leaderId: "demo", electionCycle: { name: "General Election 2027" } },
    { id: "d4", title: "Upgrade Westlands Health Centre to Level 4", description: "Add maternity wing, expand outpatient capacity.", category: "health", region: "Westlands", targetDate: new Date(Date.now() + 180 * 86400000).toISOString(), budgetCommitted: 78000000, status: "partially_delivered", computedDeliveryScore: 0.6, leaderId: "demo", electionCycle: { name: "General Election 2027" } },
    { id: "d5", title: "Install 200 streetlights across all 6 wards", description: "Solar-powered streetlights for community safety.", category: "security", region: "Westlands", targetDate: new Date(Date.now() - 45 * 86400000).toISOString(), budgetCommitted: 18000000, status: "broken", computedDeliveryScore: 0, leaderId: "demo", electionCycle: { name: "General Election 2027" } },
  ];

  const displayPromises = promises.length > 0 ? promises : DEMO_PROMISES;
  const filteredPromises = displayPromises
    .filter(p => !filterStatus || p.status === filterStatus)
    .filter(p => !filterCat    || p.category === filterCat);

  // Stats for summary bar
  const total     = displayPromises.length;
  const delivered = displayPromises.filter(p => p.status === "delivered").length;
  const broken    = displayPromises.filter(p => p.status === "broken").length;
  const overdue   = displayPromises.filter(p => p.targetDate && new Date(p.targetDate) < new Date() && p.status !== "delivered").length;
  const avgScore  = total ? Math.round(displayPromises.reduce((s, p) => s + (p.computedDeliveryScore || 0), 0) / total * 100) : 0;

  return (
    <main className="cm-page">
      <div className="cm-header-row">
        <div>
          <div className="cm-page-title">Election Cycle & Manifesto Tracker</div>
          <div className="cm-page-sub">Time-bound accountability — promises made vs promises kept</div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          {isLeader && activeCycle && (
            <button className="cm-btn-primary" onClick={() => setShowPromiseModal(true)}>
              <i className="ti ti-plus" /> Add promise
            </button>
          )}
          {isAdmin && (
            <button className="cm-btn-ghost" onClick={() => setShowCycleModal(true)}>
              <i className="ti ti-calendar-plus" /> New cycle
            </button>
          )}
        </div>
      </div>

      {/* Active cycle banner */}
      <CycleBanner cycle={activeCycle} onPhaseChange={handlePhaseChange} isAdmin={isAdmin} />

      {error && (
        <div className="cm-alert-banner">
          <i className="ti ti-alert-triangle" style={{ color: "#A32D2D", fontSize: 16, flexShrink: 0 }} />
          <div className="cm-alert-text">{error}</div>
        </div>
      )}

      {/* Summary stats */}
      {total > 0 && (
        <div className="cm-metrics" style={{ gridTemplateColumns: "repeat(5, 1fr)" }}>
          {[
            { label: "Total promises", value: total, color: "var(--color-text-primary)" },
            { label: "Delivered", value: delivered, color: "#1A7A4A" },
            { label: "Broken", value: broken, color: "#C1392B" },
            { label: "Overdue", value: overdue, color: "#E8A020" },
            { label: "Avg delivery score", value: `${avgScore}%`, color: avgScore >= 70 ? "#1A7A4A" : avgScore >= 40 ? "#E8A020" : "#C1392B" },
          ].map(s => (
            <div key={s.label} className="cm-metric">
              <div className="cm-metric-label">{s.label}</div>
              <div className="cm-metric-value" style={{ color: s.color, fontSize: 22 }}>{s.value}</div>
            </div>
          ))}
        </div>
      )}

      {/* Tabs */}
      <div style={{ display: "flex", borderBottom: "0.5px solid var(--color-border-tertiary)", gap: 0 }}>
        {[
          { id: "tracker", label: "Manifesto Tracker", icon: "ti-list-check" },
          { id: "cycles",  label: "Election Cycles",   icon: "ti-calendar" },
          ...(isAdmin ? [{ id: "admin", label: "Admin", icon: "ti-settings" }] : []),
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            style={{ padding: "10px 16px", border: "none", background: "none", cursor: "pointer",
              fontSize: 13, fontFamily: "IBM Plex Sans, sans-serif", display: "flex", alignItems: "center", gap: 6,
              color: tab === t.id ? "#1A7A4A" : "var(--color-text-secondary)",
              borderBottom: tab === t.id ? "2px solid #1A7A4A" : "2px solid transparent",
              fontWeight: tab === t.id ? 500 : 400, marginBottom: -1 }}>
            <i className={`ti ${t.icon}`} style={{ fontSize: 14 }} />
            {t.label}
          </button>
        ))}
      </div>

      {/* ── TRACKER TAB ── */}
      {tab === "tracker" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <div className="cm-chips">
              {["", "promised", "in_progress", "partially_delivered", "delivered", "broken"].map(s => (
                <button key={s} className={`cm-chip ${filterStatus === s ? "active" : ""}`} onClick={() => setFilterStatus(s)}>
                  {s ? STATUS_COLORS[s].label : "All statuses"}
                </button>
              ))}
            </div>
            <select className="cm-select" style={{ width: 130, fontSize: 12 }} value={filterCat} onChange={e => setFilterCat(e.target.value)}>
              <option value="">All categories</option>
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          {loading ? <div className="cm-loading">Loading promises…</div> :
            <ManifestoTable promises={filteredPromises} user={user} onUpdateStatus={handleUpdateStatus} />
          }
        </div>
      )}

      {/* ── CYCLES TAB ── */}
      {tab === "cycles" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {allCycles.length === 0 ? (
            <div className="cm-empty"><i className="ti ti-calendar-off" />No election cycles defined yet.{isAdmin && " Create one above."}</div>
          ) : allCycles.map(c => {
            const phaseStyle = PHASE_COLORS[c.phase] || PHASE_COLORS.pre_election;
            const daysLeft = Math.max(0, Math.ceil((new Date(c.endDate) - new Date()) / 86400000));
            return (
              <div key={c.id} className="cm-card">
                <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12 }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                      {c.activeFlag && <div className="cm-live-dot" />}
                      <span style={{ fontSize: 14, fontWeight: 600 }}>{c.name}</span>
                      <span style={{ fontSize: 11, padding: "2px 7px", borderRadius: 4, background: phaseStyle.bg, color: phaseStyle.color, fontWeight: 500 }}>{phaseStyle.label}</span>
                      {c.activeFlag && <span style={{ fontSize: 11, padding: "2px 7px", borderRadius: 4, background: "#E1F5EE", color: "#085041", fontWeight: 600 }}>ACTIVE</span>}
                    </div>
                    <div style={{ fontSize: 12, color: "var(--color-text-secondary)", display: "flex", gap: 12, flexWrap: "wrap" }}>
                      {c.region && <span><i className="ti ti-map-2" /> {c.region}</span>}
                      <span><i className="ti ti-calendar" /> {new Date(c.startDate).toLocaleDateString()} → {new Date(c.endDate).toLocaleDateString()}</span>
                      <span><i className="ti ti-clock" /> {daysLeft}d remaining</span>
                      <span><i className="ti ti-list-check" /> {c._count?.manifestoPromises || 0} promises</span>
                    </div>
                    {c.description && <p style={{ fontSize: 12, color: "var(--color-text-tertiary)", marginTop: 6 }}>{c.description}</p>}
                  </div>
                  {isAdmin && (
                    <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
                      {!c.activeFlag
                        ? <button className="cm-btn-primary" style={{ fontSize: 12, padding: "5px 10px" }} onClick={() => handleActivate(c.id)}><i className="ti ti-player-play" /> Activate</button>
                        : <button className="cm-btn-ghost"  style={{ fontSize: 12, padding: "5px 10px" }} onClick={() => handleDeactivate(c.id)}>Deactivate</button>
                      }
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── ADMIN TAB ── */}
      {tab === "admin" && isAdmin && (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div className="cm-card">
            <div className="cm-section-title" style={{ marginBottom: 12 }}>Cycle summary</div>
            {cycleSummary ? (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
                {[
                  { label: "Total promises", value: cycleSummary.summary.totalPromises },
                  { label: "Delivered", value: cycleSummary.summary.deliveredCount, color: "#1A7A4A" },
                  { label: "Broken", value: cycleSummary.summary.brokenCount, color: "#C1392B" },
                  { label: "Avg delivery score", value: `${cycleSummary.summary.avgDeliveryScore}%` },
                  { label: "Phase", value: PHASE_COLORS[cycleSummary.cycle.phase]?.label },
                  { label: "Days remaining", value: `${cycleSummary.cycle.daysRemaining}d` },
                ].map(s => (
                  <div key={s.label} style={{ padding: 12, background: "var(--color-background-secondary)", borderRadius: "var(--border-radius-md)" }}>
                    <div style={{ fontSize: 11, color: "var(--color-text-tertiary)", marginBottom: 4 }}>{s.label}</div>
                    <div style={{ fontSize: 18, fontWeight: 700, fontFamily: "Merriweather, serif", color: s.color || "var(--color-text-primary)" }}>{s.value}</div>
                  </div>
                ))}
              </div>
            ) : <p style={{ fontSize: 13, color: "var(--color-text-tertiary)" }}>No active cycle to summarise. Activate a cycle to see stats.</p>}
          </div>

          <div className="cm-narrative">
            <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.8px", textTransform: "uppercase", color: "#0A4A32", marginBottom: 6 }}>
              <i className="ti ti-shield-check" /> Election module rules
            </div>
            <ul style={{ fontSize: 13, lineHeight: 1.8, paddingLeft: 16 }}>
              <li>Oversight reports and manifesto promises can only be <strong>created</strong> when an election cycle is active.</li>
              <li>Only one cycle can be active at a time — activating a new one auto-deactivates the current one.</li>
              <li>Phase transitions: <strong>pre_election → campaign → polling → post_election → transition</strong></li>
              <li>Leaders can only update their own promises; election_stakeholders can annotate evidence but not change status.</li>
              <li>Linking a promise to a project auto-syncs the delivery score from the Verification Engine.</li>
              <li>All phase changes are recorded in the immutable Audit Log.</li>
            </ul>
          </div>
        </div>
      )}

      {showCycleModal   && <CreateCycleModal onClose={() => setShowCycleModal(false)} onSubmit={handleCreateCycle} />}
      {showPromiseModal && <CreatePromiseModal activeCycle={activeCycle} onClose={() => setShowPromiseModal(false)} onSubmit={handleCreatePromise} />}
    </main>
  );
}
