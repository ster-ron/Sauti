import { useEffect, useState } from "react";
import Link from "next/link";
import { getProjects, getReports, createReport } from "../lib/api";
import EvidenceUpload from "../components/EvidenceUpload";
import MediaGallery from "../components/MediaGallery";

const STATUS_FILL = { verified: "fill-green", partial: "fill-amber", disputed: "fill-red", unverified: "fill-blue" };
const STATUS_PCT  = { verified: 88, partial: 51, disputed: 12, unverified: 35 };

function getTagClass(category) {
  const map = { water: "tag-water", roads: "tag-roads", health: "tag-health", education: "tag-edu", security: "tag-security" };
  return map[category] || "tag-other";
}

function ReportModal({ onClose, onSubmit }) {
  const [form, setForm] = useState({ content: "", location: "", isAnonymous: false });
  const [mediaIds, setMediaIds] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async () => {
    if (!form.content.trim()) { setError("Please describe what you observed."); return; }
    setLoading(true);
    try {
      await onSubmit({ ...form, mediaIds });
      onClose();
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  };

  return (
    <div className="cm-modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="cm-modal">
        <div className="cm-modal-title">Submit citizen report</div>
        <p style={{ fontSize: 12, color: "var(--color-text-secondary)" }}>
          Reports are reviewed by the Verification Engine and contribute to project accountability scores.
          Photo and video evidence is weighted more heavily.
        </p>
        <div className="cm-field">
          <label className="cm-label">What did you observe? *</label>
          <textarea className="cm-input cm-textarea" value={form.content}
            onChange={e => setForm({...form, content: e.target.value})}
            placeholder="Describe what you saw at the project site..." />
        </div>
        <div className="cm-field">
          <label className="cm-label">Location</label>
          <input className="cm-input" value={form.location} onChange={e => setForm({...form, location: e.target.value})} placeholder="e.g. Kangemi ward" />
        </div>
        <div className="cm-field">
          <label className="cm-label">Photo / video evidence</label>
          <EvidenceUpload onUploaded={setMediaIds} disabled={loading} />
          {mediaIds.length > 0 && (
            <p style={{ fontSize: 11, color: "#1A7A4A", marginTop: 4 }}>
              <i className="ti ti-check" /> {mediaIds.length} file{mediaIds.length > 1 ? "s" : ""} ready to attach
            </p>
          )}
        </div>
        <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, cursor: "pointer" }}>
          <input type="checkbox" checked={form.isAnonymous} onChange={e => setForm({...form, isAnonymous: e.target.checked})} />
          Submit anonymously
        </label>
        {error && <p className="cm-error">{error}</p>}
        <div className="cm-modal-footer">
          <button className="cm-btn-ghost" onClick={onClose}>Cancel</button>
          <button className="cm-btn-primary" onClick={handleSubmit} disabled={loading}>
            {loading ? "Submitting..." : "Submit report"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [projects, setProjects] = useState([]);
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);

  const load = () =>
    Promise.all([getProjects(), getReports()])
      .then(([p, r]) => { setProjects(p); setReports(r); })
      .catch(console.error)
      .finally(() => setLoading(false));

  useEffect(() => { load(); }, []);

  const handleReport = async (form) => {
    await createReport(form);
    load();
  };

  const disputed = projects.filter(p => p.verificationStatus === "disputed").length;
  const budget = projects.reduce((s, p) => s + (p.budget || 0), 0);

  if (loading) return <div className="cm-loading"><i className="ti ti-loader" style={{ fontSize: 24, display: "block", marginBottom: 8 }} />Loading dashboard…</div>;

  return (
    <main className="cm-page">
      <div className="cm-header-row">
        <div>
          <div className="cm-page-title">Westlands Constituency</div>
          <div className="cm-page-sub">Nairobi County · Updated just now · 2,341 active citizens</div>
        </div>
        <button className="cm-btn-primary" onClick={() => setShowModal(true)}>
          <i className="ti ti-plus" /> Submit report
        </button>
      </div>

      <div className="cm-metrics">
        <div className="cm-metric">
          <div className="cm-metric-label"><i className="ti ti-building-community" /> Active projects</div>
          <div className="cm-metric-value">{projects.length || 24}</div>
          <div className="cm-metric-delta delta-up"><i className="ti ti-arrow-up" style={{ fontSize: 11 }} /> 3 new this month</div>
        </div>
        <div className="cm-metric">
          <div className="cm-metric-label"><i className="ti ti-alert-circle" /> Disputed claims</div>
          <div className="cm-metric-value" style={{ color: "#C1392B" }}>{disputed || 7}</div>
          <div className="cm-metric-delta delta-down"><i className="ti ti-arrow-up" style={{ fontSize: 11 }} /> 2 escalated</div>
        </div>
        <div className="cm-metric">
          <div className="cm-metric-label"><i className="ti ti-coin" /> Budget tracked</div>
          <div className="cm-metric-value" style={{ fontSize: budget ? 16 : 22 }}>
            {budget ? `KSh ${(budget/1e6).toFixed(0)}M` : "KSh 480M"}
          </div>
          <div className="cm-metric-delta" style={{ color: "var(--color-text-tertiary)" }}>FY 2024–25</div>
        </div>
        <div className="cm-metric">
          <div className="cm-metric-label"><i className="ti ti-users" /> Citizen reports</div>
          <div className="cm-metric-value">{reports.length || 1204}</div>
          <div className="cm-metric-delta delta-up"><i className="ti ti-arrow-up" style={{ fontSize: 11 }} /> 89 this week</div>
        </div>
      </div>

      <div className="cm-alert-banner">
        <i className="ti ti-alert-triangle" style={{ color: "#A32D2D", fontSize: 16, flexShrink: 0, marginTop: 1 }} />
        <div className="cm-alert-text">
          <strong>Integrity flag:</strong> MP Kamau's Uthiru road project marked "completed" — 214 citizens report construction has not started. Verification in progress.
        </div>
      </div>

      <div>
        <div className="cm-section-title">
          Active projects
          <Link href="/projects"><span className="cm-section-link">View all →</span></Link>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {projects.length > 0 ? projects.slice(0, 5).map(p => (
            <div key={p.id} className="cm-project-card">
              <div>
                <div className="cm-project-title">{p.title}</div>
                <div className="cm-project-meta">
                  {p.budget && <span><i className="ti ti-coin" /> KSh {(p.budget/1e6).toFixed(1)}M</span>}
                  {p.location && <span><i className="ti ti-map-pin" /> {p.location}</span>}
                  <span className={`cm-tag ${getTagClass(p.category)}`}>{p.category}</span>
                </div>
                <div className="cm-progress-bar">
                  <div className={`cm-progress-fill ${STATUS_FILL[p.verificationStatus] || "fill-blue"}`}
                    style={{ width: `${STATUS_PCT[p.verificationStatus] || 40}%` }} />
                </div>
              </div>
              <span className={`cm-status status-${p.verificationStatus}`}>{p.verificationStatus}</span>
            </div>
          )) : (
            // Demo projects when backend is empty
            [
              { title: "Uthiru–Regen Road Rehabilitation", budget: 120, ward: "Uthiru ward", due: "Dec 2025", status: "disputed", pct: 12 },
              { title: "Kangemi Market Renovation", budget: 34, ward: "Kangemi ward", due: "Mar 2025", status: "verified", pct: 88 },
              { title: "Westlands Health Centre Expansion", budget: 78, ward: "Westlands ward", due: "Jun 2025", status: "partial", pct: 51 },
              { title: "Mountain View Primary School Desks", budget: 8.5, ward: "Parklands ward", due: "Delivered", status: "verified", pct: 100 },
              { title: "Loresho Borehole Water Project", budget: 19, ward: "Loresho ward", due: "Aug 2025", status: "unverified", pct: 35 },
            ].map(p => (
              <div key={p.title} className="cm-project-card">
                <div>
                  <div className="cm-project-title">{p.title}</div>
                  <div className="cm-project-meta">
                    <span><i className="ti ti-coin" /> KSh {p.budget}M</span>
                    <span><i className="ti ti-map-pin" /> {p.ward}</span>
                    <span><i className="ti ti-calendar" /> {p.due}</span>
                  </div>
                  <div className="cm-progress-bar">
                    <div className={`cm-progress-fill ${STATUS_FILL[p.status]}`} style={{ width: `${p.pct}%` }} />
                  </div>
                </div>
                <span className={`cm-status status-${p.status}`}>{p.status}</span>
              </div>
            ))
          )}
        </div>
      </div>

      <div>
        <div className="cm-section-title">
          Forum discussions
          <Link href="/forums"><span className="cm-section-link">View all →</span></Link>
        </div>
        <div className="cm-card" style={{ padding: "4px 14px" }}>
          {[
            { title: "Why is there still no clean water in Kangemi after 3 months of promises?", tag: "tag-water", tagLabel: "Water", replies: 142, upvotes: 312, ago: "2h ago" },
            { title: "Waiyaki Way potholes have caused 4 accidents this month — who is responsible?", tag: "tag-roads", tagLabel: "Roads", replies: 87, upvotes: 198, ago: "5h ago" },
            { title: "Health centre expansion — phase 2 construction crew missing for 2 weeks", tag: "tag-health", tagLabel: "Health", replies: 61, upvotes: 155, ago: "1d ago" },
            { title: "School desk delivery confirmed — Parklands parents verify 640 desks arrived", tag: "tag-edu", tagLabel: "Education", replies: 24, upvotes: 91, ago: "2d ago" },
          ].map((t, i) => (
            <Link key={i} href="/forums">
              <div className="cm-forum-item">
                <div className="cm-forum-title">{t.title}</div>
                <div className="cm-forum-meta">
                  <span className={`cm-tag ${t.tag}`}>{t.tagLabel}</span>
                  <span>{t.replies} replies</span>
                  <span>{t.upvotes} upvotes</span>
                  <span>{t.ago}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {showModal && <ReportModal onClose={() => setShowModal(false)} onSubmit={handleReport} />}
    </main>
  );
}
