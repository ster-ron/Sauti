import { useEffect, useState } from "react";
import Link from "next/link";
import { getProjects } from "../lib/api";
import { getSavedIds, toggleSaved } from "../lib/saved";

const STATUS_COLOR = { verified: "#1A7A4A", partial: "#E8A020", disputed: "#C1392B", unverified: "#9AA3AB" };

export default function SavedPage() {
  const [allProjects, setAllProjects] = useState([]);
  const [savedIds, setSavedIds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const refresh = () => setSavedIds(getSavedIds());

  useEffect(() => {
    refresh();
    getProjects()
      .then(setAllProjects)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));

    // Pick up changes made from the Projects page bookmark buttons without
    // a full reload, and stay in sync if the same project is unsaved from
    // another tab.
    window.addEventListener("sauti-saved-changed", refresh);
    return () => window.removeEventListener("sauti-saved-changed", refresh);
  }, []);

  const savedProjects = allProjects.filter((p) => savedIds.includes(p.id));

  return (
    <main className="cm-page">
      <div className="cm-header-row">
        <div>
          <div className="cm-page-title">Saved Projects</div>
          <div className="cm-page-sub">Bookmarked on this device — not synced across devices yet</div>
        </div>
      </div>

      {error && <p className="cm-error">{error}</p>}

      {loading ? (
        <div className="cm-loading">Loading…</div>
      ) : savedProjects.length === 0 ? (
        <div className="cm-empty">
          <i className="ti ti-bookmark" />
          Nothing saved yet. Tap the bookmark icon on any project in the{" "}
          <Link href="/projects" style={{ color: "var(--cm-green, #1A7A4A)" }}>Projects list</Link> to track it here.
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {savedProjects.map((p) => {
            const color = STATUS_COLOR[p.verificationStatus] || STATUS_COLOR.unverified;
            return (
              <div key={p.id} className="cm-card" style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 500 }}>{p.title}</div>
                  <div style={{ fontSize: 12, color: "var(--color-text-secondary)", marginTop: 4 }}>{p.description}</div>
                  <div style={{ fontSize: 11, marginTop: 6, fontWeight: 600, color, textTransform: "uppercase" }}>
                    {p.verificationStatus} · {Math.round((p.verificationScore || 0) * 100)}% confidence
                  </div>
                </div>
                <button
                  className="cm-btn-ghost"
                  style={{ fontSize: 11, padding: "4px 8px", whiteSpace: "nowrap" }}
                  onClick={() => { toggleSaved(p.id); refresh(); }}
                >
                  <i className="ti ti-bookmark-off" /> Remove
                </button>
              </div>
            );
          })}
        </div>
      )}
    </main>
  );
}
