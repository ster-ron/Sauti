import { useEffect, useState } from "react";
import { getIntelligenceSummary } from "../lib/api";

export default function IntelligencePage() {
  const [summary, setSummary] = useState(null);
  const [region, setRegion] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = () => {
    setLoading(true);
    getIntelligenceSummary(region ? { region } : {})
      .then(setSummary)
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  return (
    <main className="cm-page">
      <div className="cm-header-row">
        <div>
          <div className="cm-page-title">Civic Intelligence</div>
          <div className="cm-page-sub">Aggregate patterns across all projects and reports — leaders, stakeholders & admins only</div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <input className="cm-input" style={{ width: 180 }} placeholder="Filter by region" value={region} onChange={e => setRegion(e.target.value)} onKeyDown={e => e.key === "Enter" && load()} />
          <button className="cm-btn-primary" onClick={load}><i className="ti ti-refresh" /> Refresh</button>
        </div>
      </div>

      {error && (
        <div className="cm-alert-banner">
          <i className="ti ti-alert-triangle" style={{ color: "#A32D2D", fontSize: 16, flexShrink: 0 }} />
          <div className="cm-alert-text">{error} — Ensure you're logged in as a leader, admin, or election stakeholder.</div>
        </div>
      )}

      {loading ? <div className="cm-loading">Generating intelligence summary…</div> : summary && (
        <>
          <div className="cm-narrative">
            <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.8px", textTransform: "uppercase", color: "#0A4A32", marginBottom: 6, display: "flex", alignItems: "center", gap: 6 }}>
              <i className="ti ti-brain" /> AI narrative summary
            </div>
            {summary.narrative}
          </div>

          <div className="cm-stat-grid">
            <div className="cm-card">
              <div style={{ fontSize: 11, color: "var(--color-text-secondary)", marginBottom: 6 }}>Total projects</div>
              <div style={{ fontFamily: "Merriweather, serif", fontSize: 24, fontWeight: 700 }}>{summary.totals?.projects || 0}</div>
            </div>
            <div className="cm-card">
              <div style={{ fontSize: 11, color: "var(--color-text-secondary)", marginBottom: 6 }}>Total reports</div>
              <div style={{ fontFamily: "Merriweather, serif", fontSize: 24, fontWeight: 700 }}>{summary.totals?.reports || 0}</div>
            </div>
            <div className="cm-card">
              <div style={{ fontSize: 11, color: "var(--color-text-secondary)", marginBottom: 6 }}>Disputed projects</div>
              <div style={{ fontFamily: "Merriweather, serif", fontSize: 24, fontWeight: 700, color: "#C1392B" }}>{summary.highRiskProjects?.length || 0}</div>
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div className="cm-card">
              <div className="cm-section-title" style={{ marginBottom: 12 }}>Projects by region</div>
              {Object.entries(summary.byRegion || {}).length > 0 ? Object.entries(summary.byRegion).map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 0", borderBottom: "0.5px solid var(--color-border-tertiary)", fontSize: 13 }}>
                  <span>{k}</span>
                  <span style={{ fontWeight: 600, color: "#1A7A4A" }}>{v}</span>
                </div>
              )) : <p style={{ fontSize: 13, color: "var(--color-text-tertiary)" }}>No data yet.</p>}
            </div>

            <div className="cm-card">
              <div className="cm-section-title" style={{ marginBottom: 12 }}>Verification breakdown</div>
              {Object.entries(summary.byStatus || {}).length > 0 ? Object.entries(summary.byStatus).map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 0", borderBottom: "0.5px solid var(--color-border-tertiary)", fontSize: 13 }}>
                  <span className={`cm-status status-${k}`}>{k}</span>
                  <span style={{ fontWeight: 600 }}>{v}</span>
                </div>
              )) : <p style={{ fontSize: 13, color: "var(--color-text-tertiary)" }}>No data yet.</p>}
            </div>
          </div>

          <div className="cm-card">
            <div className="cm-section-title" style={{ marginBottom: 12 }}>Recurring complaint themes</div>
            {summary.repeatedComplaints?.length > 0 ? summary.repeatedComplaints.map(c => (
              <div key={c.phrase} className="cm-complaint-item">
                <span style={{ color: "var(--color-text-primary)" }}>"{c.phrase}"</span>
                <span style={{ fontSize: 12, fontWeight: 600, background: "#FCEBEB", color: "#A32D2D", padding: "2px 8px", borderRadius: 4 }}>{c.count}x</span>
              </div>
            )) : <p style={{ fontSize: 13, color: "var(--color-text-tertiary)" }}>No recurring themes detected yet.</p>}
          </div>

          {summary.highRiskProjects?.length > 0 && (
            <div>
              <div className="cm-alert-banner">
                <i className="ti ti-alert-triangle" style={{ color: "#A32D2D", fontSize: 16, flexShrink: 0, marginTop: 1 }} />
                <div>
                  <div className="cm-alert-text" style={{ fontWeight: 600, marginBottom: 4 }}>Flagged (disputed) projects</div>
                  {summary.highRiskProjects.map(p => (
                    <div key={p.id} className="cm-alert-text">{p.title}{p.region ? ` · ${p.region}` : ""}</div>
                  ))}
                </div>
              </div>
            </div>
          )}

          <div style={{ fontSize: 11, color: "var(--color-text-tertiary)", textAlign: "right" }}>
            Generated {new Date(summary.generatedAt).toLocaleString()}
          </div>
        </>
      )}
    </main>
  );
}
