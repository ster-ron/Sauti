import { useEffect, useState } from "react";
import Link from "next/link";
import { getMyReports } from "../lib/api";

export default function MyReportsPage() {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    getMyReports()
      .then(setReports)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <main className="cm-page">
      <div className="cm-header-row">
        <div>
          <div className="cm-page-title">My Reports</div>
          <div className="cm-page-sub">Everything you've submitted, including anonymous reports</div>
        </div>
      </div>

      {error && <p className="cm-error">{error}</p>}

      {loading ? (
        <div className="cm-loading">Loading your reports…</div>
      ) : reports.length === 0 ? (
        <div className="cm-empty">
          <i className="ti ti-file-description" />
          You haven't submitted any reports yet. Use "Report issue" in the sidebar, or report on a specific project from the{" "}
          <Link href="/projects" style={{ color: "var(--cm-green, #1A7A4A)" }}>Projects page</Link>.
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {reports.map((r) => (
            <div key={r.id} className="cm-card">
              <div style={{ display: "flex", justifyContent: "space-between", gap: 8, alignItems: "flex-start" }}>
                <p style={{ fontSize: 13, lineHeight: 1.5, flex: 1 }}>{r.content}</p>
                {r.isAnonymous && (
                  <span style={{ fontSize: 10, color: "#378ADD", whiteSpace: "nowrap", border: "1px solid #378ADD", borderRadius: 4, padding: "2px 6px" }}>
                    submitted anonymously
                  </span>
                )}
              </div>
              <div style={{ fontSize: 11, color: "var(--color-text-tertiary)", marginTop: 6, display: "flex", gap: 10, flexWrap: "wrap" }}>
                <span>{new Date(r.createdAt).toLocaleDateString()}</span>
                {r.location && <span><i className="ti ti-map-pin" /> {r.location}</span>}
                {r.project?.title && <span><i className="ti ti-building-community" /> {r.project.title}</span>}
                {r.imageUrl && <span><i className="ti ti-photo" /> photo attached</span>}
                {r.videoUrl && <span><i className="ti ti-video" /> video attached</span>}
              </div>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}
