/**
 * Geospatial Project Map
 *
 * Plots every project and citizen report that carries lat/lng coordinates.
 * Projects are colored by verificationStatus (the same palette used
 * throughout the app); reports are smaller dots, colored by whether they're
 * anonymous. Falls back to a handful of demo pins around Westlands, Nairobi
 * so the page isn't blank before real geo-tagged data exists — same pattern
 * used on the Leaders/Oversight/Election pages.
 */

import { useEffect, useRef, useState } from "react";
import { loadLeaflet } from "../lib/leaflet-loader";
import { getProjects, getReports } from "../lib/api";

const WESTLANDS_CENTER = [-1.2676, 36.8067];

const STATUS_COLOR = {
  verified:    "#1A7A4A",
  partial:     "#E8A020",
  disputed:    "#C1392B",
  unverified:  "#9AA3AB",
};

const DEMO_PROJECTS = [
  { id: "dp1", title: "Kangemi market renovation phase 1", verificationStatus: "verified", verificationScore: 0.82, category: "roads", latitude: -1.2657, longitude: 36.7611 },
  { id: "dp2", title: "Loresho borehole installation",      verificationStatus: "partial",  verificationScore: 0.45, category: "water", latitude: -1.2581, longitude: 36.7723 },
  { id: "dp3", title: "Waiyaki Way road resurfacing",        verificationStatus: "disputed", verificationScore: 0.18, category: "roads", latitude: -1.2697, longitude: 36.7972 },
  { id: "dp4", title: "Westlands Health Centre upgrade",     verificationStatus: "verified", verificationScore: 0.71, category: "health", latitude: -1.2685, longitude: 36.8095 },
  { id: "dp5", title: "Parklands streetlight installation",  verificationStatus: "unverified", verificationScore: 0, category: "security", latitude: -1.2615, longitude: 36.8138 },
];

const DEMO_REPORTS = [
  { id: "dr1", content: "Road work stopped, no crew for 11 days.", isAnonymous: false, latitude: -1.2698, longitude: 36.7975 },
  { id: "dr2", content: "Borehole complete but pump not installed.", isAnonymous: false, latitude: -1.2583, longitude: 36.7725 },
  { id: "dr3", content: "Health centre exterior painted, interior stalled.", isAnonymous: true, latitude: -1.2687, longitude: 36.8098 },
];

export default function MapPage() {
  const mapRef = useRef(null);
  const mapInstance = useRef(null);
  const [projects, setProjects] = useState([]);
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [showReports, setShowReports] = useState(true);

  // Fetch data once
  useEffect(() => {
    Promise.all([getProjects().catch(() => []), getReports().catch(() => [])])
      .then(([p, r]) => { setProjects(p); setReports(r); })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  // Build / rebuild the map whenever data changes
  useEffect(() => {
    if (loading) return;

    let cancelled = false;

    loadLeaflet().then((L) => {
      if (cancelled || !mapRef.current) return;

      // Re-use the same map instance across re-renders (e.g. toggling the
      // reports layer) instead of destroying/recreating the whole map.
      if (!mapInstance.current) {
        mapInstance.current = L.map(mapRef.current, { scrollWheelZoom: true }).setView(WESTLANDS_CENTER, 13);
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
          maxZoom: 19,
        }).addTo(mapInstance.current);
        mapInstance.current._cmLayers = { projects: L.layerGroup().addTo(mapInstance.current), reports: L.layerGroup() };
      }

      const map = mapInstance.current;
      const { projects: projectLayer, reports: reportLayer } = map._cmLayers;
      projectLayer.clearLayers();
      reportLayer.clearLayers();

      const geoProjects = projects.filter((p) => p.latitude != null && p.longitude != null);
      const displayProjects = geoProjects.length > 0 ? geoProjects : DEMO_PROJECTS;

      displayProjects.forEach((p) => {
        const color = STATUS_COLOR[p.verificationStatus] || STATUS_COLOR.unverified;
        const marker = L.circleMarker([p.latitude, p.longitude], {
          radius: 9, color: "#fff", weight: 2, fillColor: color, fillOpacity: 0.9,
        });
        marker.bindPopup(`
          <div style="font-family: 'IBM Plex Sans', sans-serif; min-width: 180px;">
            <div style="font-weight:600;font-size:13px;margin-bottom:4px;">${escapeHtml(p.title)}</div>
            <div style="font-size:11px;color:${color};font-weight:600;text-transform:uppercase;letter-spacing:0.4px;margin-bottom:2px;">
              ${escapeHtml(p.verificationStatus || "unverified")}
            </div>
            <div style="font-size:11px;color:#5B6470;">Confidence: ${Math.round((p.verificationScore || 0) * 100)}%</div>
            ${p.id && !String(p.id).startsWith("dp") ? `<a href="/projects" style="font-size:11px;color:#1A7A4A;">View in Projects →</a>` : ""}
          </div>
        `);
        projectLayer.addLayer(marker);
      });

      const geoReports = reports.filter((r) => r.latitude != null && r.longitude != null);
      const displayReports = geoReports.length > 0 ? geoReports : DEMO_REPORTS;

      displayReports.forEach((r) => {
        const marker = L.circleMarker([r.latitude, r.longitude], {
          radius: 5, color: "#fff", weight: 1.5,
          fillColor: r.isAnonymous ? "#378ADD" : "#0D1B2A", fillOpacity: 0.85,
        });
        marker.bindPopup(`
          <div style="font-family: 'IBM Plex Sans', sans-serif; max-width: 200px;">
            <div style="font-size:12px;line-height:1.4;margin-bottom:4px;">${escapeHtml(r.content)}</div>
            <div style="font-size:10px;color:#9AA3AB;">${r.isAnonymous ? "Anonymous report" : "Citizen report"}</div>
          </div>
        `);
        reportLayer.addLayer(marker);
      });

      if (showReports) { if (!map.hasLayer(reportLayer)) map.addLayer(reportLayer); }
      else { if (map.hasLayer(reportLayer)) map.removeLayer(reportLayer); }
    }).catch((e) => setError(e.message));

    return () => { cancelled = true; };
  }, [loading, projects, reports, showReports]);

  const geoProjectCount = projects.filter((p) => p.latitude != null && p.longitude != null).length;
  const geoReportCount  = reports.filter((r) => r.latitude != null && r.longitude != null).length;
  const usingDemoData = geoProjectCount === 0 && geoReportCount === 0;

  return (
    <main className="cm-page">
      <div className="cm-header-row">
        <div>
          <div className="cm-page-title">Project Map</div>
          <div className="cm-page-sub">Geospatial view of tracked projects and citizen reports</div>
        </div>
        <button className="cm-btn-ghost" onClick={() => setShowReports((s) => !s)}>
          <i className={`ti ${showReports ? "ti-eye-off" : "ti-eye"}`} /> {showReports ? "Hide" : "Show"} reports
        </button>
      </div>

      {error && (
        <div className="cm-alert-banner">
          <i className="ti ti-alert-triangle" style={{ color: "#A32D2D", fontSize: 16 }} />
          <div className="cm-alert-text">{error}</div>
        </div>
      )}

      {usingDemoData && !loading && (
        <div style={{ background: "#FEF9E7", border: "0.5px solid #E8A020", borderRadius: "var(--border-radius-md)", padding: "10px 12px", fontSize: 12, color: "#633806" }}>
          <i className="ti ti-info-circle" /> No projects or reports have coordinates yet — showing illustrative demo pins around Westlands. Add a latitude/longitude when creating a project, or submit a report with GPS-tagged photo evidence, to see real data here.
        </div>
      )}

      <div className="cm-card" style={{ padding: 0, overflow: "hidden" }}>
        {loading ? (
          <div className="cm-loading" style={{ padding: 60 }}>Loading map…</div>
        ) : (
          <div ref={mapRef} style={{ height: 520, width: "100%" }} />
        )}
      </div>

      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", fontSize: 12, color: "var(--color-text-secondary)" }}>
        {Object.entries(STATUS_COLOR).map(([status, color]) => (
          <div key={status} style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ width: 10, height: 10, borderRadius: "50%", background: color, display: "inline-block" }} />
            {status}
          </div>
        ))}
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ width: 8, height: 8, borderRadius: "50%", background: "#0D1B2A", display: "inline-block" }} />
          citizen report
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ width: 8, height: 8, borderRadius: "50%", background: "#378ADD", display: "inline-block" }} />
          anonymous report
        </div>
      </div>
    </main>
  );
}

// Minimal escaping for content interpolated into Leaflet popup HTML strings
// (Leaflet's bindPopup renders raw HTML, so anything from report content or
// project titles needs escaping to avoid XSS via a malicious report).
function escapeHtml(str) {
  return String(str ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}
