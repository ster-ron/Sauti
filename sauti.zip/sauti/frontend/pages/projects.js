import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import Link from "next/link";
import { getProjects, createProject, recomputeVerification, createReport, getProjectMedia } from "../lib/api";
import EvidenceUpload from "../components/EvidenceUpload";
import { isSaved, toggleSaved } from "../lib/saved";

const CATEGORIES = ["water", "roads", "health", "education", "security", "other"];
const STATUS_FILL = { verified: "fill-green", partial: "fill-amber", disputed: "fill-red", unverified: "fill-blue" };
const STATUS_PCT  = { verified: 88, partial: 51, disputed: 12, unverified: 35 };

function getTagClass(cat) {
  return { water:"tag-water", roads:"tag-roads", health:"tag-health", education:"tag-edu", security:"tag-security" }[cat] || "tag-other";
}

function CreateProjectModal({ onClose, onSubmit }) {
  const [form, setForm] = useState({ title: "", description: "", location: "", region: "Westlands", category: "other", budget: "", latitude: "", longitude: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [locating, setLocating] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const useMyLocation = () => {
    if (!("geolocation" in navigator)) { setError("GPS not available on this device/browser."); return; }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => { setForm((f) => ({ ...f, latitude: pos.coords.latitude.toFixed(5), longitude: pos.coords.longitude.toFixed(5) })); setLocating(false); },
      () => { setError("Location access denied — you can still type coordinates manually."); setLocating(false); },
      { timeout: 8000 }
    );
  };

  const handleSubmit = async () => {
    if (!form.title.trim() || !form.description.trim()) { setError("Title and description are required."); return; }
    setLoading(true);
    try {
      await onSubmit({
        ...form,
        budget: form.budget ? parseFloat(form.budget) : null,
        latitude: form.latitude !== "" ? parseFloat(form.latitude) : null,
        longitude: form.longitude !== "" ? parseFloat(form.longitude) : null,
      });
      onClose();
    }
    catch (e) { setError(e.message); setLoading(false); }
  };

  return (
    <div className="cm-modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="cm-modal">
        <div className="cm-modal-title">Add new project</div>
        <p style={{ fontSize: 12, color: "var(--color-text-secondary)" }}>Leaders post public projects for citizen accountability tracking.</p>
        <div className="cm-form-grid">
          <div className="cm-field"><label className="cm-label">Title *</label><input className="cm-input" value={form.title} onChange={set("title")} placeholder="Project title" /></div>
          <div className="cm-field"><label className="cm-label">Description *</label><textarea className="cm-input cm-textarea" value={form.description} onChange={set("description")} placeholder="What is this project about?" /></div>
          <div className="cm-form-row">
            <div className="cm-field"><label className="cm-label">Location</label><input className="cm-input" value={form.location} onChange={set("location")} placeholder="e.g. Kangemi ward" /></div>
            <div className="cm-field"><label className="cm-label">Region</label><input className="cm-input" value={form.region} onChange={set("region")} placeholder="e.g. Westlands" /></div>
          </div>
          <div className="cm-form-row">
            <div className="cm-field">
              <label className="cm-label">Category</label>
              <select className="cm-select" value={form.category} onChange={set("category")}>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="cm-field"><label className="cm-label">Budget (KSh)</label><input className="cm-input" type="number" value={form.budget} onChange={set("budget")} placeholder="e.g. 45000000" /></div>
          </div>
          <div className="cm-field">
            <label className="cm-label">Coordinates (for the project map)</label>
            <div className="cm-form-row">
              <input className="cm-input" type="number" step="0.00001" value={form.latitude} onChange={set("latitude")} placeholder="Latitude e.g. -1.2676" />
              <input className="cm-input" type="number" step="0.00001" value={form.longitude} onChange={set("longitude")} placeholder="Longitude e.g. 36.8067" />
            </div>
            <button type="button" className="cm-btn-ghost" style={{ fontSize: 11, marginTop: 6 }} onClick={useMyLocation} disabled={locating}>
              <i className="ti ti-current-location" /> {locating ? "Locating…" : "Use my current location"}
            </button>
          </div>
        </div>
        {error && <p className="cm-error">{error}</p>}
        <div className="cm-modal-footer">
          <button className="cm-btn-ghost" onClick={onClose}>Cancel</button>
          <button className="cm-btn-primary" onClick={handleSubmit} disabled={loading}>{loading ? "Creating…" : "Create project"}</button>
        </div>
      </div>
    </div>
  );
}

function ReportModal({ project, onClose, onSubmit }) {
  const [content, setContent]     = useState("");
  const [location, setLocation]   = useState(project?.location || "");
  const [isAnonymous, setAnonymous] = useState(false);
  const [mediaIds, setMediaIds]   = useState([]);
  const [gps, setGps]             = useState(null);
  const [gpsError, setGpsError]   = useState(null);
  const [loading, setLoading]     = useState(false);
  const [error, setError]         = useState("");

  useEffect(() => {
    if (!("geolocation" in navigator)) { setGpsError("GPS not available on this device"); return; }
    navigator.geolocation.getCurrentPosition(
      (pos) => setGps({ latitude: pos.coords.latitude, longitude: pos.coords.longitude }),
      ()    => setGpsError("Location access denied — your report will still be submitted without coordinates"),
      { timeout: 8000, maximumAge: 60000 }
    );
  }, []);

  const handleSubmit = async () => {
    if (!content.trim()) { setError("Please describe what you observed."); return; }
    setLoading(true);
    try {
      await onSubmit({
        content, location, isAnonymous, projectId: project.id, mediaIds,
        latitude: gps?.latitude ?? null,
        longitude: gps?.longitude ?? null,
      });
      onClose();
    }
    catch (e) { setError(e.message); setLoading(false); }
  };

  return (
    <div className="cm-modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="cm-modal">
        <div className="cm-modal-title">Submit report for "{project.title}"</div>
        <p style={{ fontSize: 12, color: "var(--color-text-secondary)", marginBottom: 4 }}>
          Photo and video evidence is given higher weight in the Verification Engine.
        </p>
        <div className="cm-field"><label className="cm-label">What did you observe? *</label><textarea className="cm-input cm-textarea" value={content} onChange={e => setContent(e.target.value)} placeholder="Describe what you saw at this project site…" /></div>
        <div className="cm-field"><label className="cm-label">Your location</label><input className="cm-input" value={location} onChange={e => setLocation(e.target.value)} /></div>
        <div style={{ fontSize: 11, color: gps ? "#1A7A4A" : "var(--color-text-tertiary)", marginBottom: 8 }}>
          <i className={`ti ${gps ? "ti-map-pin" : "ti-map-pin-off"}`} />{" "}
          {gps ? `GPS attached (${gps.latitude.toFixed(4)}, ${gps.longitude.toFixed(4)})${isAnonymous ? " — rounded before publishing since you're reporting anonymously" : ""}` : gpsError || "Acquiring GPS…"}
        </div>
        <div className="cm-field">
          <label className="cm-label">Photo / video evidence</label>
          <EvidenceUpload onUploaded={setMediaIds} projectId={project.id} disabled={loading} />
          {mediaIds.length > 0 && (
            <p style={{ fontSize: 11, color: "#1A7A4A", marginTop: 4 }}>
              <i className="ti ti-check" /> {mediaIds.length} file{mediaIds.length > 1 ? "s" : ""} ready to attach
            </p>
          )}
        </div>
        <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, cursor: "pointer" }}>
          <input type="checkbox" checked={isAnonymous} onChange={e => setAnonymous(e.target.checked)} /> Submit anonymously
        </label>
        {error && <p className="cm-error">{error}</p>}
        <div className="cm-modal-footer">
          <button className="cm-btn-ghost" onClick={onClose}>Cancel</button>
          <button className="cm-btn-primary" onClick={handleSubmit} disabled={loading}>{loading ? "Submitting…" : "Submit report"}</button>
        </div>
      </div>
    </div>
  );
}

export default function ProjectsPage() {
  const router = useRouter();
  const leaderFilter = typeof router.query.createdBy === "string" ? router.query.createdBy : null;

  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [reportTarget, setReportTarget] = useState(null);
  const [error, setError] = useState("");
  const [savedTick, setSavedTick] = useState(0);

  const handleToggleSaved = (id) => { toggleSaved(id); setSavedTick((t) => t + 1); };

  const load = () =>
    getProjects(leaderFilter ? { createdBy: leaderFilter } : {})
      .then(setProjects)
      .catch(console.error)
      .finally(() => setLoading(false));

  // router.isReady guards against firing once with an empty query on first
  // render, then again once Next.js has parsed the URL — we only want the one
  // real fetch, using whatever createdBy ended up in the URL (or none).
  useEffect(() => { if (router.isReady) load(); }, [router.isReady, leaderFilter]);

  const handleCreate = async (form) => { await createProject(form); load(); };
  const handleReport = async (form) => { await createReport(form); load(); };
  const handleRecompute = async (id) => { try { await recomputeVerification(id); load(); } catch(e) { setError(e.message); } };

  const filtered = filter ? projects.filter(p => p.category === filter || p.verificationStatus === filter) : projects;

  return (
    <main className="cm-page">
      <div className="cm-header-row">
        <div>
          <div className="cm-page-title">Public Projects</div>
          <div className="cm-page-sub">All tracked civic projects · Westlands Constituency</div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <Link href="/map" className="cm-btn-ghost" style={{ fontSize: 13, display: "inline-flex", alignItems: "center", gap: 6 }}>
            <i className="ti ti-map-2" /> Map view
          </Link>
          <button className="cm-btn-primary" onClick={() => setShowCreate(true)}>
            <i className="ti ti-plus" /> Add project
          </button>
        </div>
      </div>

      {leaderFilter && (
        <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12, color: "var(--color-text-secondary)" }}>
          <i className="ti ti-filter" /> Showing only this leader's projects
          <Link href="/projects" className="cm-btn-ghost" style={{ fontSize: 11, padding: "3px 8px" }}>Clear</Link>
        </div>
      )}

      <div className="cm-chips">
        {["", ...CATEGORIES, "verified", "disputed", "partial"].map(f => (
          <button key={f} className={`cm-chip ${filter === f ? "active" : ""}`} onClick={() => setFilter(f)}>
            {f || "All"}
          </button>
        ))}
      </div>

      {error && <p className="cm-error">{error}</p>}

      {loading ? <div className="cm-loading">Loading projects…</div> : filtered.length === 0 ? (
        <div className="cm-empty"><i className="ti ti-building-community" />No projects found. Leaders can add the first one.</div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {filtered.map(p => (
            <div key={p.id} className="cm-card" style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 12, alignItems: "start" }}>
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                  <div style={{ fontSize: 14, fontWeight: 500 }}>{p.title}</div>
                  <span className={`cm-tag ${getTagClass(p.category)}`}>{p.category}</span>
                </div>
                <p style={{ fontSize: 12, color: "var(--color-text-secondary)", marginBottom: 8, lineHeight: 1.5 }}>{p.description}</p>
                <div style={{ fontSize: 12, color: "var(--color-text-secondary)", display: "flex", gap: 12, flexWrap: "wrap" }}>
                  {p.budget && <span><i className="ti ti-coin" /> KSh {(p.budget/1e6).toFixed(2)}M</span>}
                  {p.location && <span><i className="ti ti-map-pin" /> {p.location}</span>}
                  {p.region && <span><i className="ti ti-map-2" /> {p.region}</span>}
                </div>
                <div className="cm-progress-bar" style={{ marginTop: 10 }}>
                  <div className={`cm-progress-fill ${STATUS_FILL[p.verificationStatus] || "fill-blue"}`}
                    style={{ width: `${p.verificationScore ? Math.round(p.verificationScore * 100) : (STATUS_PCT[p.verificationStatus] || 0)}%` }} />
                </div>
                <div style={{ fontSize: 11, color: "var(--color-text-tertiary)", marginTop: 4 }}>
                  Verification confidence: {Math.round((p.verificationScore || 0) * 100)}%
                </div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6, alignItems: "flex-end" }}>
                <span className={`cm-status status-${p.verificationStatus}`}>{p.verificationStatus}</span>
                <button
                  className="cm-btn-ghost"
                  style={{ fontSize: 11, padding: "4px 8px" }}
                  onClick={() => handleToggleSaved(p.id)}
                  title={isSaved(p.id) ? "Remove from saved" : "Save this project"}
                >
                  <i className={`ti ${isSaved(p.id) ? "ti-bookmark-filled" : "ti-bookmark"}`} key={savedTick} /> {isSaved(p.id) ? "Saved" : "Save"}
                </button>
                <button className="cm-btn-ghost" style={{ fontSize: 11, padding: "4px 8px" }} onClick={() => setReportTarget(p)}>
                  <i className="ti ti-file-plus" /> Report
                </button>
                <button className="cm-btn-ghost" style={{ fontSize: 11, padding: "4px 8px" }} onClick={() => handleRecompute(p.id)}>
                  <i className="ti ti-refresh" /> Re-verify
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showCreate && <CreateProjectModal onClose={() => setShowCreate(false)} onSubmit={handleCreate} />}
      {reportTarget && <ReportModal project={reportTarget} onClose={() => setReportTarget(null)} onSubmit={handleReport} />}
    </main>
  );
}
