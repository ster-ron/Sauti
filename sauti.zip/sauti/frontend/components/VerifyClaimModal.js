import { useEffect, useState } from "react";
import Link from "next/link";
import { getProjects } from "../lib/api";

const STATUS_COLOR = { verified: "#1A7A4A", partial: "#E8A020", disputed: "#C1392B", unverified: "#9AA3AB" };

/**
 * "Verify a claim" — lets anyone search for a project by name/region and see
 * the Verification Engine's current finding, without having to dig through
 * the full Projects list first. Searches client-side against whatever's
 * already loaded from GET /projects (no dedicated search endpoint exists
 * yet — fine at current data volumes, worth revisiting if the project list
 * grows into the thousands).
 */
export default function VerifyClaimModal({ onClose }) {
  const [query, setQuery] = useState("");
  const [allProjects, setAllProjects] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    getProjects()
      .then(setAllProjects)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const q = query.trim().toLowerCase();
  const results = !q || !allProjects
    ? []
    : allProjects.filter((p) =>
        p.title?.toLowerCase().includes(q) ||
        p.region?.toLowerCase().includes(q) ||
        p.location?.toLowerCase().includes(q)
      ).slice(0, 8);

  return (
    <div className="cm-modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="cm-modal">
        <div className="cm-modal-title">Verify a claim</div>
        <p style={{ fontSize: 12, color: "var(--color-text-secondary)", marginBottom: 10 }}>
          Search for a project by name, ward, or region to see its current Verification Engine status — based on
          citizen reports submitted against it, not on anyone's say-so.
        </p>

        <input
          className="cm-input"
          autoFocus
          placeholder="e.g. 'borehole', 'Kangemi', 'health centre'…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />

        {error && <p className="cm-error" style={{ marginTop: 8 }}>{error}</p>}
        {loading && <p style={{ fontSize: 12, color: "var(--color-text-tertiary)", marginTop: 10 }}>Loading project records…</p>}

        {!loading && q && results.length === 0 && (
          <div className="cm-empty" style={{ padding: 16 }}>
            No project matches "{query}". Try a shorter or different search term, or check the full{" "}
            <Link href="/projects" onClick={onClose} style={{ color: "var(--cm-green, #1A7A4A)" }}>Projects list</Link>.
          </div>
        )}

        {results.length > 0 && (
          <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 6, maxHeight: 320, overflowY: "auto" }}>
            {results.map((p) => {
              const color = STATUS_COLOR[p.verificationStatus] || STATUS_COLOR.unverified;
              return (
                <Link
                  key={p.id}
                  href={`/projects?createdBy=${p.createdBy || ""}`}
                  onClick={onClose}
                  style={{ display: "block", border: "1px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-md)", padding: "10px 12px" }}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>{p.title}</div>
                    <span style={{ fontSize: 11, fontWeight: 600, color, textTransform: "uppercase", whiteSpace: "nowrap" }}>
                      {p.verificationStatus || "unverified"}
                    </span>
                  </div>
                  <div style={{ fontSize: 11, color: "var(--color-text-tertiary)", marginTop: 2 }}>
                    {p.region || p.location || "Location not specified"} · {Math.round((p.verificationScore || 0) * 100)}% confidence
                    {typeof p.corruptionRiskLevel === "string" && p.corruptionRiskLevel !== "none" && (
                      <span style={{ color: "#C1392B" }}> · corruption risk: {p.corruptionRiskLevel}</span>
                    )}
                  </div>
                </Link>
              );
            })}
          </div>
        )}

        <div className="cm-modal-footer">
          <button className="cm-btn-ghost" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}
