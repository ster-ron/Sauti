/**
 * EvidenceUpload — shared component for photo/video evidence capture
 *
 * Features:
 *  - Drag-and-drop or click-to-browse (images + video)
 *  - Camera capture on mobile (accept="capture")
 *  - GPS auto-attach (asks permission once, gracefully degrades)
 *  - Per-file preview: thumbnail for images, duration badge for video
 *  - Progress bar during upload
 *  - Returns array of MediaEvidence IDs to the parent via onUploaded(mediaIds)
 *  - Works without Cloudinary configured — warns and skips upload, returns []
 *
 * Usage:
 *   <EvidenceUpload onUploaded={(ids) => setMediaIds(ids)} reportId={reportId} />
 */

import { useState, useRef, useCallback } from "react";

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";

function getToken() {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("sauti_token");
}

async function uploadFile(file, { reportId, projectId, latitude, longitude }) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const res = await fetch(`${API}/upload`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${getToken()}`,
          },
          body: JSON.stringify({
            file:      reader.result,      // base64 data URI
            mimeType:  file.type,
            reportId:  reportId  || null,
            projectId: projectId || null,
            latitude:  latitude  || null,
            longitude: longitude || null,
            capturedAt: new Date().toISOString(),
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Upload failed");
        resolve(data);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsDataURL(file);
  });
}

function FilePreview({ file, status, progress, error, onRemove }) {
  const isVideo = file.type.startsWith("video/");
  const isImage = file.type.startsWith("image/");
  const previewUrl = isImage ? URL.createObjectURL(file) : null;

  const statusColor = {
    pending:    "var(--color-text-tertiary)",
    uploading:  "#185FA5",
    done:       "#1A7A4A",
    error:      "#C1392B",
  }[status];

  const statusLabel = {
    pending:   "Waiting…",
    uploading: `${progress}%`,
    done:      "Uploaded",
    error:     error || "Failed",
  }[status];

  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: "48px 1fr auto",
      gap: 10,
      alignItems: "center",
      padding: "8px 10px",
      border: "0.5px solid var(--color-border-tertiary)",
      borderRadius: "var(--border-radius-md)",
      background: "var(--color-background-primary)",
    }}>
      {/* Thumbnail / icon */}
      <div style={{
        width: 48, height: 48, borderRadius: 4,
        background: "var(--color-background-secondary)",
        display: "flex", alignItems: "center", justifyContent: "center",
        overflow: "hidden", flexShrink: 0,
      }}>
        {isImage && previewUrl ? (
          <img src={previewUrl} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        ) : isVideo ? (
          <i className="ti ti-movie" style={{ fontSize: 22, color: "#185FA5" }} aria-hidden="true" />
        ) : (
          <i className="ti ti-file" style={{ fontSize: 22, color: "var(--color-text-tertiary)" }} aria-hidden="true" />
        )}
      </div>

      {/* Info + progress */}
      <div style={{ minWidth: 0 }}>
        <div style={{
          fontSize: 12, fontWeight: 500,
          overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
          marginBottom: 3,
        }}>{file.name}</div>
        <div style={{ fontSize: 11, color: "var(--color-text-tertiary)", marginBottom: 4 }}>
          {(file.size / 1024 / 1024).toFixed(2)} MB
        </div>
        {status === "uploading" && (
          <div style={{ height: 3, background: "var(--color-border-tertiary)", borderRadius: 2, overflow: "hidden" }}>
            <div style={{ height: 3, width: `${progress}%`, background: "#185FA5", borderRadius: 2, transition: "width 0.3s" }} />
          </div>
        )}
        {status !== "uploading" && (
          <div style={{ fontSize: 11, color: statusColor }}>{statusLabel}</div>
        )}
      </div>

      {/* Remove button */}
      {status !== "uploading" && (
        <button
          onClick={onRemove}
          style={{ background: "none", border: "none", cursor: "pointer", padding: 4, color: "var(--color-text-tertiary)" }}
          aria-label="Remove file"
        >
          <i className="ti ti-x" style={{ fontSize: 14 }} aria-hidden="true" />
        </button>
      )}
    </div>
  );
}

export default function EvidenceUpload({ onUploaded, reportId = null, projectId = null, disabled = false }) {
  const [files, setFiles] = useState([]);          // { file, status, progress, error, mediaId }
  const [gps, setGps]     = useState(null);        // { latitude, longitude }
  const [gpsError, setGpsError] = useState(null);
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef(null);

  // Attempt GPS once on first file add
  const requestGps = useCallback(() => {
    if (gps || gpsError) return;
    if (!("geolocation" in navigator)) {
      setGpsError("GPS not available on this device");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => setGps({ latitude: pos.coords.latitude, longitude: pos.coords.longitude }),
      ()    => setGpsError("Location access denied — GPS will not be attached"),
      { timeout: 8000, maximumAge: 60000 }
    );
  }, [gps, gpsError]);

  const addFiles = useCallback((newFiles) => {
    requestGps();
    const ACCEPTED = ["image/jpeg","image/png","image/webp","image/gif","video/mp4","video/quicktime","video/webm"];
    const MAX_SIZE = 10 * 1024 * 1024; // 10MB — server limit for base64 uploads

    const valid = Array.from(newFiles).filter((f) => {
      if (!ACCEPTED.includes(f.type)) return false;
      if (f.size > MAX_SIZE) return false;
      return true;
    });

    const entries = valid.map((file) => ({
      id: `${Date.now()}-${Math.random()}`,
      file,
      status:   "pending",
      progress: 0,
      error:    null,
      mediaId:  null,
    }));

    setFiles((prev) => [...prev, ...entries]);

    // Upload immediately
    entries.forEach((entry) => {
      uploadOneFile(entry);
    });
  }, [gps, reportId, projectId]); // eslint-disable-line react-hooks/exhaustive-deps

  const uploadOneFile = async (entry) => {
    setFiles((prev) => prev.map((f) => f.id === entry.id ? { ...f, status: "uploading", progress: 10 } : f));

    // Simulate progress ticks while waiting for Cloudinary
    let tick = 10;
    const interval = setInterval(() => {
      tick = Math.min(tick + 8, 85);
      setFiles((prev) => prev.map((f) => f.id === entry.id && f.status === "uploading" ? { ...f, progress: tick } : f));
    }, 400);

    try {
      const result = await uploadFile(entry.file, {
        reportId,
        projectId,
        latitude:  gps?.latitude,
        longitude: gps?.longitude,
      });
      clearInterval(interval);
      setFiles((prev) => {
        const next = prev.map((f) =>
          f.id === entry.id ? { ...f, status: "done", progress: 100, mediaId: result.id } : f
        );
        // Notify parent with all completed media IDs
        const done = next.filter((f) => f.mediaId).map((f) => f.mediaId);
        onUploaded(done);
        return next;
      });
    } catch (err) {
      clearInterval(interval);
      setFiles((prev) => prev.map((f) =>
        f.id === entry.id ? { ...f, status: "error", error: err.message } : f
      ));
    }
  };

  const removeFile = (id) => {
    setFiles((prev) => {
      const next = prev.filter((f) => f.id !== id);
      const done = next.filter((f) => f.mediaId).map((f) => f.mediaId);
      onUploaded(done);
      return next;
    });
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    if (disabled) return;
    addFiles(e.dataTransfer.files);
  };

  const uploadingCount = files.filter((f) => f.status === "uploading").length;
  const doneCount      = files.filter((f) => f.status === "done").length;
  const errorCount     = files.filter((f) => f.status === "error").length;

  return (
    <div>
      {/* Drop zone */}
      <div
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        onClick={() => !disabled && inputRef.current?.click()}
        style={{
          border: `1.5px dashed ${dragOver ? "#1A7A4A" : "var(--color-border-secondary)"}`,
          borderRadius: "var(--border-radius-lg)",
          padding: "20px 16px",
          textAlign: "center",
          cursor: disabled ? "not-allowed" : "pointer",
          background: dragOver ? "#E1F5EE" : "var(--color-background-secondary)",
          transition: "all 0.15s",
          opacity: disabled ? 0.5 : 1,
        }}
        role="button"
        tabIndex={disabled ? -1 : 0}
        aria-label="Upload photo or video evidence"
        onKeyDown={(e) => e.key === "Enter" && !disabled && inputRef.current?.click()}
      >
        <i className="ti ti-camera-plus" style={{ fontSize: 28, color: "#1A7A4A", display: "block", marginBottom: 8 }} aria-hidden="true" />
        <div style={{ fontSize: 13, fontWeight: 500, color: "var(--color-text-primary)", marginBottom: 3 }}>
          Drag photos or video here, or tap to browse
        </div>
        <div style={{ fontSize: 11, color: "var(--color-text-tertiary)" }}>
          JPG, PNG, WEBP, MP4, MOV · max 10 MB each
        </div>
      </div>

      {/* Hidden file input — supports camera capture on mobile */}
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/quicktime,video/webm"
        multiple
        capture="environment"
        style={{ display: "none" }}
        onChange={(e) => addFiles(e.target.files)}
        disabled={disabled}
      />

      {/* GPS status */}
      {files.length > 0 && (
        <div style={{ fontSize: 11, marginTop: 6, display: "flex", alignItems: "center", gap: 5 }}>
          {gps ? (
            <>
              <i className="ti ti-map-pin" style={{ fontSize: 12, color: "#1A7A4A" }} aria-hidden="true" />
              <span style={{ color: "#1A7A4A" }}>
                GPS attached ({gps.latitude.toFixed(4)}, {gps.longitude.toFixed(4)})
              </span>
            </>
          ) : gpsError ? (
            <>
              <i className="ti ti-map-pin-off" style={{ fontSize: 12, color: "var(--color-text-tertiary)" }} aria-hidden="true" />
              <span style={{ color: "var(--color-text-tertiary)" }}>{gpsError}</span>
            </>
          ) : (
            <>
              <i className="ti ti-loader" style={{ fontSize: 12, color: "var(--color-text-tertiary)" }} aria-hidden="true" />
              <span style={{ color: "var(--color-text-tertiary)" }}>Acquiring GPS…</span>
            </>
          )}
        </div>
      )}

      {/* File list */}
      {files.length > 0 && (
        <div style={{ display: "flex", flexDirection: "column", gap: 6, marginTop: 10 }}>
          {files.map((f) => (
            <FilePreview
              key={f.id}
              file={f.file}
              status={f.status}
              progress={f.progress}
              error={f.error}
              onRemove={() => removeFile(f.id)}
            />
          ))}
        </div>
      )}

      {/* Summary status */}
      {files.length > 0 && (
        <div style={{ fontSize: 11, marginTop: 8, color: "var(--color-text-secondary)", display: "flex", gap: 12 }}>
          {uploadingCount > 0 && <span style={{ color: "#185FA5" }}><i className="ti ti-loader" /> {uploadingCount} uploading…</span>}
          {doneCount      > 0 && <span style={{ color: "#1A7A4A"  }}><i className="ti ti-check" /> {doneCount} ready</span>}
          {errorCount     > 0 && <span style={{ color: "#C1392B"  }}><i className="ti ti-alert-circle" /> {errorCount} failed — check file size/type</span>}
        </div>
      )}
    </div>
  );
}
