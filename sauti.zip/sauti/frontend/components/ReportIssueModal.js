import { useEffect, useState } from "react";
import { getProjects, createReport } from "../lib/api";
import EvidenceUpload from "./EvidenceUpload";

/**
 * "Report issue" — the sidebar-level entry point for filing a report from
 * anywhere in the app, not just from a project's own page. Functionally
 * this is the same POST /reports call as ReportModal in pages/projects.js,
 * but projectId is optional here: citizens can flag a general civic issue
 * (e.g. "this whole road is unlit at night") without it belonging to any
 * tracked project, or optionally search for and attach a related project.
 */
export default function ReportIssueModal({ onClose, onSubmitted }) {
  const [content, setContent] = useState("");
  const [location, setLocation] = useState("");
  const [isAnonymous, setAnonymous] = useState(false);
  const [mediaIds, setMediaIds] = useState([]);
  const [gps, setGps] = useState(null);
  const [gpsError, setGpsError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Optional: search for and link a related project
  const [projectQuery, setProjectQuery] = useState("");
  const [allProjects, setAllProjects] = useState([]);
  const [linkedProject, setLinkedProject] = useState(null);

  useEffect(() => {
    getProjects().then(setAllProjects).catch(() => setAllProjects([]));
  }, []);

  useEffect(() => {
    if (!("geolocation" in navigator)) { setGpsError("GPS not available on this device"); return; }
    navigator.geolocation.getCurrentPosition(
      (pos) => setGps({ latitude: pos.coords.latitude, longitude: pos.coords.longitude }),
      ()    => setGpsError("Location access denied — your report will still be submitted without coordinates"),
      { timeout: 8000, maximumAge: 60000 }
    );
  }, []);

  const matches = projectQuery.trim()
    ? allProjects.filter((p) => p.title?.toLowerCase().includes(projectQuery.trim().toLowerCase())).slice(0, 5)
    : [];

  const handleSubmit = async () => {
    if (!content.trim()) { setError("Please describe the issue."); return; }
    setLoading(true);
    try {
      await createReport({
        content, location, isAnonymous, mediaIds,
        projectId: linkedProject?.id || null,
        latitude: gps?.latitude ?? null,
        longitude: gps?.longitude ?? null,
      });
      onSubmitted?.();
      onClose();
    } catch (e) {
      setError(e.message);
      setLoading(false);
    }
  };

  return (
    <div className="cm-modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="cm-modal">
        <div className="cm-modal-title">Report an issue</div>
        <p style={{ fontSize: 12, color: "var(--color-text-secondary)", marginBottom: 4 }}>
          Flag a civic problem you've observed. You don't need to link it to a specific project.
        </p>

        <div className="cm-field">
          <label className="cm-label">What's the issue? *</label>
          <textarea className="cm-input cm-textarea" value={content} onChange={(e) => setContent(e.target.value)}
            placeholder="Describe what you observed and where…" />
        </div>

        <div className="cm-field">
          <label className="cm-label">Your location</label>
          <input className="cm-input" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="e.g. Kangemi ward, near the market" />
        </div>

        <div style={{ fontSize: 11, color: gps ? "#1A7A4A" : "var(--color-text-tertiary)", marginBottom: 10 }}>
          <i className={`ti ${gps ? "ti-map-pin" : "ti-map-pin-off"}`} />{" "}
          {gps ? `GPS attached (${gps.latitude.toFixed(4)}, ${gps.longitude.toFixed(4)})${isAnonymous ? " — rounded before publishing since you're reporting anonymously" : ""}` : gpsError || "Acquiring GPS…"}
        </div>

        <div className="cm-field">
          <label className="cm-label">Link to a related project (optional)</label>
          {linkedProject ? (
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", border: "1px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-md)", padding: "6px 10px", fontSize: 12 }}>
              <span><i className="ti ti-building-community" /> {linkedProject.title}</span>
              <button type="button" className="cm-btn-ghost" style={{ fontSize: 11, padding: "2px 6px" }} onClick={() => setLinkedProject(null)}>Remove</button>
            </div>
          ) : (
            <>
              <input className="cm-input" value={projectQuery} onChange={(e) => setProjectQuery(e.target.value)} placeholder="Search projects by name…" />
              {matches.length > 0 && (
                <div style={{ marginTop: 4, border: "1px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-md)", overflow: "hidden" }}>
                  {matches.map((p) => (
                    <div key={p.id} style={{ padding: "6px 10px", fontSize: 12, cursor: "pointer" }}
                      onClick={() => { setLinkedProject(p); setProjectQuery(""); }}>
                      {p.title}
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>

        <div className="cm-field">
          <label className="cm-label">Photo / video evidence</label>
          <EvidenceUpload onUploaded={setMediaIds} projectId={linkedProject?.id} disabled={loading} />
          {mediaIds.length > 0 && (
            <p style={{ fontSize: 11, color: "#1A7A4A", marginTop: 4 }}>
              <i className="ti ti-check" /> {mediaIds.length} file{mediaIds.length > 1 ? "s" : ""} ready to attach
            </p>
          )}
        </div>

        <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, cursor: "pointer" }}>
          <input type="checkbox" checked={isAnonymous} onChange={(e) => setAnonymous(e.target.checked)} /> Submit anonymously
        </label>

        {error && <p className="cm-error">{error}</p>}

        <div className="cm-modal-footer">
          <button className="cm-btn-ghost" onClick={onClose}>Cancel</button>
          <button className="cm-btn-primary" onClick={handleSubmit} disabled={loading}>{loading ? "Submitting…" : "Submit report"}</button>
        </div>
      </div>
    </div>
  );
}
