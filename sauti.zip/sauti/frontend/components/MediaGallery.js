/**
 * MediaGallery — renders a row of media evidence thumbnails
 * Used inside project cards and report items.
 *
 * Props:
 *   items  — array of MediaEvidence objects { url, thumbnailUrl, mediaType, latitude, longitude }
 *   max    — how many to show before "+N more" (default 4)
 */
export default function MediaGallery({ items = [], max = 4 }) {
  if (!items || items.length === 0) return null;

  const visible = items.slice(0, max);
  const overflow = items.length - max;

  return (
    <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
      {visible.map((item, i) => {
        const thumb = item.thumbnailUrl || item.url;
        const isVideo = item.mediaType === "video";
        const hasGps  = item.latitude && item.longitude;

        return (
          <a
            key={item.id || i}
            href={item.url}
            target="_blank"
            rel="noopener noreferrer"
            style={{
              position: "relative",
              display: "block",
              width: 56, height: 56,
              borderRadius: 6,
              overflow: "hidden",
              flexShrink: 0,
              border: "0.5px solid var(--color-border-tertiary)",
            }}
            title={hasGps ? `GPS: ${item.latitude?.toFixed(4)}, ${item.longitude?.toFixed(4)}` : undefined}
          >
            <img
              src={thumb}
              alt="Evidence"
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
              loading="lazy"
            />
            {isVideo && (
              <div style={{
                position: "absolute", inset: 0,
                display: "flex", alignItems: "center", justifyContent: "center",
                background: "rgba(0,0,0,0.35)",
              }}>
                <i className="ti ti-player-play" style={{ color: "#fff", fontSize: 18 }} aria-hidden="true" />
              </div>
            )}
            {hasGps && (
              <div style={{
                position: "absolute", bottom: 2, right: 2,
                background: "rgba(26,122,74,0.85)",
                borderRadius: 3, padding: "1px 3px",
              }}>
                <i className="ti ti-map-pin" style={{ color: "#fff", fontSize: 9 }} aria-hidden="true" />
              </div>
            )}
          </a>
        );
      })}

      {overflow > 0 && (
        <div style={{
          width: 56, height: 56, borderRadius: 6,
          background: "var(--color-background-secondary)",
          border: "0.5px solid var(--color-border-tertiary)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 12, fontWeight: 600, color: "var(--color-text-secondary)",
          flexShrink: 0,
        }}>
          +{overflow}
        </div>
      )}
    </div>
  );
}
