const mongoose = require("mongoose");
const { Schema } = mongoose;

const REPLY_SCHEMA = new Schema(
  {
    userId: { type: String, required: true },
    userName: { type: String, required: true },
    content: { type: String, required: true },
    createdAt: { type: Date, default: Date.now },
  },
  { _id: true }
);

const THREAD_SCHEMA = new Schema(
  {
    topic: {
      type: String,
      enum: ["water", "roads", "health", "education", "security", "other"],
      required: true,
    },
    title: { type: String, required: true },
    content: { type: String, required: true },
    userId: { type: String, required: true },
    userName: { type: String, required: true },
    projectId: { type: String, default: null }, // optional link to a Postgres Project
    replies: { type: [REPLY_SCHEMA], default: [] },
    isModerated: { type: Boolean, default: false },
    isHidden: { type: Boolean, default: false }, // moderation layer can hide w/o deleting
  },
  { timestamps: true }
);

module.exports = mongoose.model("ForumThread", THREAD_SCHEMA);
