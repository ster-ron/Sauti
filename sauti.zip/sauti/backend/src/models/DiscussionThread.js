/**
 * 🧭 Civic Discussion Engine
 *
 * Replaces the separate ForumThread / TownHall models. Both "a forum thread"
 * and "a town hall" are the same underlying object — a discussion someone
 * opened, that other citizens contribute to over time — they just run in
 * different MODES:
 *
 *   mode: "async"  → forum behavior   (no schedule, open-ended, topic-tagged)
 *   mode: "live"   → town hall behavior (scheduled, leader-hosted, region-tagged)
 *
 * Contributions from citizens (replies, questions, agenda proposals) are all
 * just ENTRIES with a `kind`. This is what lets one schema serve both UIs:
 *
 *   kind: "comment" → a forum reply
 *   kind: "question" → a town hall Q&A submission (supports .answer)
 *   kind: "agenda"   → a town hall agenda proposal (supports .votes)
 *
 * A forum thread only ever has "comment" entries. A town hall only ever has
 * "question"/"agenda" entries. The routes layer enforces that — the schema
 * itself stays mode-agnostic on purpose, so adding a third mode later
 * (e.g. "petition") doesn't require a new model.
 */

const mongoose = require("mongoose");
const { Schema } = mongoose;

const ENTRY_SCHEMA = new Schema(
  {
    kind: {
      type: String,
      enum: ["comment", "question", "agenda"],
      required: true,
    },
    title: { type: String, default: null }, // agenda items only
    content: { type: String, required: true }, // comment text / question text / agenda description
    authorId: { type: String, required: true },
    authorName: { type: String, required: true },

    // "question" kind only
    answer: { type: String, default: null },
    answeredAt: { type: Date, default: null },

    // "agenda" kind only
    votes: { type: [String], default: [] }, // userIds who upvoted
  },
  { timestamps: true }
);

const DISCUSSION_SCHEMA = new Schema(
  {
    mode: { type: String, enum: ["async", "live"], required: true },

    title: { type: String, required: true },
    description: { type: String, required: true }, // forum: thread body. town hall: agenda/context blurb.

    // async-only categorization
    topic: {
      type: String,
      enum: ["water", "roads", "health", "education", "security", "other"],
      default: undefined,
    },

    // live-only categorization + scheduling
    region: { type: String, default: undefined },
    scheduledFor: { type: Date, default: undefined },
    transcript: { type: String, default: "" }, // live-only, append-only once completed

    status: {
      type: String,
      enum: ["open", "closed", "scheduled", "live", "completed", "cancelled"],
      required: true,
    },

    authorId: { type: String, required: true }, // forum: thread creator. town hall: hosting leader.
    authorName: { type: String, required: true },

    projectId: { type: String, default: null }, // optional link to a Postgres Project

    entries: { type: [ENTRY_SCHEMA], default: [] },

    isModerated: { type: Boolean, default: false },
    isHidden: { type: Boolean, default: false },
  },
  { timestamps: true }
);

DISCUSSION_SCHEMA.index({ mode: 1, status: 1, createdAt: -1 });
DISCUSSION_SCHEMA.index({ mode: 1, topic: 1 });
DISCUSSION_SCHEMA.index({ mode: 1, region: 1 });

module.exports = mongoose.model("DiscussionThread", DISCUSSION_SCHEMA);
