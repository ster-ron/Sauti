const mongoose = require("mongoose");
const { Schema } = mongoose;

const AGENDA_ITEM_SCHEMA = new Schema(
  {
    title: { type: String, required: true },
    description: { type: String, default: "" },
    upvotes: { type: [String], default: [] }, // userIds who voted
  },
  { _id: true }
);

const QA_SCHEMA = new Schema(
  {
    question: { type: String, required: true },
    askedBy: { type: String, required: true },
    askedByName: { type: String, required: true },
    answer: { type: String, default: null },
    answeredAt: { type: Date, default: null },
  },
  { _id: true }
);

const TOWNHALL_SCHEMA = new Schema(
  {
    title: { type: String, required: true },
    region: { type: String, required: true },
    leaderId: { type: String, required: true },
    leaderName: { type: String, required: true },
    scheduledFor: { type: Date, required: true },
    status: {
      type: String,
      enum: ["scheduled", "live", "completed", "cancelled"],
      default: "scheduled",
    },
    agendaItems: { type: [AGENDA_ITEM_SCHEMA], default: [] },
    qa: { type: [QA_SCHEMA], default: [] },
    transcript: { type: String, default: "" }, // recorded transcript, append-only once completed
  },
  { timestamps: true }
);

module.exports = mongoose.model("TownHall", TOWNHALL_SCHEMA);
