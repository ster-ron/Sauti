-- Election Cycle Engine migration
-- Run: npx prisma migrate deploy  (or migrate dev in local)

-- ── ElectionCycle ─────────────────────────────────────────────────────────────
CREATE TABLE "ElectionCycle" (
  "id"          TEXT NOT NULL,
  "name"        TEXT NOT NULL,
  "region"      TEXT,
  "startDate"   TIMESTAMP(3) NOT NULL,
  "endDate"     TIMESTAMP(3) NOT NULL,
  "activeFlag"  BOOLEAN NOT NULL DEFAULT false,
  "phase"       TEXT NOT NULL DEFAULT 'pre_election',
  "description" TEXT,
  "createdBy"   TEXT NOT NULL,
  "createdAt"   TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"   TIMESTAMP(3) NOT NULL,
  CONSTRAINT "ElectionCycle_pkey" PRIMARY KEY ("id")
);

-- Only one active cycle at a time — partial unique index
CREATE UNIQUE INDEX "ElectionCycle_activeFlag_unique" ON "ElectionCycle"("activeFlag")
  WHERE "activeFlag" = true;

-- ── ManifestoPromise ──────────────────────────────────────────────────────────
CREATE TABLE "ManifestoPromise" (
  "id"               TEXT NOT NULL,
  "leaderId"         TEXT NOT NULL,
  "electionCycleId"  TEXT NOT NULL,
  "title"            TEXT NOT NULL,
  "description"      TEXT NOT NULL,
  "category"         TEXT,
  "region"           TEXT,
  "targetDate"       TIMESTAMP(3),
  "budgetCommitted"  DOUBLE PRECISION,
  "status"           TEXT NOT NULL DEFAULT 'promised',
  "deliveryEvidence" TEXT,
  "linkedProjectId"  TEXT,
  "deliveryScore"    DOUBLE PRECISION,
  "createdAt"        TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"        TIMESTAMP(3) NOT NULL,
  CONSTRAINT "ManifestoPromise_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "ManifestoPromise_electionCycleId_fkey"
    FOREIGN KEY ("electionCycleId") REFERENCES "ElectionCycle"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- ── OversightReport: add electionCycleId column ───────────────────────────────
ALTER TABLE "OversightReport"
  ADD COLUMN IF NOT EXISTS "electionCycleId" TEXT;
