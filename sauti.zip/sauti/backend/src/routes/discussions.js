const router = require("express").Router();
const { PrismaClient } = require("@prisma/client");
const DiscussionThread = require("../models/DiscussionThread");
const { authMiddleware, requireRole } = require("../middleware/authMiddleware");
const { logAction } = require("../services/auditLogger");
const core = require("../core/SautiCore");

const prisma = new PrismaClient();
const TOPICS = ["water", "roads", "health", "education", "security", "other"];
const LIVE_STATUSES = ["scheduled", "live", "completed", "cancelled"];
const ASYNC_STATUSES = ["open", "closed"];

function requireMode(req, res, next) {
  const { mode } = req.query.mode ? req.query : req.body;
  if (!mode || !["async", "live"].includes(mode)) {
    return res.status(400).json({ error: "mode must be 'async' or 'live'" });
  }
  next();
}

// ── CREATE — POST /discussions ────────────────────────────────────────────────
router.post("/", authMiddleware, requireMode, async (req, res) => {
  try {
    const { mode, title, description, topic, projectId, region, scheduledFor } = req.body;

    if (!title || !description) {
      return res.status(400).json({ error: "title and description are required" });
    }

    if (mode === "async" && topic && !TOPICS.includes(topic)) {
      return res.status(400).json({ error: `topic must be one of: ${TOPICS.join(", ")}` });
    }
    if (mode === "live") {
      if (!["leader", "admin"].includes(req.user.role)) {
        return res.status(403).json({ error: "Only leaders or admins can schedule a town hall" });
      }
      if (!region || !scheduledFor) {
        return res.status(400).json({ error: "region and scheduledFor are required for live discussions" });
      }
    }

    const user = await prisma.user.findUnique({ where: { id: req.user.id } });

    // Build the document so the Core can inspect it for rule checks before persisting
    const discussionData = {
      mode,
      title,
      description,
      authorId:   req.user.id,
      authorName: user?.name || "Unknown",
      status:     mode === "async" ? "open" : "scheduled",
      ...(mode === "async" ? { topic: topic || "other", projectId: projectId || null } : {}),
      ...(mode === "live"  ? { region, scheduledFor } : {}),
    };

    // 🧠 Core enforces governance rules BEFORE we persist
    // (e.g. NO_TOWNHALLS_DURING_POLLING)
    const ruleCheck = await core.emit("discussion.create", {
      prisma,
      discussion: discussionData,
      userId:     req.user.id,
    });

    if (ruleCheck.ruleViolation) {
      return res.status(403).json({
        error: ruleCheck.message,
        rule:  ruleCheck.rule,
      });
    }

    const discussion = await DiscussionThread.create(discussionData);

    res.status(201).json(discussion);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create discussion" });
  }
});

// ── LIST — GET /discussions?mode=async|live ──────────────────────────────────
router.get("/", async (req, res) => {
  try {
    const { mode, topic, region, projectId, status } = req.query;
    if (!mode || !["async", "live"].includes(mode)) {
      return res.status(400).json({ error: "mode query param must be 'async' or 'live'" });
    }

    const discussions = await DiscussionThread.find({
      mode,
      isHidden: false,
      ...(topic     ? { topic }     : {}),
      ...(region    ? { region }    : {}),
      ...(projectId ? { projectId } : {}),
      ...(status    ? { status }    : {}),
    }).sort(mode === "live" ? { scheduledFor: 1 } : { createdAt: -1 });

    res.json(discussions);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch discussions" });
  }
});

// ── GET SINGLE — GET /discussions/:id ───────────────────────────────────────
router.get("/:id", async (req, res) => {
  try {
    const discussion = await DiscussionThread.findById(req.params.id);
    if (!discussion || discussion.isHidden) {
      return res.status(404).json({ error: "Discussion not found" });
    }
    res.json(discussion);
  } catch (err) {
    res.status(404).json({ error: "Discussion not found" });
  }
});

// ── STATUS — PATCH /discussions/:id/status ───────────────────────────────────
router.patch("/:id/status", authMiddleware, async (req, res) => {
  try {
    const { status, transcript } = req.body;
    const discussion = await DiscussionThread.findById(req.params.id);
    if (!discussion) return res.status(404).json({ error: "Discussion not found" });

    if (discussion.mode === "live") {
      if (!["leader", "admin"].includes(req.user.role)) {
        return res.status(403).json({ error: "Insufficient permissions" });
      }
      if (!LIVE_STATUSES.includes(status)) {
        return res.status(400).json({ error: `status must be one of: ${LIVE_STATUSES.join(", ")}` });
      }
    } else {
      const isOwnerOrAdmin = discussion.authorId === req.user.id || req.user.role === "admin";
      if (!isOwnerOrAdmin) return res.status(403).json({ error: "Insufficient permissions" });
      if (!ASYNC_STATUSES.includes(status)) {
        return res.status(400).json({ error: `status must be one of: ${ASYNC_STATUSES.join(", ")}` });
      }
    }

    discussion.status = status;
    if (status === "completed" && transcript) discussion.transcript = transcript;
    await discussion.save();

    // 🧠 Core logs the status transition
    await core.emit("discussion.status_change", {
      prisma,
      discussion,
      newStatus: status,
      userId:    req.user.id,
    });

    res.json(discussion);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update discussion" });
  }
});

// ── ADD ENTRY — POST /discussions/:id/entries ────────────────────────────────
router.post("/:id/entries", authMiddleware, async (req, res) => {
  try {
    const { kind, content, title } = req.body;
    if (!content) return res.status(400).json({ error: "content is required" });

    const discussion = await DiscussionThread.findById(req.params.id);
    if (!discussion || discussion.isHidden) return res.status(404).json({ error: "Discussion not found" });

    const allowedKinds = discussion.mode === "async" ? ["comment"] : ["question", "agenda"];
    if (!allowedKinds.includes(kind)) {
      return res.status(400).json({ error: `kind must be one of: ${allowedKinds.join(", ")} for mode '${discussion.mode}'` });
    }
    if (kind === "agenda" && !title) {
      return res.status(400).json({ error: "title is required for agenda entries" });
    }

    const user = await prisma.user.findUnique({ where: { id: req.user.id } });
    const entry = {
      kind,
      title:      title || null,
      content,
      authorId:   req.user.id,
      authorName: user?.name || "Unknown",
    };

    discussion.entries.push(entry);
    await discussion.save();

    const savedEntry = discussion.entries[discussion.entries.length - 1];

    // 🧠 Core logs the contribution
    await core.emit("discussion.entry.add", {
      prisma,
      discussion,
      entry: savedEntry,
      userId: req.user.id,
    });

    res.status(201).json(discussion);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to add entry" });
  }
});

// ── VOTE ON AGENDA ENTRY ─────────────────────────────────────────────────────
router.post("/:id/entries/:entryId/vote", authMiddleware, async (req, res) => {
  try {
    const discussion = await DiscussionThread.findById(req.params.id);
    if (!discussion) return res.status(404).json({ error: "Discussion not found" });

    const entry = discussion.entries.id(req.params.entryId);
    if (!entry || entry.kind !== "agenda") {
      return res.status(404).json({ error: "Agenda entry not found" });
    }

    const idx = entry.votes.indexOf(req.user.id);
    if (idx >= 0) {
      entry.votes.splice(idx, 1);
    } else {
      entry.votes.push(req.user.id);
    }
    await discussion.save();

    res.json(entry);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to vote on entry" });
  }
});

// ── ANSWER A QUESTION ENTRY ──────────────────────────────────────────────────
router.patch("/:id/entries/:entryId/answer", authMiddleware, requireRole("leader", "admin"), async (req, res) => {
  try {
    const { answer } = req.body;
    if (!answer) return res.status(400).json({ error: "answer is required" });

    const discussion = await DiscussionThread.findById(req.params.id);
    if (!discussion) return res.status(404).json({ error: "Discussion not found" });

    const entry = discussion.entries.id(req.params.entryId);
    if (!entry || entry.kind !== "question") {
      return res.status(404).json({ error: "Question entry not found" });
    }

    entry.answer     = answer;
    entry.answeredAt = new Date();
    await discussion.save();

    res.json(entry);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to answer entry" });
  }
});

// ── MODERATE (admin only) ────────────────────────────────────────────────────
router.patch("/:id/moderate", authMiddleware, requireRole("admin"), async (req, res) => {
  try {
    const { isHidden } = req.body;
    const discussion = await DiscussionThread.findByIdAndUpdate(
      req.params.id,
      { isHidden: !!isHidden, isModerated: true },
      { new: true }
    );
    if (!discussion) return res.status(404).json({ error: "Discussion not found" });

    await logAction(prisma, {
      action:     "discussion.moderate",
      entityType: "DiscussionThread",
      entityId:   discussion.id,
      userId:     req.user.id,
      meta:       { isHidden: !!isHidden },
    });

    res.json(discussion);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to moderate discussion" });
  }
});

module.exports = router;
