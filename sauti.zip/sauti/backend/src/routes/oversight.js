/**
 * Election Stakeholder Oversight Reports
 *
 * Architecture role: structured public accountability documents that can only
 * be CREATED during an active ElectionCycle. Reading is always public.
 *
 * Cycle enforcement:
 *   - POST /oversight  → rejected with 403 + code "NO_ACTIVE_CYCLE" if no cycle active
 *   - GET  /oversight  → always public (transparency records persist after cycle ends)
 *   - PATCH /oversight → allowed outside cycle (stakeholders can amend findings later)
 */

const router    = require("express").Router();
const { PrismaClient } = require("@prisma/client");
const { authMiddleware, requireRole } = require("../middleware/authMiddleware");
const { logAction } = require("../services/auditLogger");
const electionRouter = require("./election");
const core = require("../core/SautiCore");

const prisma = new PrismaClient();

// CREATE (election_stakeholder or admin — only during active cycle)
router.post("/", authMiddleware, requireRole("election_stakeholder", "admin"), async (req, res) => {
  try {
    // ── Election-cycle gate ──────────────────────────────────────────────────
    const activeCycle = await electionRouter.getActiveCycle();
    if (!activeCycle) {
      return res.status(403).json({
        error: "No active election cycle. Oversight reports can only be created during an active election cycle. Ask an admin to activate one.",
        code:  "NO_ACTIVE_CYCLE",
      });
    }

    const { title, summary, region, findings, isPublished } = req.body;
    if (!title || !summary) {
      return res.status(400).json({ error: "title and summary are required" });
    }

    const report = await prisma.oversightReport.create({
      data: {
        title,
        summary,
        region:          region      || null,
        findings:        findings    ? JSON.stringify(findings) : "[]",
        publishedBy:     req.user.id,
        isPublished:     !!isPublished,
        electionCycleId: activeCycle.id,
      },
    });

    await logAction(prisma, {
      action: "oversight.report.create", entityType: "OversightReport",
      entityId: report.id, userId: req.user.id,
      meta: { isPublished: !!isPublished, region, cycleId: activeCycle.id, cycleName: activeCycle.name },
    });

    await core.emit("oversight.publish", { prisma, report, publishedBy: req.user.id });

    res.status(201).json({ ...report, findings: JSON.parse(report.findings) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create oversight report" });
  }
});

// LIST (public sees published; privileged see all)
router.get("/", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    let userRole = null;
    if (authHeader?.startsWith("Bearer ")) {
      try {
        const jwt = require("jsonwebtoken");
        const decoded = jwt.verify(authHeader.split(" ")[1], process.env.JWT_SECRET || "dev_secret_change_me");
        userRole = decoded.role;
      } catch {}
    }
    const isPrivileged = ["election_stakeholder", "admin"].includes(userRole);
    const { region, cycleId } = req.query;

    const reports = await prisma.oversightReport.findMany({
      where: {
        ...(isPrivileged ? {} : { isPublished: true }),
        ...(region  ? { region }              : {}),
        ...(cycleId ? { electionCycleId: cycleId } : {}),
      },
      orderBy: { createdAt: "desc" },
    });

    res.json(reports.map((r) => ({ ...r, findings: JSON.parse(r.findings || "[]") })));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch oversight reports" });
  }
});

// UPDATE / PUBLISH (no cycle requirement for edits)
router.patch("/:id", authMiddleware, requireRole("election_stakeholder", "admin"), async (req, res) => {
  try {
    const { title, summary, region, findings, isPublished } = req.body;
    const existing = await prisma.oversightReport.findUnique({ where: { id: req.params.id } });
    if (!existing) return res.status(404).json({ error: "Report not found" });

    const updated = await prisma.oversightReport.update({
      where: { id: req.params.id },
      data: {
        title:       title       || undefined,
        summary:     summary     || undefined,
        region:      region      ?? undefined,
        findings:    findings    ? JSON.stringify(findings) : undefined,
        isPublished: isPublished != null ? !!isPublished : undefined,
      },
    });

    await logAction(prisma, {
      action: isPublished ? "oversight.report.publish" : "oversight.report.update",
      entityType: "OversightReport", entityId: updated.id, userId: req.user.id,
    });

    res.json({ ...updated, findings: JSON.parse(updated.findings || "[]") });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update oversight report" });
  }
});

module.exports = router;
