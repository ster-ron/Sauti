const router = require("express").Router();
const { PrismaClient } = require("@prisma/client");
const { authMiddleware, requireRole } = require("../middleware/authMiddleware");

const prisma = new PrismaClient();

// LIST AUDIT LOGS (admin only) — immutable civic record
router.get("/", authMiddleware, requireRole("admin"), async (req, res) => {
  try {
    const { entityType, action, entityId, userId, channel, limit, page } = req.query;

    const take = limit ? Math.min(parseInt(limit, 10) || 100, 500) : 100;
    const skip = page  ? (parseInt(page, 10) - 1) * take : 0;

    const logs = await prisma.auditLog.findMany({
      where: {
        ...(entityType ? { entityType } : {}),
        ...(action     ? { action }     : {}),
        ...(entityId   ? { entityId }   : {}),
        ...(userId     ? { userId }     : {}),
        ...(channel    ? { channel }    : {}),
      },
      include: { user: { select: { id: true, name: true, role: true } } },
      orderBy: { createdAt: "desc" },
      take,
      skip,
    });

    const total = await prisma.auditLog.count({
      where: {
        ...(entityType ? { entityType } : {}),
        ...(action     ? { action }     : {}),
        ...(entityId   ? { entityId }   : {}),
        ...(userId     ? { userId }     : {}),
        ...(channel    ? { channel }    : {}),
      },
    });

    res.json({
      logs: logs.map((l) => ({ ...l, meta: l.meta ? JSON.parse(l.meta) : null })),
      total,
      page:  page ? parseInt(page, 10) : 1,
      pages: Math.ceil(total / take),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch audit logs" });
  }
});

// CORRUPTION-SPECIFIC AUDIT TRAIL (election_stakeholder and admin)
// Filters to only corruption.flagged events for quick oversight access
router.get("/corruption", authMiddleware, requireRole("election_stakeholder", "admin"), async (req, res) => {
  try {
    const { region, limit } = req.query;
    const take = limit ? Math.min(parseInt(limit, 10) || 50, 200) : 50;

    const logs = await prisma.auditLog.findMany({
      where: { action: "corruption.flagged" },
      include: { user: { select: { id: true, name: true, role: true } } },
      orderBy: { createdAt: "desc" },
      take,
    });

    res.json(logs.map((l) => ({ ...l, meta: l.meta ? JSON.parse(l.meta) : null })));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch corruption audit log" });
  }
});

module.exports = router;
