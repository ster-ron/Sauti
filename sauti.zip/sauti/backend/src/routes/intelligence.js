const router = require("express").Router();
const { PrismaClient } = require("@prisma/client");
const { generateSummary } = require("../services/intelligenceEngine");
const { authMiddleware, requireRole } = require("../middleware/authMiddleware");

const prisma = new PrismaClient();

// GET CIVIC INTELLIGENCE SUMMARY
// Leaders, election stakeholders, and admins can call this.
// Citizens see a limited public variant without corruption detail.
router.get("/summary", authMiddleware, requireRole("election_stakeholder", "admin", "leader"), async (req, res) => {
  try {
    const { region, ward } = req.query;

    const projectWhere = {
      ...(region ? { region } : {}),
      ...(ward   ? { ward }   : {}),
    };

    const projects = await prisma.project.findMany({ where: projectWhere });
    const reports  = await prisma.report.findMany({
      where: region ? { project: { region } } : {},
    });

    const summary = await generateSummary(projects, reports, prisma);
    res.json(summary);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to generate civic intelligence summary" });
  }
});

// PUBLIC CORRUPTION SIGNALS OVERVIEW (no auth required — transparency)
// Returns only aggregate counts, not project-level detail
router.get("/corruption-overview", async (req, res) => {
  try {
    const { region } = req.query;

    const projects = await prisma.project.findMany({
      where: { ...(region ? { region } : {}) },
      select: { corruptionRiskLevel: true, corruptionFlags: true, region: true, category: true },
    });

    const overview = {
      total:    projects.length,
      none:     projects.filter((p) => p.corruptionRiskLevel === "none").length,
      low:      projects.filter((p) => p.corruptionRiskLevel === "low").length,
      medium:   projects.filter((p) => p.corruptionRiskLevel === "medium").length,
      high:     projects.filter((p) => p.corruptionRiskLevel === "high").length,
      critical: projects.filter((p) => p.corruptionRiskLevel === "critical").length,
    };

    // Aggregate unique flag types across all projects
    const flagFrequency = {};
    for (const p of projects) {
      if (p.corruptionFlags) {
        const flags = JSON.parse(p.corruptionFlags);
        for (const f of flags) {
          flagFrequency[f] = (flagFrequency[f] || 0) + 1;
        }
      }
    }

    const topFlags = Object.entries(flagFrequency)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([flag, count]) => ({ flag, count }));

    res.json({ overview, topFlags, generatedAt: new Date().toISOString() });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch corruption overview" });
  }
});

module.exports = router;
