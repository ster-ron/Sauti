const router = require("express").Router();
const { PrismaClient } = require("@prisma/client");
const { authMiddleware } = require("../middleware/authMiddleware");
const { logAction } = require("../services/auditLogger");
const core = require("../core/SautiCore");

const prisma = new PrismaClient();

function publicReport(r) {
  if (!r.isAnonymous) return r;
  const { userId, user, ...rest } = r;
  // Precise coordinates + content + timestamp can be enough to re-identify
  // a whistleblower even with identity stripped (e.g. "the one report from
  // that exact GPS point last Tuesday"). Round to ~1.1km precision instead
  // of dropping location entirely — keeps the report useful on the project
  // map (which area) without pinpointing the reporter.
  const coarsen = (n) => (n == null ? null : Math.round(n * 100) / 100);
  return {
    ...rest,
    userId: null,
    user: null,
    latitude: coarsen(rest.latitude),
    longitude: coarsen(rest.longitude),
  };
}

// CREATE REPORT — Evidence Layer
router.post("/", authMiddleware, async (req, res) => {
  try {
    const {
      content, imageUrl, videoUrl, location,
      latitude, longitude, projectId, isAnonymous, channel,
      mediaIds,
    } = req.body;

    if (!content) return res.status(400).json({ error: "content is required" });

    // Fetch reporter's trust score to stamp on this report
    const reporter = await prisma.user.findUnique({
      where:  { id: req.user.id },
      select: { trustScore: true },
    });

    const report = await prisma.report.create({
      data: {
        content,
        imageUrl:            imageUrl  || null,
        videoUrl:            videoUrl  || null,
        location:            location  || null,
        latitude:            latitude  != null ? parseFloat(latitude)  : null,
        longitude:           longitude != null ? parseFloat(longitude) : null,
        projectId:           projectId || null,
        userId:              req.user.id,
        isAnonymous:         !!isAnonymous,
        channel:             channel || "web",
        reporterTrustWeight: reporter?.trustScore ?? 50,
      },
    });

    // Link any pre-uploaded MediaEvidence records to this report
    if (mediaIds?.length) {
      await prisma.mediaEvidence.updateMany({
        where: { id: { in: mediaIds }, uploadedBy: req.user.id },
        data:  { reportId: report.id },
      });
    }

    // Increment reporter's report count
    await prisma.user.update({
      where: { id: req.user.id },
      data:  { reportCount: { increment: 1 } },
    });

    await logAction(prisma, {
      action:     "report.submit",
      entityType: "Report",
      entityId:   report.id,
      userId:     req.user.id,
      channel:    channel || "web",
      meta: {
        projectId:  projectId || null,
        anonymous:  !!isAnonymous,
        channel:    channel || "web",
        mediaCount: mediaIds?.length || 0,
        trustWeight: reporter?.trustScore ?? 50,
      },
    });

    // 🧠 Delegate all downstream side-effects to the Core
    await core.emit("report.submit", {
      prisma,
      report,
      userId:    req.user.id,
      projectId: projectId || null,
      channel:   channel || "web",
    });

    res.status(201).json(publicReport(report));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create report" });
  }
});

// GET ALL REPORTS
router.get("/", async (req, res, next) => {
  if (req.query.mine === "true") return authMiddleware(req, res, next);
  next();
}, async (req, res) => {
  try {
    const { projectId, channel, mine } = req.query;

    const reports = await prisma.report.findMany({
      where: {
        ...(projectId ? { projectId } : {}),
        ...(channel   ? { channel }   : {}),
        ...(mine === "true" ? { userId: req.user.id } : {}),
      },
      include: {
        user:    { select: { id: true, name: true, trustScore: true } },
        project: { select: { id: true, title: true } },
        media: {
          where:   { moderationStatus: { not: "removed" } },
          orderBy: { createdAt: "asc" },
          select:  { id: true, url: true, thumbnailUrl: true, mediaType: true, latitude: true, longitude: true },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    res.json(reports.map(publicReport));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch reports" });
  }
});

// UPVOTE — community verification signal
router.post("/:id/upvote", authMiddleware, async (req, res) => {
  try {
    const report = await prisma.report.update({
      where: { id: req.params.id },
      data:  { upvotes: { increment: 1 } },
    });

    // 🧠 Core handles trust nudge + engine re-run
    await core.emit("report.upvote", { prisma, report });

    res.json(report);
  } catch (err) {
    res.status(500).json({ error: "Failed to upvote report" });
  }
});

module.exports = router;
