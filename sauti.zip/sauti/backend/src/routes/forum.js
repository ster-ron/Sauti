/**
 * Civic Forum Engine — DEPRECATED ROUTE SURFACE.
 *
 * This now reads/writes the same DiscussionThread collection as
 * /discussions (mode="async"), via the shared discussions router.
 * It exists only so the current frontend (pages/forums.js) keeps working
 * unmodified while it migrates to calling /discussions?mode=async directly.
 *
 * New code should use /discussions. Remove this file once the frontend
 * migration in pages/forums.js is complete.
 */
const router = require("express").Router();
const DiscussionThread = require("../models/DiscussionThread");
const { authMiddleware, requireRole } = require("../middleware/authMiddleware");
const { PrismaClient } = require("@prisma/client");
const { logAction } = require("../services/auditLogger");

const prisma = new PrismaClient();
const TOPICS = ["water", "roads", "health", "education", "security", "other"];

// Shape a DiscussionThread doc back into the old ForumThread JSON contract
function toLegacyThread(d) {
  return {
    _id: d._id,
    topic: d.topic,
    title: d.title,
    content: d.description,
    userId: d.authorId,
    userName: d.authorName,
    projectId: d.projectId,
    replies: d.entries
      .filter((e) => e.kind === "comment")
      .map((e) => ({ _id: e._id, userId: e.authorId, userName: e.authorName, content: e.content, createdAt: e.createdAt })),
    isModerated: d.isModerated,
    isHidden: d.isHidden,
    createdAt: d.createdAt,
    updatedAt: d.updatedAt,
  };
}

router.post("/threads", authMiddleware, async (req, res) => {
  try {
    const { topic, title, content, projectId } = req.body;
    if (!title || !content) return res.status(400).json({ error: "title and content are required" });
    if (topic && !TOPICS.includes(topic)) {
      return res.status(400).json({ error: `topic must be one of: ${TOPICS.join(", ")}` });
    }

    const user = await prisma.user.findUnique({ where: { id: req.user.id } });
    const discussion = await DiscussionThread.create({
      mode: "async",
      status: "open",
      topic: topic || "other",
      title,
      description: content,
      authorId: req.user.id,
      authorName: user?.name || "Unknown",
      projectId: projectId || null,
    });

    await logAction(prisma, { action: "forum.thread.create", entityType: "DiscussionThread", entityId: discussion.id, userId: req.user.id });
    res.status(201).json(toLegacyThread(discussion));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create thread" });
  }
});

router.get("/threads", async (req, res) => {
  try {
    const { topic, projectId } = req.query;
    const discussions = await DiscussionThread.find({
      mode: "async",
      isHidden: false,
      ...(topic ? { topic } : {}),
      ...(projectId ? { projectId } : {}),
    }).sort({ createdAt: -1 });
    res.json(discussions.map(toLegacyThread));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch threads" });
  }
});

router.get("/threads/:id", async (req, res) => {
  try {
    const discussion = await DiscussionThread.findOne({ _id: req.params.id, mode: "async" });
    if (!discussion || discussion.isHidden) return res.status(404).json({ error: "Thread not found" });
    res.json(toLegacyThread(discussion));
  } catch (err) {
    res.status(404).json({ error: "Thread not found" });
  }
});

router.post("/threads/:id/replies", authMiddleware, async (req, res) => {
  try {
    const { content } = req.body;
    if (!content) return res.status(400).json({ error: "content is required" });

    const user = await prisma.user.findUnique({ where: { id: req.user.id } });
    const discussion = await DiscussionThread.findOne({ _id: req.params.id, mode: "async" });
    if (!discussion || discussion.isHidden) return res.status(404).json({ error: "Thread not found" });

    discussion.entries.push({ kind: "comment", content, authorId: req.user.id, authorName: user?.name || "Unknown" });
    await discussion.save();

    res.status(201).json(toLegacyThread(discussion));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to add reply" });
  }
});

router.patch("/threads/:id/moderate", authMiddleware, requireRole("admin"), async (req, res) => {
  try {
    const { isHidden } = req.body;
    const discussion = await DiscussionThread.findOneAndUpdate(
      { _id: req.params.id, mode: "async" },
      { isHidden: !!isHidden, isModerated: true },
      { new: true }
    );
    if (!discussion) return res.status(404).json({ error: "Thread not found" });

    await logAction(prisma, {
      action: "forum.thread.moderate",
      entityType: "DiscussionThread",
      entityId: discussion.id,
      userId: req.user.id,
      meta: { isHidden: !!isHidden },
    });

    res.json(toLegacyThread(discussion));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to moderate thread" });
  }
});

module.exports = router;
