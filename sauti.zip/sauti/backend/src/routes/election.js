/**
 * Election Cycle Engine
 *
 * Architecture role: time-gates the entire Election Stakeholder module.
 * - Only one ElectionCycle can have activeFlag = true at a time.
 * - Oversight reports and manifesto tracking enforce cycle-awareness.
 * - Phase changes (pre_election → campaign → polling → post_election → transition)
 *   drive what actions are available to each role.
 *
 * Access matrix:
 *   GET  /election/cycles          → public (all)
 *   GET  /election/cycles/active   → public
 *   POST /election/cycles          → admin only
 *   PATCH /election/cycles/:id     → admin only
 *   POST /election/cycles/:id/activate  → admin only
 *
 *   GET  /election/manifesto              → public
 *   POST /election/manifesto              → leader only
 *   PATCH /election/manifesto/:id         → leader (own) or admin
 *   PATCH /election/manifesto/:id/link    → leader (own) or admin — links a Project
 *   GET  /election/manifesto/leader/:lid  → public
 */

const router = require("express").Router();
const { PrismaClient } = require("@prisma/client");
const { authMiddleware, requireRole } = require("../middleware/authMiddleware");
const { logAction } = require("../services/auditLogger");
const core           = require("../core/SautiCore");

const prisma = new PrismaClient();

// ── Helpers ───────────────────────────────────────────────────────────────────

const PHASES = ["pre_election", "campaign", "polling", "post_election", "transition"];

/**
 * Fetch the single active election cycle (if any).
 * Returns null when no cycle is active — callers use this to gate features.
 */
async function getActiveCycle() {
  return prisma.electionCycle.findFirst({ where: { activeFlag: true } });
}

/**
 * Compute a delivery score for a manifesto promise:
 *   - No linked project → score based on status enum
 *   - Linked project    → mirrors project.verificationScore
 */
function computeDeliveryScore(promise) {
  if (promise.linkedProjectId && promise.deliveryScore != null) {
    return promise.deliveryScore;
  }
  const statusMap = {
    promised:             0.0,
    in_progress:          0.4,
    partially_delivered:  0.6,
    delivered:            1.0,
    broken:               0.0,
  };
  return statusMap[promise.status] ?? 0;
}

// ═══════════════════════════════════════════════════════════════════
// ELECTION CYCLE ROUTES
// ═══════════════════════════════════════════════════════════════════

// LIST cycles (public)
router.get("/cycles", async (req, res) => {
  try {
    const cycles = await prisma.electionCycle.findMany({
      orderBy: { startDate: "desc" },
      include: { _count: { select: { manifestoPromises: true } } },
    });
    res.json(cycles);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch election cycles" });
  }
});

// GET active cycle (public — used by UI to gate election features)
router.get("/cycles/active", async (req, res) => {
  try {
    const cycle = await getActiveCycle();
    res.json(cycle || { active: false });
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch active cycle" });
  }
});

// CREATE cycle (admin)
router.post("/cycles", authMiddleware, requireRole("admin"), async (req, res) => {
  try {
    const { name, region, startDate, endDate, phase, description } = req.body;
    if (!name || !startDate || !endDate) {
      return res.status(400).json({ error: "name, startDate, endDate are required" });
    }
    if (!PHASES.includes(phase || "pre_election")) {
      return res.status(400).json({ error: `phase must be one of: ${PHASES.join(", ")}` });
    }

    const cycle = await prisma.electionCycle.create({
      data: {
        name,
        region:      region      || null,
        startDate:   new Date(startDate),
        endDate:     new Date(endDate),
        phase:       phase       || "pre_election",
        description: description || null,
        activeFlag:  false, // always starts inactive — use /activate
        createdBy:   req.user.id,
      },
    });

    await logAction(prisma, {
      action: "election.cycle.create", entityType: "ElectionCycle",
      entityId: cycle.id, userId: req.user.id, meta: { name, phase },
    });

    res.status(201).json(cycle);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create election cycle" });
  }
});

// ACTIVATE a cycle — Core enforces single-active-cycle invariant
router.post("/cycles/:id/activate", authMiddleware, requireRole("admin"), async (req, res) => {
  try {
    // IMPORTANT: deactivate every other cycle BEFORE flipping this one on.
    // The partial unique index (WHERE "activeFlag" = true) means setting this
    // cycle to true while another is still true throws a constraint violation —
    // so order matters, and both writes must happen in one transaction so a
    // crash between them can never leave zero (or two) active cycles.
    const cycle = await prisma.$transaction(async (tx) => {
      await tx.electionCycle.updateMany({
        where: { id: { not: req.params.id }, activeFlag: true },
        data: { activeFlag: false },
      });
      return tx.electionCycle.update({
        where: { id: req.params.id },
        data: { activeFlag: true },
      });
    });

    await logAction(prisma, {
      action: "election.cycle.activated",
      entityType: "ElectionCycle",
      entityId: cycle.id,
      userId: req.user.id,
      meta: { enforcedBy: "election.cycles.activate route (transactional)" },
    });

    res.json(cycle);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to activate cycle" });
  }
});

// DEACTIVATE (admin)
router.post("/cycles/:id/deactivate", authMiddleware, requireRole("admin"), async (req, res) => {
  try {
    const cycle = await prisma.electionCycle.update({
      where: { id: req.params.id },
      data:  { activeFlag: false },
    });
    await logAction(prisma, {
      action: "election.cycle.deactivate", entityType: "ElectionCycle",
      entityId: cycle.id, userId: req.user.id,
    });
    res.json(cycle);
  } catch (err) {
    res.status(500).json({ error: "Failed to deactivate cycle" });
  }
});

// UPDATE cycle phase / metadata (admin)
router.patch("/cycles/:id", authMiddleware, requireRole("admin"), async (req, res) => {
  try {
    const { name, region, startDate, endDate, phase, description } = req.body;
    if (phase && !PHASES.includes(phase)) {
      return res.status(400).json({ error: `phase must be one of: ${PHASES.join(", ")}` });
    }

    const existing = await prisma.electionCycle.findUnique({ where: { id: req.params.id } });
    if (!existing) return res.status(404).json({ error: "Cycle not found" });

    const cycle = await prisma.electionCycle.update({
      where: { id: req.params.id },
      data: {
        name:        name        || undefined,
        region:      region      ?? undefined,
        startDate:   startDate   ? new Date(startDate) : undefined,
        endDate:     endDate     ? new Date(endDate)   : undefined,
        phase:       phase       || undefined,
        description: description ?? undefined,
      },
    });

    // 🧠 Core handles phase-change consequences and returns advisories
    if (phase && phase !== existing.phase) {
      const phaseResult = await core.emit("election.phase_change", {
        prisma, cycle, newPhase: phase, adminId: req.user.id,
      });
      return res.json({ ...cycle, _coreAdvisory: phaseResult.advisory ?? null });
    }

    await logAction(prisma, {
      action: "election.cycle.update", entityType: "ElectionCycle",
      entityId: cycle.id, userId: req.user.id, meta: { phase },
    });

    res.json(cycle);
  } catch (err) {
    res.status(500).json({ error: "Failed to update cycle" });
  }
});

// ═══════════════════════════════════════════════════════════════════
// MANIFESTO PROMISE ROUTES
// ═══════════════════════════════════════════════════════════════════

// LIST all promises — optionally filter by cycle or leader (public)
router.get("/manifesto", async (req, res) => {
  try {
    const { cycleId, leaderId, status, category } = req.query;

    const promises = await prisma.manifestoPromise.findMany({
      where: {
        ...(cycleId  ? { electionCycleId: cycleId }  : {}),
        ...(leaderId ? { leaderId }                   : {}),
        ...(status   ? { status }                     : {}),
        ...(category ? { category }                   : {}),
      },
      include: { electionCycle: { select: { name: true, activeFlag: true, phase: true } } },
      orderBy: { createdAt: "desc" },
    });

    // Enrich with computed delivery score
    const enriched = promises.map((p) => ({
      ...p,
      computedDeliveryScore: computeDeliveryScore(p),
    }));

    res.json(enriched);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch manifesto promises" });
  }
});

// GET promises for a specific leader (public profile view)
router.get("/manifesto/leader/:leaderId", async (req, res) => {
  try {
    const { cycleId } = req.query;

    const [leader, promises] = await Promise.all([
      prisma.user.findUnique({
        where: { id: req.params.leaderId },
        select: { id: true, name: true, title: true, constituency: true, ward: true, accountabilityScore: true },
      }),
      prisma.manifestoPromise.findMany({
        where: {
          leaderId: req.params.leaderId,
          ...(cycleId ? { electionCycleId: cycleId } : {}),
        },
        include: { electionCycle: { select: { name: true, activeFlag: true } } },
        orderBy: { createdAt: "desc" },
      }),
    ]);

    if (!leader) return res.status(404).json({ error: "Leader not found" });

    const stats = {
      total:              promises.length,
      delivered:          promises.filter((p) => p.status === "delivered").length,
      in_progress:        promises.filter((p) => p.status === "in_progress").length,
      broken:             promises.filter((p) => p.status === "broken").length,
      partially_delivered: promises.filter((p) => p.status === "partially_delivered").length,
      promised:           promises.filter((p) => p.status === "promised").length,
      avgDeliveryScore:   promises.length
        ? Math.round((promises.reduce((s, p) => s + computeDeliveryScore(p), 0) / promises.length) * 100)
        : 0,
    };

    res.json({
      leader,
      promises: promises.map((p) => ({ ...p, computedDeliveryScore: computeDeliveryScore(p) })),
      stats,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch leader manifesto" });
  }
});

// CREATE a manifesto promise (leader — linked to active election cycle)
router.post("/manifesto", authMiddleware, requireRole("leader", "admin"), async (req, res) => {
  try {
    // Enforce: only allowed during an active election cycle
    const activeCycle = await getActiveCycle();
    if (!activeCycle) {
      return res.status(403).json({
        error: "No active election cycle. Manifesto promises can only be created during an active election cycle.",
        code:  "NO_ACTIVE_CYCLE",
      });
    }

    const { title, description, category, region, targetDate, budgetCommitted, electionCycleId } = req.body;
    if (!title || !description) {
      return res.status(400).json({ error: "title and description are required" });
    }

    // Leaders can only create for themselves; admins can specify leaderId
    const leaderId = req.user.role === "admin" && req.body.leaderId
      ? req.body.leaderId
      : req.user.id;

    const cycleId = electionCycleId || activeCycle.id;

    const promise = await prisma.manifestoPromise.create({
      data: {
        leaderId,
        electionCycleId: cycleId,
        title,
        description,
        category:        category        || null,
        region:          region          || null,
        targetDate:      targetDate      ? new Date(targetDate) : null,
        budgetCommitted: budgetCommitted ? parseFloat(budgetCommitted) : null,
        status:          "promised",
      },
      include: { electionCycle: { select: { name: true, phase: true } } },
    });

    await logAction(prisma, {
      action: "election.manifesto.create", entityType: "ManifestoPromise",
      entityId: promise.id, userId: req.user.id, meta: { cycleId, title },
    });

    res.status(201).json(promise);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create manifesto promise" });
  }
});

// UPDATE promise status (leader — own only; admin — any)
router.patch("/manifesto/:id", authMiddleware, requireRole("leader", "admin", "election_stakeholder"), async (req, res) => {
  try {
    const existing = await prisma.manifestoPromise.findUnique({ where: { id: req.params.id } });
    if (!existing) return res.status(404).json({ error: "Promise not found" });

    // Leaders can only edit their own promises
    if (req.user.role === "leader" && existing.leaderId !== req.user.id) {
      return res.status(403).json({ error: "Cannot edit another leader's promise" });
    }

    // election_stakeholders can only update deliveryEvidence (read/annotate, not status)
    const { status, deliveryEvidence, targetDate, budgetCommitted } = req.body;

    const VALID_STATUSES = ["promised", "in_progress", "partially_delivered", "delivered", "broken"];
    if (status && !VALID_STATUSES.includes(status)) {
      return res.status(400).json({ error: `status must be one of: ${VALID_STATUSES.join(", ")}` });
    }

    const updated = await prisma.manifestoPromise.update({
      where: { id: req.params.id },
      data: {
        ...(req.user.role !== "election_stakeholder" && status ? { status } : {}),
        ...(deliveryEvidence != null ? { deliveryEvidence: JSON.stringify(deliveryEvidence) } : {}),
        ...(targetDate       ? { targetDate: new Date(targetDate) } : {}),
        ...(budgetCommitted  ? { budgetCommitted: parseFloat(budgetCommitted) } : {}),
      },
      include: { electionCycle: { select: { name: true } } },
    });

    await logAction(prisma, {
      action: "election.manifesto.update", entityType: "ManifestoPromise",
      entityId: updated.id, userId: req.user.id, meta: { status },
    });

    res.json({ ...updated, computedDeliveryScore: computeDeliveryScore(updated) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update manifesto promise" });
  }
});

// LINK a manifesto promise to a concrete Project (leader or admin)
router.patch("/manifesto/:id/link", authMiddleware, requireRole("leader", "admin"), async (req, res) => {
  try {
    const { projectId } = req.body;
    if (!projectId) return res.status(400).json({ error: "projectId is required" });

    const [existing, project] = await Promise.all([
      prisma.manifestoPromise.findUnique({ where: { id: req.params.id } }),
      prisma.project.findUnique({ where: { id: projectId }, select: { id: true, verificationScore: true } }),
    ]);

    if (!existing) return res.status(404).json({ error: "Promise not found" });
    if (!project)  return res.status(404).json({ error: "Project not found" });
    if (req.user.role === "leader" && existing.leaderId !== req.user.id) {
      return res.status(403).json({ error: "Cannot link another leader's promise" });
    }

    const updated = await prisma.manifestoPromise.update({
      where: { id: req.params.id },
      data: {
        linkedProjectId: projectId,
        deliveryScore:   project.verificationScore || 0,
        // Auto-promote status if project is verified
        status: project.verificationScore >= 0.8 ? "delivered"
               : project.verificationScore >= 0.4 ? "in_progress"
               : existing.status,
      },
    });

    await logAction(prisma, {
      action: "election.manifesto.link_project", entityType: "ManifestoPromise",
      entityId: updated.id, userId: req.user.id, meta: { projectId },
    });

    res.json({ ...updated, computedDeliveryScore: computeDeliveryScore(updated) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to link project to promise" });
  }
});

// CYCLE-SCOPED SUMMARY — aggregate delivery stats for a given cycle (public)
router.get("/cycles/:id/summary", async (req, res) => {
  try {
    const cycle = await prisma.electionCycle.findUnique({
      where:   { id: req.params.id },
      include: { manifestoPromises: true },
    });
    if (!cycle) return res.status(404).json({ error: "Cycle not found" });

    const promises = cycle.manifestoPromises;
    const byStatus = {};
    const byCategory = {};

    for (const p of promises) {
      byStatus[p.status]      = (byStatus[p.status] || 0) + 1;
      const cat = p.category || "other";
      byCategory[cat]         = (byCategory[cat] || 0) + 1;
    }

    const avgDelivery = promises.length
      ? Math.round((promises.reduce((s, p) => s + computeDeliveryScore(p), 0) / promises.length) * 100)
      : 0;

    const daysRemaining = Math.max(0, Math.ceil((new Date(cycle.endDate) - new Date()) / (1000 * 60 * 60 * 24)));

    res.json({
      cycle: {
        id:        cycle.id,
        name:      cycle.name,
        phase:     cycle.phase,
        activeFlag: cycle.activeFlag,
        startDate: cycle.startDate,
        endDate:   cycle.endDate,
        daysRemaining,
      },
      summary: {
        totalPromises: promises.length,
        byStatus,
        byCategory,
        avgDeliveryScore: avgDelivery,
        deliveredCount:   byStatus.delivered || 0,
        brokenCount:      byStatus.broken    || 0,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to compute cycle summary" });
  }
});

// ACTIVE CYCLE GUARD — middleware export for other routes that need cycle-gating
router.getActiveCycle = getActiveCycle;

module.exports = router;
