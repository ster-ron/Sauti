/**
 * Town Hall Engine — DEPRECATED ROUTE SURFACE.
 *
 * This now reads/writes the same DiscussionThread collection as
 * /discussions (mode="live"), via the shared discussions router.
 * It exists only so the current frontend (pages/townhalls.js) keeps working
 * unmodified while it migrates to calling /discussions?mode=live directly.
 *
 * New code should use /discussions. Remove this file once the frontend
 * migration in pages/townhalls.js is complete.
 */
const router = require("express").Router();
const DiscussionThread = require("../models/DiscussionThread");
const { authMiddleware, requireRole } = require("../middleware/authMiddleware");
const { PrismaClient } = require("@prisma/client");
const { logAction } = require("../services/auditLogger");

const prisma = new PrismaClient();
const STATUSES = ["scheduled", "live", "completed", "cancelled"];

// Shape a DiscussionThread doc back into the old TownHall JSON contract
function toLegacyTownHall(d) {
  return {
    _id: d._id,
    title: d.title,
    region: d.region,
    leaderId: d.authorId,
    leaderName: d.authorName,
    scheduledFor: d.scheduledFor,
    status: d.status,
    agendaItems: d.entries
      .filter((e) => e.kind === "agenda")
      .map((e) => ({ _id: e._id, title: e.title, description: e.content, upvotes: e.votes })),
    qa: d.entries
      .filter((e) => e.kind === "question")
      .map((e) => ({ _id: e._id, question: e.content, askedBy: e.authorId, askedByName: e.authorName, answer: e.answer, answeredAt: e.answeredAt })),
    transcript: d.transcript,
    createdAt: d.createdAt,
    updatedAt: d.updatedAt,
  };
}

router.post("/", authMiddleware, requireRole("leader", "admin"), async (req, res) => {
  try {
    const { title, region, scheduledFor, agendaItems } = req.body;
    if (!title || !region || !scheduledFor) {
      return res.status(400).json({ error: "title, region, and scheduledFor are required" });
    }

    const leader = await prisma.user.findUnique({ where: { id: req.user.id } });
    const discussion = await DiscussionThread.create({
      mode: "live",
      status: "scheduled",
      title,
      description: title,
      region,
      scheduledFor,
      authorId: req.user.id,
      authorName: leader?.name || "Unknown",
      entries: (agendaItems || []).map((a) => ({
        kind: "agenda",
        title: a.title,
        content: a.description || "",
        authorId: req.user.id,
        authorName: leader?.name || "Unknown",
      })),
    });

    await logAction(prisma, { action: "townhall.create", entityType: "DiscussionThread", entityId: discussion.id, userId: req.user.id });
    res.status(201).json(toLegacyTownHall(discussion));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to schedule town hall" });
  }
});

router.get("/", async (req, res) => {
  try {
    const { region, status } = req.query;
    const discussions = await DiscussionThread.find({
      mode: "live",
      ...(region ? { region } : {}),
      ...(status ? { status } : {}),
    }).sort({ scheduledFor: 1 });
    res.json(discussions.map(toLegacyTownHall));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch town halls" });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const discussion = await DiscussionThread.findOne({ _id: req.params.id, mode: "live" });
    if (!discussion) return res.status(404).json({ error: "Town hall not found" });
    res.json(toLegacyTownHall(discussion));
  } catch (err) {
    res.status(404).json({ error: "Town hall not found" });
  }
});

router.patch("/:id/status", authMiddleware, requireRole("leader", "admin"), async (req, res) => {
  try {
    const { status, transcript } = req.body;
    if (!STATUSES.includes(status)) {
      return res.status(400).json({ error: `status must be one of: ${STATUSES.join(", ")}` });
    }

    const discussion = await DiscussionThread.findOne({ _id: req.params.id, mode: "live" });
    if (!discussion) return res.status(404).json({ error: "Town hall not found" });

    discussion.status = status;
    if (status === "completed" && transcript) discussion.transcript = transcript;
    await discussion.save();

    await logAction(prisma, { action: "townhall.status_change", entityType: "DiscussionThread", entityId: discussion.id, userId: req.user.id, meta: { status } });
    res.json(toLegacyTownHall(discussion));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update town hall" });
  }
});

router.post("/:id/agenda", authMiddleware, async (req, res) => {
  try {
    const { title, description } = req.body;
    if (!title) return res.status(400).json({ error: "title is required" });

    const user = await prisma.user.findUnique({ where: { id: req.user.id } });
    const discussion = await DiscussionThread.findOne({ _id: req.params.id, mode: "live" });
    if (!discussion) return res.status(404).json({ error: "Town hall not found" });

    discussion.entries.push({ kind: "agenda", title, content: description || "", authorId: req.user.id, authorName: user?.name || "Unknown" });
    await discussion.save();

    res.status(201).json(toLegacyTownHall(discussion));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to add agenda item" });
  }
});

router.post("/:id/agenda/:itemId/vote", authMiddleware, async (req, res) => {
  try {
    const discussion = await DiscussionThread.findOne({ _id: req.params.id, mode: "live" });
    if (!discussion) return res.status(404).json({ error: "Town hall not found" });

    const entry = discussion.entries.id(req.params.itemId);
    if (!entry || entry.kind !== "agenda") return res.status(404).json({ error: "Agenda item not found" });

    const idx = entry.votes.indexOf(req.user.id);
    if (idx >= 0) entry.votes.splice(idx, 1);
    else entry.votes.push(req.user.id);
    await discussion.save();

    res.json({ _id: entry._id, title: entry.title, description: entry.content, upvotes: entry.votes });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to vote on agenda item" });
  }
});

router.post("/:id/qa", authMiddleware, async (req, res) => {
  try {
    const { question } = req.body;
    if (!question) return res.status(400).json({ error: "question is required" });

    const user = await prisma.user.findUnique({ where: { id: req.user.id } });
    const discussion = await DiscussionThread.findOne({ _id: req.params.id, mode: "live" });
    if (!discussion) return res.status(404).json({ error: "Town hall not found" });

    discussion.entries.push({ kind: "question", content: question, authorId: req.user.id, authorName: user?.name || "Unknown" });
    await discussion.save();

    res.status(201).json(toLegacyTownHall(discussion));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to submit question" });
  }
});

router.patch("/:id/qa/:qaId/answer", authMiddleware, requireRole("leader", "admin"), async (req, res) => {
  try {
    const { answer } = req.body;
    if (!answer) return res.status(400).json({ error: "answer is required" });

    const discussion = await DiscussionThread.findOne({ _id: req.params.id, mode: "live" });
    if (!discussion) return res.status(404).json({ error: "Town hall not found" });

    const entry = discussion.entries.id(req.params.qaId);
    if (!entry || entry.kind !== "question") return res.status(404).json({ error: "Question not found" });

    entry.answer = answer;
    entry.answeredAt = new Date();
    await discussion.save();

    res.json({ _id: entry._id, question: entry.content, askedBy: entry.authorId, askedByName: entry.authorName, answer: entry.answer, answeredAt: entry.answeredAt });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to answer question" });
  }
});

module.exports = router;
