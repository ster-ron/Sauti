const router = require("express").Router();
const { PrismaClient } = require("@prisma/client");
const { authMiddleware, requireRole } = require("../middleware/authMiddleware");
const { logAction } = require("../services/auditLogger");
const core = require("../core/SautiCore");

const prisma = new PrismaClient();

// CREATE PROJECT (leader or admin) — Accountability Engine
router.post("/", authMiddleware, requireRole("leader", "admin"), async (req, res) => {
  try {
    const {
      title, description, location, region, ward, category,
      budget, budgetSpent, status, latitude, longitude, startDate, endDate,
    } = req.body;

    if (!title || !description) {
      return res.status(400).json({ error: "title and description are required" });
    }

    const project = await prisma.project.create({
      data: {
        title, description, location, region, ward, category,
        budget:      budget      ? parseFloat(budget)      : null,
        budgetSpent: budgetSpent ? parseFloat(budgetSpent) : null,
        status:      status || "planned",
        latitude:    latitude  != null ? parseFloat(latitude)  : null,
        longitude:   longitude != null ? parseFloat(longitude) : null,
        startDate:   startDate ? new Date(startDate)   : null,
        endDate:     endDate   ? new Date(endDate)     : null,
        createdBy:   req.user.id,
      },
    });

    await logAction(prisma, {
      action:     "project.create",
      entityType: "Project",
      entityId:   project.id,
      userId:     req.user.id,
    });

    // 🧠 Core initialises verification state + accountability score
    await core.emit("project.create", { prisma, project, userId: req.user.id });

    res.status(201).json(project);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create project" });
  }
});

// GET ALL PROJECTS (public)
router.get("/", async (req, res) => {
  try {
    const { region, status, ward, category, corruptionRiskLevel, createdBy } = req.query;

    const projects = await prisma.project.findMany({
      where: {
        ...(region              ? { region }              : {}),
        ...(status              ? { status }              : {}),
        ...(ward                ? { ward }                : {}),
        ...(category            ? { category }            : {}),
        ...(corruptionRiskLevel ? { corruptionRiskLevel } : {}),
        ...(createdBy           ? { createdBy }           : {}),
      },
      include: {
        reports: { select: { id: true, content: true, createdAt: true, isAnonymous: true } },
        creator: { select: { id: true, name: true, title: true, constituency: true } },
      },
      orderBy: { createdAt: "desc" },
    });
    res.json(projects);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch projects" });
  }
});

// GET SINGLE PROJECT
router.get("/:id", async (req, res) => {
  try {
    const project = await prisma.project.findUnique({
      where:   { id: req.params.id },
      include: {
        reports: { include: { user: { select: { id: true, name: true } } } },
        creator: { select: { id: true, name: true, title: true, constituency: true } },
      },
    });
    if (!project) return res.status(404).json({ error: "Project not found" });
    res.json(project);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch project" });
  }
});

// UPDATE PROJECT
router.patch("/:id", authMiddleware, requireRole("leader", "admin"), async (req, res) => {
  try {
    const existing = await prisma.project.findUnique({ where: { id: req.params.id } });
    if (!existing) return res.status(404).json({ error: "Project not found" });

    if (req.user.role !== "admin" && existing.createdBy !== req.user.id) {
      return res.status(403).json({ error: "Not your project" });
    }

    const {
      title, description, location, region, ward, category,
      budget, budgetSpent, status, latitude, longitude, startDate, endDate,
    } = req.body;

    const project = await prisma.project.update({
      where: { id: req.params.id },
      data:  {
        title, description, location, region, ward, category,
        budget:      budget      != null ? parseFloat(budget)      : undefined,
        budgetSpent: budgetSpent != null ? parseFloat(budgetSpent) : undefined,
        status,
        latitude:  latitude  != null ? parseFloat(latitude)  : undefined,
        longitude: longitude != null ? parseFloat(longitude) : undefined,
        startDate: startDate ? new Date(startDate) : undefined,
        endDate:   endDate   ? new Date(endDate)   : undefined,
      },
    });

    await logAction(prisma, {
      action:     "project.update",
      entityType: "Project",
      entityId:   project.id,
      userId:     req.user.id,
      meta:       { changes: Object.keys(req.body) },
    });

    // 🧠 Core re-runs engines and refreshes accountability score
    await core.emit("project.update", {
      prisma,
      projectId:  project.id,
      updatedBy:  req.user.id,
    });

    res.json(project);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update project" });
  }
});

// RECOMPUTE VERIFICATION — manual trigger
router.post("/:id/recompute-verification", authMiddleware, async (req, res) => {
  try {
    const existing = await prisma.project.findUnique({ where: { id: req.params.id } });
    if (!existing) return res.status(404).json({ error: "Project not found" });

    // 🧠 Core runs both engines, logs audit events, handles corruption alerts
    const result = await core.emit("project.recompute", {
      prisma,
      projectId:   req.params.id,
      requestedBy: req.user.id,
    });

    const updated = await prisma.project.findUnique({ where: { id: req.params.id } });
    res.json({ ...updated, ...result });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to recompute verification" });
  }
});

module.exports = router;
