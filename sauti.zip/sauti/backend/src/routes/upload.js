/**
 * Upload Route — Media Evidence Layer
 *
 * Two upload strategies supported:
 *
 * 1. SERVER-SIDE (POST /upload)
 *    Client sends a base64 data URI in the request body.
 *    Server uploads to Cloudinary and creates a MediaEvidence record.
 *    Good for small files and USSD/SMS-originated uploads.
 *    Limit: 10MB per file enforced by express.json limit.
 *
 * 2. DIRECT (POST /upload/sign + client POSTs to Cloudinary)
 *    Server returns a signed upload signature.
 *    Browser uploads directly to Cloudinary (bypassing Node entirely).
 *    Cloudinary webhook → POST /upload/confirm saves the MediaEvidence record.
 *    Recommended for video (no 10MB limit, no server memory pressure).
 *    For local dev, use strategy 1 — strategy 2 needs a public webhook URL.
 *
 * For local dev: use POST /upload only.
 * For production: use POST /upload/sign + client direct upload.
 */

const router = require("express").Router();
const { PrismaClient } = require("@prisma/client");
const { authMiddleware, requireRole } = require("../middleware/authMiddleware");
const { uploadMedia, deleteMedia, generateSignedUploadParams } = require("../services/mediaService");
const { logAction } = require("../services/auditLogger");
const core = require("../core/SautiCore");

const prisma = new PrismaClient();

// ── Helpers ──────────────────────────────────────────────────────────────────

function inferResourceType(mimeType = "") {
  if (mimeType.startsWith("video/")) return "video";
  if (mimeType.startsWith("image/")) return "image";
  return "raw";
}

// ── Routes ────────────────────────────────────────────────────────────────────

/**
 * POST /upload
 * Body: {
 *   file:        string  — base64 data URI, e.g. "data:image/jpeg;base64,..."
 *   mimeType:    string  — "image/jpeg" | "video/mp4" etc.
 *   reportId:    string? — attach to an existing report
 *   projectId:   string? — attach directly to a project (leader uploads)
 *   latitude:    number?
 *   longitude:   number?
 *   capturedAt:  string? — ISO date string
 * }
 */
router.post("/", authMiddleware, async (req, res) => {
  try {
    const {
      file, mimeType, reportId, projectId,
      latitude, longitude, capturedAt,
    } = req.body;

    if (!file) {
      return res.status(400).json({ error: "file (base64 data URI) is required" });
    }

    // Validate size: base64 is ~33% larger than raw, so 10MB raw ≈ 13.3MB base64
    const base64Bytes = Buffer.byteLength(file, "utf8") * 0.75;
    if (base64Bytes > 10 * 1024 * 1024) {
      return res.status(413).json({
        error: "File too large for server-side upload (max 10 MB). Use POST /upload/sign for large video files.",
      });
    }

    const resourceType = inferResourceType(mimeType);

    const cloudResult = await uploadMedia(file, {
      folder:       "sauti/reports",
      resourceType,
      reportId:     reportId || null,
      eager:        resourceType === "video",
    });

    const media = await prisma.mediaEvidence.create({
      data: {
        reportId:    reportId  || null,
        projectId:   projectId || null,
        uploadedBy:  req.user.id,
        cloudinaryId: cloudResult.cloudinaryId,
        url:          cloudResult.url,
        thumbnailUrl: cloudResult.thumbnailUrl,
        mediaType:    cloudResult.mediaType,
        format:       cloudResult.format,
        bytes:        cloudResult.bytes,
        width:        cloudResult.width,
        height:       cloudResult.height,
        durationSecs: cloudResult.durationSecs,
        latitude:     latitude  ? parseFloat(latitude)  : null,
        longitude:    longitude ? parseFloat(longitude) : null,
        capturedAt:   capturedAt ? new Date(capturedAt) : null,
        moderationStatus: "pending",
      },
    });

    await logAction(prisma, {
      action:     "media.upload",
      entityType: "MediaEvidence",
      entityId:   media.id,
      userId:     req.user.id,
      meta:       { mediaType: cloudResult.mediaType, bytes: cloudResult.bytes, reportId, projectId },
    });

    const coreResult = await core.emit("media.upload", { prisma, media, uploadedBy: req.user.id });

    res.status(201).json({ ...media, _priorityReview: !!coreResult.priorityReview });
  } catch (err) {
    console.error("Upload error:", err);
    res.status(500).json({ error: "Upload failed: " + err.message });
  }
});

/**
 * POST /upload/sign
 * Returns signed params for direct browser → Cloudinary upload.
 * Client uses these with the Cloudinary JS SDK or fetch to POST directly.
 * After upload, client calls POST /upload/confirm to register the MediaEvidence record.
 */
router.post("/sign", authMiddleware, (req, res) => {
  try {
    const params = generateSignedUploadParams("sauti/reports");
    res.json(params);
  } catch (err) {
    res.status(500).json({ error: "Failed to generate upload signature" });
  }
});

/**
 * POST /upload/confirm
 * Called by client after a successful direct Cloudinary upload.
 * Body: Cloudinary's upload response + our metadata.
 */
router.post("/confirm", authMiddleware, async (req, res) => {
  try {
    const {
      public_id, secure_url, resource_type, format, bytes,
      width, height, duration, eager,
      reportId, projectId, latitude, longitude, capturedAt,
    } = req.body;

    if (!public_id || !secure_url) {
      return res.status(400).json({ error: "public_id and secure_url are required" });
    }

    const media = await prisma.mediaEvidence.create({
      data: {
        reportId:    reportId  || null,
        projectId:   projectId || null,
        uploadedBy:  req.user.id,
        cloudinaryId: public_id,
        url:          secure_url,
        thumbnailUrl: eager?.[0]?.secure_url || null,
        mediaType:    resource_type || "image",
        format:       format || null,
        bytes:        bytes  || null,
        width:        width  || null,
        height:       height || null,
        durationSecs: duration || null,
        latitude:     latitude  ? parseFloat(latitude)  : null,
        longitude:    longitude ? parseFloat(longitude) : null,
        capturedAt:   capturedAt ? new Date(capturedAt) : null,
        moderationStatus: "pending",
      },
    });

    await logAction(prisma, {
      action:     "media.upload.direct",
      entityType: "MediaEvidence",
      entityId:   media.id,
      userId:     req.user.id,
      meta:       { mediaType: resource_type, bytes, reportId, projectId },
    });

    const coreResult = await core.emit("media.upload", { prisma, media, uploadedBy: req.user.id });

    res.status(201).json({ ...media, _priorityReview: !!coreResult.priorityReview });
  } catch (err) {
    console.error("Confirm upload error:", err);
    res.status(500).json({ error: "Failed to register upload: " + err.message });
  }
});

/**
 * GET /upload/media/:reportId
 * Fetch all MediaEvidence for a given report (public, but moderated items filtered).
 *
 * If the parent report is anonymous, this MUST NOT leak uploadedBy or precise
 * GPS — those were the exact things /reports already protects, and media is
 * disproportionately likely to be attached to the reports people most want
 * anonymity for (visual evidence of misconduct).
 */
router.get("/media/:reportId", async (req, res) => {
  try {
    const report = await prisma.report.findUnique({
      where: { id: req.params.reportId },
      select: { isAnonymous: true },
    });

    const media = await prisma.mediaEvidence.findMany({
      where: {
        reportId: req.params.reportId,
        moderationStatus: { not: "removed" },
      },
      orderBy: { createdAt: "asc" },
    });

    if (report?.isAnonymous) {
      const coarsen = (n) => (n == null ? null : Math.round(n * 100) / 100);
      return res.json(
        media.map((m) => ({ ...m, uploadedBy: null, latitude: coarsen(m.latitude), longitude: coarsen(m.longitude) }))
      );
    }

    res.json(media);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch media" });
  }
});

/**
 * GET /upload/project-media/:projectId
 * All approved media attached to a project (for the project detail view).
 */
router.get("/project-media/:projectId", async (req, res) => {
  try {
    const media = await prisma.mediaEvidence.findMany({
      where: {
        projectId: req.params.projectId,
        moderationStatus: { in: ["pending", "approved"] },
      },
      include: {
        uploader: { select: { id: true, name: true } },
        report:   { select: { id: true, content: true } },
      },
      orderBy: { createdAt: "desc" },
    });
    res.json(media);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch project media" });
  }
});

/**
 * PATCH /upload/moderate/:id
 * Admin or moderation layer can approve, flag, or remove media.
 */
router.patch("/moderate/:id", authMiddleware, requireRole("admin"), async (req, res) => {
  try {
    const { status, note } = req.body;
    const valid = ["pending", "approved", "flagged", "removed"];
    if (!valid.includes(status)) {
      return res.status(400).json({ error: `status must be one of: ${valid.join(", ")}` });
    }

    const media = await prisma.mediaEvidence.findUnique({ where: { id: req.params.id } });
    if (!media) return res.status(404).json({ error: "Media not found" });

    // If removing, also delete from Cloudinary to avoid orphaned storage
    if (status === "removed") {
      await deleteMedia(media.cloudinaryId, media.mediaType).catch(console.error);
    }

    const updated = await prisma.mediaEvidence.update({
      where: { id: req.params.id },
      data:  { moderationStatus: status, moderationNote: note || null },
    });

    await logAction(prisma, {
      action:     "media.moderate",
      entityType: "MediaEvidence",
      entityId:   media.id,
      userId:     req.user.id,
      meta:       { status, note },
    });

    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: "Moderation failed" });
  }
});

module.exports = router;
