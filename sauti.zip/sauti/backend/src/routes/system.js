/**
 * 🧠 SautiCore — System Health & Introspection Route
 *
 * GET  /system/health        → overall system status (public, lightweight)
 * GET  /system/core-status   → full Core diagnostic (admin only)
 * POST /system/consistency   → run a consistency sweep across all engines (admin only)
 */

"use strict";

const router = require("express").Router();
const mongoose = require("mongoose");
const { PrismaClient } = require("@prisma/client");
const { authMiddleware, requireRole } = require("../middleware/authMiddleware");
const core = require("../core/SautiCore");
const { runProjectEngines, recomputeAccountability, EVENT_HANDLERS } = require("../core/SautiCore");

const prisma = new PrismaClient();

// ── GET /system/health ────────────────────────────────────────────────────────
//
// Lightweight public heartbeat.  Returns database connectivity and the count
// of active governance objects so an external monitor can detect a collapse.
//
router.get("/health", async (req, res) => {
  const status = { ok: true, checks: {} };

  // PostgreSQL
  try {
    await prisma.$queryRaw`SELECT 1`;
    status.checks.postgres = "ok";
  } catch (err) {
    status.checks.postgres = `error: ${err.message}`;
    status.ok = false;
  }

  // MongoDB — backs Discussions/Forum/Town Halls. Previously unchecked here,
  // meaning this endpoint reported "ok" the entire time Mongo was down/not
  // yet installed, even though a third of the platform's routes would 500.
  // readyState: 0=disconnected, 1=connected, 2=connecting, 3=disconnecting.
  const mongoState = mongoose.connection.readyState;
  if (mongoState === 1) {
    status.checks.mongo = "ok";
  } else {
    status.checks.mongo = `not connected (readyState=${mongoState})`;
    status.ok = false;
  }

  // Basic counts
  try {
    const [projectCount, reportCount, userCount] = await Promise.all([
      prisma.project.count(),
      prisma.report.count(),
      prisma.user.count(),
    ]);
    status.counts = { projects: projectCount, reports: reportCount, users: userCount };
  } catch {
    status.counts = null;
  }

  // Active election cycle
  try {
    const cycle = await prisma.electionCycle.findFirst({ where: { activeFlag: true } });
    status.electionCycle = cycle
      ? { id: cycle.id, name: cycle.name, phase: cycle.phase }
      : null;
  } catch {
    status.electionCycle = null;
  }

  status.timestamp = new Date().toISOString();
  res.status(status.ok ? 200 : 503).json(status);
});

// ── GET /system/core-status ───────────────────────────────────────────────────
//
// Full diagnostic: registered events, governance constants, flags any projects
// that are overdue for engine recomputation.
//
router.get("/core-status", authMiddleware, requireRole("admin"), async (req, res) => {
  const registeredEvents = Object.keys(EVENT_HANDLERS);

  // Projects whose verification is stale (> 7 days since last check)
  const cutoff = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const staleProjects = await prisma.project.findMany({
    where: {
      status:         { not: "completed" },
      lastVerifiedAt: { lt: cutoff },
    },
    select: { id: true, title: true, lastVerifiedAt: true, verificationStatus: true },
    orderBy: { lastVerifiedAt: "asc" },
    take: 20,
  });

  // Leaders with null/missing accountability scores
  const unscoredLeaders = await prisma.user.findMany({
    where:  { role: "leader", accountabilityScore: null },
    select: { id: true, name: true },
  });

  // High-risk projects still unresolved
  const criticalProjects = await prisma.project.findMany({
    where:  { corruptionRiskLevel: { in: ["high", "critical"] } },
    select: { id: true, title: true, corruptionRiskLevel: true, region: true },
    orderBy: { lastCorruptionCheck: "desc" },
    take: 10,
  });

  res.json({
    core: "SautiCore v4",
    registeredEvents,
    handlerCount: registeredEvents.length,
    staleVerification:   { count: staleProjects.length,    items: staleProjects },
    unscoredLeaders:     { count: unscoredLeaders.length,  items: unscoredLeaders },
    criticalRiskProjects:{ count: criticalProjects.length, items: criticalProjects },
    generatedAt: new Date().toISOString(),
  });
});

// ── POST /system/consistency ──────────────────────────────────────────────────
//
// Consistency sweep: re-runs the verification + corruption engines on every
// non-completed project, and refreshes every leader's accountability score.
// This is an expensive background operation — run during off-peak hours.
//
// Returns a summary of what was updated and any anomalies found.
//
router.post("/consistency", authMiddleware, requireRole("admin"), async (req, res) => {
  const summary = {
    projectsChecked:      0,
    projectsUpdated:      0,
    corruptionEscalated:  0,
    leadersRescored:      0,
    anomalies:            [],
    startedAt:            new Date().toISOString(),
  };

  // -- Projects -----------------------------------------------------------------
  const projects = await prisma.project.findMany({
    where:  { status: { not: "completed" } },
    select: { id: true, createdBy: true, corruptionRiskLevel: true },
  });

  const leaderIds = new Set();

  for (const project of projects) {
    summary.projectsChecked++;
    try {
      const before = project.corruptionRiskLevel;
      const result = await runProjectEngines(prisma, project.id);
      if (!result) continue;

      summary.projectsUpdated++;
      leaderIds.add(project.createdBy);

      // Detect escalation: risk level increased
      const riskOrder = { none: 0, low: 1, medium: 2, high: 3, critical: 4 };
      if ((riskOrder[result.riskLevel] ?? 0) > (riskOrder[before] ?? 0)) {
        summary.corruptionEscalated++;
        summary.anomalies.push({
          type:      "corruption_escalated",
          projectId: project.id,
          from:      before,
          to:        result.riskLevel,
        });
      }

      // Detect verification regression: was verified, now disputed
      if (result.effectiveStatus === "disputed") {
        summary.anomalies.push({
          type:      "verification_disputed",
          projectId: project.id,
          status:    result.effectiveStatus,
          score:     result.score,
        });
      }
    } catch (err) {
      summary.anomalies.push({
        type:      "engine_error",
        projectId: project.id,
        error:     err.message,
      });
    }
  }

  // -- Leaders ------------------------------------------------------------------
  const leaders = await prisma.user.findMany({
    where:  { role: "leader" },
    select: { id: true },
  });

  for (const leader of leaders) {
    try {
      await recomputeAccountability(prisma, leader.id);
      summary.leadersRescored++;
    } catch (err) {
      summary.anomalies.push({ type: "leader_rescore_error", leaderId: leader.id, error: err.message });
    }
  }

  summary.completedAt = new Date().toISOString();
  res.json(summary);
});

module.exports = router;
