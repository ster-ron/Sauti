/**
 * USSD / SMS Gateway Adapter (stub)
 *
 * Architecture document: "SMS/USSD — future inclusion for low internet access"
 *
 * This stub defines the entry point, session state machine, and data contract
 * so that a real USSD aggregator (Africa's Talking, Safaricom Bonga, etc.)
 * can be wired in without reshaping the rest of the system.
 *
 * All USSD sessions are stateless from the aggregator's perspective — the
 * session ID is used to reconstruct state from the input string.
 *
 * MENU FLOW (simplified):
 *   1. Welcome / main menu
 *   2. Report issue  → select category → describe → submit anonymously?
 *   3. Check project → enter project code → get verification status
 *   4. Town hall     → list upcoming sessions in region
 *
 * All reports submitted via USSD set channel = "ussd" in the Report model.
 */

const router = require("express").Router();
const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();

const MENU = {
  MAIN: "CON Welcome to Sauti\n1. Report an issue\n2. Check project status\n3. Upcoming town halls\n4. Exit",
  CATEGORY: "CON Select issue category:\n1. Water\n2. Roads\n3. Health\n4. Education\n5. Security\n6. Other",
  REPORT_PROMPT: "CON Describe the issue briefly (max 160 chars):",
  ANON_PROMPT: "CON Submit anonymously?\n1. Yes (anonymous)\n2. No (with my number)",
};

const CATEGORIES = { "1": "water", "2": "roads", "3": "health", "4": "education", "5": "security", "6": "other" };

// POST /ussd — Africa's Talking / Safaricom USSD callback format
router.post("/", async (req, res) => {
  const { sessionId, serviceCode, phoneNumber, text } = req.body;

  if (!sessionId || !phoneNumber) {
    return res.status(400).send("END Invalid request");
  }

  const steps = (text || "").split("*").map((s) => s.trim()).filter(Boolean);

  try {
    // Step 0 — main menu
    if (steps.length === 0) {
      return res.send(MENU.MAIN);
    }

    const action = steps[0];

    // ── Branch 1: Report issue ──────────────────────────────────────────────
    if (action === "1") {
      if (steps.length === 1) return res.send(MENU.CATEGORY);
      if (steps.length === 2) return res.send(MENU.REPORT_PROMPT);
      if (steps.length === 3) return res.send(MENU.ANON_PROMPT);

      if (steps.length === 4) {
        const categoryKey = steps[1];
        const reportText  = steps[2];
        const anonChoice  = steps[3];
        const category    = CATEGORIES[categoryKey] || "other";
        const isAnonymous = anonChoice === "1";

        // Upsert a shadow USSD user record keyed on phone number
        let user = await prisma.user.findFirst({ where: { email: `ussd_${phoneNumber}@sauti.internal` } });
        if (!user) {
          const bcrypt = require("bcryptjs");
          user = await prisma.user.create({
            data: {
              name:     `USSD ${phoneNumber}`,
              email:    `ussd_${phoneNumber}@sauti.internal`,
              password: await bcrypt.hash(sessionId, 8),
              role:     "citizen",
              phone:    phoneNumber,
            },
          });
        }

        await prisma.report.create({
          data: {
            content:     `[USSD] [${category}] ${reportText}`,
            userId:      user.id,
            isAnonymous,
            channel:     "ussd",
          },
        });

        return res.send("END Thank you! Your report has been submitted to Sauti and will be reviewed.");
      }
    }

    // ── Branch 2: Check project status ──────────────────────────────────────
    if (action === "2") {
      if (steps.length === 1) return res.send("CON Enter project keyword (e.g. 'Kangemi road'):");
      const keyword = steps[1];
      const projects = await prisma.project.findMany({
        where:   { title: { contains: keyword, mode: "insensitive" } },
        take:    3,
        orderBy: { createdAt: "desc" },
      });

      if (projects.length === 0) {
        return res.send(`END No projects found matching "${keyword}". Try a different keyword.`);
      }

      const list = projects
        .map((p, i) => `${i + 1}. ${p.title} [${p.verificationStatus}]`)
        .join("\n");
      return res.send(`END Projects matching "${keyword}":\n${list}`);
    }

    // ── Branch 3: Upcoming town halls ───────────────────────────────────────
    if (action === "3") {
      const { connectMongo } = require("../config/mongo");
      await connectMongo();
      const TownHall = require("../models/TownHall");
      const upcoming = await TownHall.find({ status: { $in: ["scheduled", "live"] } })
        .sort({ scheduledFor: 1 })
        .limit(3);

      if (!upcoming.length) return res.send("END No upcoming town halls scheduled.");
      const list = upcoming.map((t, i) =>
        `${i + 1}. ${t.title} (${t.region}) - ${new Date(t.scheduledFor).toLocaleDateString("en-KE")}`
      ).join("\n");
      return res.send(`END Upcoming town halls:\n${list}`);
    }

    // ── Branch 4: Exit ──────────────────────────────────────────────────────
    if (action === "4") {
      return res.send("END Thank you for using Sauti. Hold your leaders accountable.");
    }

    return res.send("END Invalid option. Please dial again.");
  } catch (err) {
    console.error("USSD error:", err);
    res.send("END Service temporarily unavailable. Please try again.");
  }
});

module.exports = router;
