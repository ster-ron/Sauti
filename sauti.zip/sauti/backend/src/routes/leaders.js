/**
 * Leaders Registry — Accountability Core
 *
 * Exposes the public-facing Leaders Registry described in the architecture:
 *   - searchable by constituency / ward / region
 *   - accountability score computed from their project portfolio
 *   - public profile with bio, title, projects and reports
 *
 * This is a read-only public endpoint built on top of the User model.
 * Leaders manage their own profile via PATCH /leaders/me.
 */

const router = require("express").Router();
const { PrismaClient } = require("@prisma/client");
const { authMiddleware, requireRole } = require("../middleware/authMiddleware");

const prisma = new PrismaClient();

// ── Helpers ──────────────────────────────────────────────────────────────────

function sanitizeLeader(u) {
  const { password, email, ...safe } = u;
  return safe;
}

/**
 * Live recomputation of an accountability score from a leader's current
 * project portfolio. This is intentionally a RICHER signal than
 * SautiCore's persisted `User.accountabilityScore` — it factors in
 * budget absorption rate, which the Core doesn't currently track.
 *
 * IMPORTANT: this is NOT the same number as the Core's persisted score
 * (they use different weights), so we expose both explicitly below rather
 * than letting one silently overwrite the other. `accountabilityScore` is
 * the Core's authoritative, audit-logged value; `liveScore` is this
 * route's live estimate for comparison/debugging. If you only want one
 * source of truth, fold this formula into
 * `SautiCore.recomputeAccountabilityScore` instead of keeping both.
 */
function computeLiveScore(projects) {
  if (!projects || projects.length === 0) return 0;

  let score = 50; // start at neutral

  for (const p of projects) {
    if (p.verificationStatus === "verified")             score += 10;
    else if (p.verificationStatus === "disputed")        score -= 12;
    if (p.corruptionRiskLevel === "high")                score -= 15;
    if (p.corruptionRiskLevel === "critical")            score -= 20;
    if (p.corruptionRiskLevel === "medium")              score -= 8;
  }

  const reportCount = projects.reduce((s, p) => s + (p.reports?.length || 0), 0);
  score += Math.min(20, Math.floor(reportCount / 5));

  const totalBudget = projects.reduce((s, p) => s + (p.budget      || 0), 0);
  const totalSpent  = projects.reduce((s, p) => s + (p.budgetSpent || 0), 0);
  if (totalBudget > 0) {
    const absorb = totalSpent / totalBudget;
    score += Math.round(absorb * 20);
  }

  return Math.max(0, Math.min(100, Math.round(score)));
}

// ── Routes ────────────────────────────────────────────────────────────────────

// LIST LEADERS (public) — Leaders Registry
router.get("/", async (req, res) => {
  try {
    const { constituency, ward, region } = req.query;

    const leaders = await prisma.user.findMany({
      where: {
        role: "leader",
        ...(constituency ? { constituency } : {}),
        ...(ward         ? { ward }         : {}),
      },
      include: {
        projects: {
          include: { reports: { select: { id: true } } },
        },
      },
      orderBy: { name: "asc" },
    });

    const enriched = leaders.map((l) => ({
      ...sanitizeLeader(l),
      accountabilityScore: l.accountabilityScore ?? 0, // authoritative, SautiCore-maintained
      liveScore:           computeLiveScore(l.projects), // see computeLiveScore() comment above
      projectCount:        l.projects.length,
      reportCount:         l.projects.reduce((s, p) => s + (p.reports?.length || 0), 0),
      disputedCount:       l.projects.filter((p) => p.verificationStatus === "disputed").length,
      corruptionFlags:     l.projects.filter((p) => p.corruptionRiskLevel && p.corruptionRiskLevel !== "none").length,
    }));

    res.json(enriched);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch leaders" });
  }
});

// GET SINGLE LEADER PROFILE (public)
router.get("/:id", async (req, res) => {
  try {
    const leader = await prisma.user.findUnique({
      where:   { id: req.params.id },
      include: {
        projects: {
          include: {
            reports: { select: { id: true, content: true, createdAt: true, isAnonymous: true } },
          },
          orderBy: { createdAt: "desc" },
        },
      },
    });

    if (!leader || leader.role !== "leader") {
      return res.status(404).json({ error: "Leader not found" });
    }

    res.json({
      ...sanitizeLeader(leader),
      accountabilityScore: leader.accountabilityScore ?? 0, // authoritative, SautiCore-maintained
      liveScore:           computeLiveScore(leader.projects),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch leader profile" });
  }
});

// UPDATE OWN PROFILE (leader only)
router.patch("/me", authMiddleware, requireRole("leader"), async (req, res) => {
  try {
    const { title, constituency, ward, bio, phone } = req.body;

    const updated = await prisma.user.update({
      where: { id: req.user.id },
      data:  {
        title:        title        || undefined,
        constituency: constituency || undefined,
        ward:         ward         || undefined,
        bio:          bio          || undefined,
        phone:        phone        || undefined,
      },
    });

    res.json(sanitizeLeader(updated));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update profile" });
  }
});

module.exports = router;
