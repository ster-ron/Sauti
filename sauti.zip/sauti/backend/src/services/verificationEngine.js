/**
 * Verification Engine (Sauti Core)
 *
 * Analyses citizen reports attached to a project and determines whether the
 * project's claimed status holds up:
 *   verified   → reports broadly agree the work is done / progressing
 *   partial    → mixed or insufficient signal
 *   disputed   → reports actively contradict each other
 *   unverified → no reports yet
 *
 * The engine is intentionally rule-based and transparent so citizens can
 * inspect *why* a project was flagged. NLP/embeddings can be layered on
 * top in a production deployment while keeping these keyword signals as an
 * auditable baseline.
 */

const COMPLETE_SIGNALS = [
  "completed", "finished", "done", "delivered", "operational",
  "working well", "fixed", "opened", "inaugurated", "launched",
  "fully functional", "100%", "construction complete",
];

const INCOMPLETE_SIGNALS = [
  "incomplete", "unfinished", "not done", "not finished", "abandoned",
  "stalled", "still under construction", "broken", "not working",
  "never started", "no progress", "halted", "stopped work",
  "crew missing", "no workers", "ghost project", "funds diverted",
  "construction paused", "contractor left",
];

const CORRUPTION_SIGNALS = [
  "funds diverted", "money missing", "ghost project", "bribery", "kickback",
  "inflated cost", "no tender", "single sourced", "contractor connected",
  "relatives awarded", "no work done but paid", "budget doubled",
  "overpriced", "substandard materials", "payment without delivery",
];

function classifyReport(content) {
  const text = (content || "").toLowerCase();
  const hasComplete   = COMPLETE_SIGNALS.some((s)   => text.includes(s));
  const hasIncomplete = INCOMPLETE_SIGNALS.some((s)  => text.includes(s));

  if (hasComplete && hasIncomplete) return "mixed";
  if (hasComplete)                  return "complete";
  if (hasIncomplete)                return "incomplete";
  return "neutral";
}

function detectCorruptionSignals(content) {
  const text = (content || "").toLowerCase();
  return CORRUPTION_SIGNALS.filter((s) => text.includes(s));
}

/**
 * @param {Array<{content: string}>} reports
 * @returns {{ status: string, score: number, breakdown: object }}
 */
function computeVerification(reports) {
  if (!reports || reports.length === 0) {
    return {
      status: "unverified",
      score: 0,
      breakdown: { complete: 0, incomplete: 0, mixed: 0, neutral: 0, total: 0 },
    };
  }

  const breakdown = { complete: 0, incomplete: 0, mixed: 0, neutral: 0, total: reports.length };

  for (const r of reports) {
    const c = classifyReport(r.content);
    breakdown[c] += 1;
  }

  const conflictRatio =
    Math.min(breakdown.complete, breakdown.incomplete) / reports.length +
    breakdown.mixed / reports.length;

  let status;
  let score;

  if (conflictRatio >= 0.25) {
    // Meaningful disagreement between citizen accounts → disputed
    status = "disputed";
    score  = Math.max(0.1, 0.5 - conflictRatio);
  } else if (breakdown.complete > breakdown.incomplete && breakdown.complete > 0) {
    status = "verified";
    score  = Math.min(1, 0.5 + breakdown.complete / reports.length / 2);
  } else if (breakdown.incomplete > 0) {
    status = "partial";
    score  = Math.max(0.2, 0.5 - breakdown.incomplete / reports.length / 2);
  } else {
    // Only neutral reports — talking about it but no clear signal
    status = "partial";
    score  = 0.4;
  }

  return { status, score: Math.round(score * 100) / 100, breakdown };
}

/**
 * Corruption Signal Engine — scans all reports for governance red-flags.
 * Returns a risk level and list of unique flag phrases detected.
 *
 * @param {Array<{content: string}>} reports
 * @returns {{ riskLevel: string, flags: string[], flagCount: number }}
 */
function computeCorruptionRisk(reports) {
  if (!reports || reports.length === 0) {
    return { riskLevel: "none", flags: [], flagCount: 0 };
  }

  const allFlags = new Set();
  for (const r of reports) {
    for (const flag of detectCorruptionSignals(r.content)) {
      allFlags.add(flag);
    }
  }

  const flagCount = allFlags.size;
  let riskLevel;

  if (flagCount === 0)      riskLevel = "none";
  else if (flagCount <= 1)  riskLevel = "low";
  else if (flagCount <= 3)  riskLevel = "medium";
  else if (flagCount <= 5)  riskLevel = "high";
  else                      riskLevel = "critical";

  return { riskLevel, flags: [...allFlags], flagCount };
}

module.exports = { computeVerification, computeCorruptionRisk, classifyReport, detectCorruptionSignals };
