/**
 * Media Service — Cloudinary adapter
 *
 * Wraps the Cloudinary SDK so the rest of the system never imports it directly.
 * Swap for S3/Azure Blob here without touching any route.
 *
 * LOCAL DEV:  sign up at cloudinary.com (free tier), copy credentials to .env
 * PRODUCTION: same credentials, same API — just a higher plan
 *
 * Env vars required:
 *   CLOUDINARY_CLOUD_NAME
 *   CLOUDINARY_API_KEY
 *   CLOUDINARY_API_SECRET
 */

const cloudinary = require("cloudinary").v2;

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key:    process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
  secure:     true,
});

/**
 * Upload a file buffer or data URI to Cloudinary.
 *
 * @param {string} fileDataUri  - base64 data URI or a local file path
 * @param {object} opts
 * @param {string} opts.folder        - Cloudinary folder (e.g. "sauti/reports")
 * @param {string} opts.resourceType  - "image" | "video" | "raw"
 * @param {string} opts.reportId      - used as context tag for traceability
 * @param {boolean} opts.eager        - generate thumbnail for videos
 * @returns {Promise<object>} upload result with url, thumbnailUrl, etc.
 */
async function uploadMedia(fileDataUri, opts = {}) {
  const {
    folder       = "sauti/reports",
    resourceType = "auto",
    reportId     = null,
    eager        = false,
  } = opts;

  const uploadOpts = {
    folder,
    resource_type: resourceType,
    // Tag with reportId so we can find orphans in Cloudinary console
    context: reportId ? `reportId=${reportId}` : undefined,
    // For videos: generate a thumbnail at 5s mark and resize to 640px wide
    eager: eager && resourceType !== "image"
      ? [{ width: 640, crop: "limit", start_offset: "5" }]
      : undefined,
    // NOTE: eager_async must be false here — uploadMedia() reads
    // result.eager[0].secure_url synchronously right after this call. With
    // eager_async:true, Cloudinary processes the transformation in the
    // background and notifies via webhook instead, so thumbnailUrl would
    // always come back null. If you want async processing for large videos,
    // add a `notification_url` and handle the callback to backfill
    // thumbnailUrl on the MediaEvidence record instead.
    eager_async: false,
  };

  const result = await cloudinary.uploader.upload(fileDataUri, uploadOpts);

  return {
    cloudinaryId: result.public_id,
    url:          result.secure_url,
    thumbnailUrl: result.eager?.[0]?.secure_url || null,
    mediaType:    result.resource_type,   // image | video | raw
    format:       result.format,
    bytes:        result.bytes,
    width:        result.width  || null,
    height:       result.height || null,
    durationSecs: result.duration || null,
  };
}

/**
 * Delete a file from Cloudinary by its public_id.
 * Called when a MediaEvidence record is removed (moderation).
 */
async function deleteMedia(cloudinaryId, resourceType = "image") {
  return cloudinary.uploader.destroy(cloudinaryId, { resource_type: resourceType });
}

/**
 * Generate a signed upload URL for direct browser → Cloudinary uploads.
 * This avoids routing large files through the Node server.
 * The frontend calls POST /upload/sign, gets back {signature, timestamp, ...},
 * then POSTs directly to Cloudinary's upload endpoint.
 */
function generateSignedUploadParams(folder = "sauti/reports") {
  const timestamp = Math.round(Date.now() / 1000);
  const params    = { timestamp, folder };
  const signature = cloudinary.utils.api_sign_request(params, process.env.CLOUDINARY_API_SECRET);

  return {
    signature,
    timestamp,
    folder,
    cloudName: process.env.CLOUDINARY_CLOUD_NAME,
    apiKey:    process.env.CLOUDINARY_API_KEY,
  };
}

module.exports = { uploadMedia, deleteMedia, generateSignedUploadParams };
