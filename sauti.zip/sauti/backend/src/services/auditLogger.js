/**
 * Writes an immutable audit log entry. Never throws into the caller's
 * request flow — logging failures shouldn't break the user-facing action.
 */
async function logAction(prisma, { action, entityType, entityId = null, userId = null, meta = null, channel = "web" }) {
  try {
    await prisma.auditLog.create({
      data: {
        action,
        entityType,
        entityId,
        userId,
        channel,
        meta: meta ? JSON.stringify(meta) : null,
      },
    });
  } catch (err) {
    console.error("AuditLog write failed:", err.message);
  }
}

module.exports = { logAction };
