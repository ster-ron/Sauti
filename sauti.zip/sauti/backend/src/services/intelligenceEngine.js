/**
 * Civic Intelligence Layer
 *
 * Computes deterministic stats over the full project/report corpus and
 * optionally enriches them with an LLM narrative. Always returns something
 * useful — the LLM is an optional enhancement, not a dependency.
 *
 * Capabilities:
 *   1. Aggregate stats (by region, category, verification status)
 *   2. Repeated-complaint clustering (keyword overlap)
 *   3. Corruption signal aggregation across all projects
 *   4. Pattern detection: unresolved complaints, budget vs spend gaps
 *   5. High-risk / high-impact project flags
 *   6. Optional Claude narrative (falls back to template if no API key)
 */

function buildStats(projects, reports, electionContext = null) {
  const byRegion       = {};
  const byCategory     = {};
  const byStatus       = {};
  const byCorruptionRisk = {};
  let   totalBudget    = 0;
  let   totalSpent     = 0;

  for (const p of projects) {
    const region   = p.region   || "Unspecified";
    const category = p.category || "other";
    const risk     = p.corruptionRiskLevel || "none";

    byRegion[region]             = (byRegion[region]   || 0) + 1;
    byCategory[category]         = (byCategory[category] || 0) + 1;
    byStatus[p.verificationStatus] = (byStatus[p.verificationStatus] || 0) + 1;
    byCorruptionRisk[risk]       = (byCorruptionRisk[risk] || 0) + 1;

    if (p.budget)      totalBudget += p.budget;
    if (p.budgetSpent) totalSpent  += p.budgetSpent;
  }

  // Budget absorption rate — large gap between allocation and spend can be
  // a governance red-flag or simply indicate a slow-disbursing project
  const absorptionRate = totalBudget > 0
    ? Math.round((totalSpent / totalBudget) * 100)
    : null;

  // Repeated-complaint clustering: group reports by first 4 significant words
  const clusters = {};
  for (const r of reports) {
    const words = (r.content || "")
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, "")
      .split(/\s+/)
      .filter((w) => w.length > 3)
      .slice(0, 4)
      .join(" ");
    if (!words) continue;
    clusters[words] = (clusters[words] || 0) + 1;
  }

  const repeatedComplaints = Object.entries(clusters)
    .filter(([, count]) => count > 1)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([phrase, count]) => ({ phrase, count }));

  // High-risk projects: disputed OR any corruption flag set
  const highRiskProjects = projects
    .filter((p) => p.verificationStatus === "disputed" || (p.corruptionRiskLevel && p.corruptionRiskLevel !== "none"))
    .map((p) => ({
      id:                  p.id,
      title:               p.title,
      region:              p.region,
      verificationStatus:  p.verificationStatus,
      corruptionRiskLevel: p.corruptionRiskLevel,
      corruptionFlags:     p.corruptionFlags ? JSON.parse(p.corruptionFlags) : [],
    }));

  // Unresolved / stalled projects: no reports in >30 days or status = planned for >60 days
  const now = new Date();
  const stalledProjects = projects
    .filter((p) => {
      if (p.status === "completed" || p.status === "cancelled") return false;
      if (!p.lastVerifiedAt && p.createdAt) {
        const ageMs = now - new Date(p.createdAt);
        return ageMs > 60 * 24 * 60 * 60 * 1000; // 60 days with zero reports
      }
      if (p.lastVerifiedAt) {
        const staleDays = (now - new Date(p.lastVerifiedAt)) / (24 * 60 * 60 * 1000);
        return staleDays > 30;
      }
      return false;
    })
    .map((p) => ({ id: p.id, title: p.title, region: p.region, status: p.status }));

  return {
    byRegion,
    byCategory,
    byStatus,
    byCorruptionRisk,
    repeatedComplaints,
    highRiskProjects,
    stalledProjects,
    budget: { total: totalBudget, spent: totalSpent, absorptionRate },
    totals: { projects: projects.length, reports: reports.length },
    electionContext,
  };
}

function templateNarrative(stats) {
  const lines = [];

  lines.push(
    `Tracking ${stats.totals.projects} public project(s) and ${stats.totals.reports} citizen report(s) across ${Object.keys(stats.byRegion).length} region(s).`
  );

  if (stats.highRiskProjects.length) {
    const disputed     = stats.highRiskProjects.filter((p) => p.verificationStatus === "disputed").length;
    const flaggedCorr  = stats.highRiskProjects.filter((p) => p.corruptionRiskLevel !== "none").length;
    if (disputed) lines.push(`${disputed} project(s) are flagged as disputed by citizens.`);
    if (flaggedCorr) lines.push(`${flaggedCorr} project(s) carry active corruption risk signals and require urgent scrutiny.`);
  } else {
    lines.push("No projects are currently flagged as disputed or high-risk.");
  }

  if (stats.stalledProjects.length) {
    lines.push(`${stats.stalledProjects.length} project(s) appear stalled — no citizen activity in over 30 days.`);
  }

  if (stats.repeatedComplaints.length) {
    lines.push(
      `Recurring civic concerns: ${stats.repeatedComplaints.map((c) => `"${c.phrase}" (${c.count}x)`).join(", ")}.`
    );
  }

  if (stats.budget.absorptionRate !== null) {
    lines.push(`Budget absorption rate stands at ${stats.budget.absorptionRate}% — KSh ${(stats.budget.spent / 1e6).toFixed(1)}M spent of KSh ${(stats.budget.total / 1e6).toFixed(1)}M allocated.`);
  }

  if (stats.electionContext?.activeFlag) {
    const { name, phase, daysRemaining } = stats.electionContext;
    lines.push(`⚠️ Active election cycle: "${name}" (${phase} phase, ${daysRemaining} days remaining). Project delivery performance will directly inform voter accountability assessments.`);
  }

  return lines.join(" ");
}

async function llmNarrative(stats) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return null;

  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 400,
        messages: [
          {
            role: "user",
            content: `You are a neutral civic transparency analyst. Summarize this governance data in 4-5 plain sentences for a general public audience. Highlight any corruption risk signals or stalled projects. Stay factual, do not editorialize about named leaders. Data: ${JSON.stringify(stats)}`,
          },
        ],
      }),
    });

    if (!res.ok) return null;
    const data = await res.json();
    const text = data.content?.find((b) => b.type === "text")?.text;
    return text || null;
  } catch (err) {
    console.error("Civic Intelligence LLM call failed, falling back to template:", err.message);
    return null;
  }
}

async function generateSummary(projects, reports, prisma = null) {
  let electionContext = null;
  if (prisma) {
    try {
      const cycle = await prisma.electionCycle.findFirst({ where: { activeFlag: true } });
      if (cycle) {
        const daysRemaining = Math.max(0, Math.ceil((new Date(cycle.endDate) - new Date()) / 86400000));
        electionContext = { ...cycle, daysRemaining };
      }
    } catch {}
  }
  const stats     = buildStats(projects, reports, electionContext);
  const narrative = (await llmNarrative(stats)) || templateNarrative(stats);
  return { ...stats, narrative, generatedAt: new Date().toISOString() };
}

module.exports = { generateSummary, buildStats, templateNarrative };
