/**
 * One-time migration: copies existing `forumthreads` and `townhalls`
 * Mongo collections into the new unified `discussionthreads` collection
 * used by the 🧭 Civic Discussion Engine.
 *
 * Safe to re-run: it skips any document whose _id already exists in
 * discussionthreads.
 *
 * Usage:
 *   node src/scripts/migrateToDiscussionEngine.js
 */
require("dotenv").config();
const mongoose = require("mongoose");
const { connectMongo } = require("../config/mongo");
const DiscussionThread = require("../models/DiscussionThread");

async function migrateForumThreads(db) {
  const col = db.collection("forumthreads");
  const docs = await col.find({}).toArray();
  let migrated = 0;

  for (const d of docs) {
    const exists = await DiscussionThread.exists({ _id: d._id });
    if (exists) continue;

    await DiscussionThread.create({
      _id: d._id,
      mode: "async",
      status: d.isHidden ? "closed" : "open",
      title: d.title,
      description: d.content,
      topic: d.topic,
      authorId: d.userId,
      authorName: d.userName,
      projectId: d.projectId || null,
      entries: (d.replies || []).map((r) => ({
        _id: r._id,
        kind: "comment",
        content: r.content,
        authorId: r.userId,
        authorName: r.userName,
        createdAt: r.createdAt,
      })),
      isModerated: !!d.isModerated,
      isHidden: !!d.isHidden,
      createdAt: d.createdAt,
      updatedAt: d.updatedAt,
    });
    migrated++;
  }
  return migrated;
}

async function migrateTownHalls(db) {
  const col = db.collection("townhalls");
  const docs = await col.find({}).toArray();
  let migrated = 0;

  for (const d of docs) {
    const exists = await DiscussionThread.exists({ _id: d._id });
    if (exists) continue;

    const agendaEntries = (d.agendaItems || []).map((a) => ({
      _id: a._id,
      kind: "agenda",
      title: a.title,
      content: a.description || "",
      votes: a.upvotes || [],
      authorId: d.leaderId,
      authorName: d.leaderName,
    }));
    const qaEntries = (d.qa || []).map((q) => ({
      _id: q._id,
      kind: "question",
      content: q.question,
      authorId: q.askedBy,
      authorName: q.askedByName,
      answer: q.answer,
      answeredAt: q.answeredAt,
    }));

    await DiscussionThread.create({
      _id: d._id,
      mode: "live",
      status: d.status,
      title: d.title,
      description: d.title,
      region: d.region,
      scheduledFor: d.scheduledFor,
      transcript: d.transcript || "",
      authorId: d.leaderId,
      authorName: d.leaderName,
      entries: [...agendaEntries, ...qaEntries],
      createdAt: d.createdAt,
      updatedAt: d.updatedAt,
    });
    migrated++;
  }
  return migrated;
}

async function run() {
  await connectMongo();
  const db = mongoose.connection.db;

  const forumCount = await migrateForumThreads(db);
  console.log(`✅ Migrated ${forumCount} forum thread(s) -> discussionthreads (mode=async)`);

  const townhallCount = await migrateTownHalls(db);
  console.log(`✅ Migrated ${townhallCount} town hall(s) -> discussionthreads (mode=live)`);

  console.log("Done. Old `forumthreads` / `townhalls` collections were left untouched — drop them manually once you've verified the migration.");
  await mongoose.disconnect();
}

run().catch((err) => {
  console.error("Migration failed:", err);
  process.exit(1);
});
