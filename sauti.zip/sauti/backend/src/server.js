require("dotenv").config();
const express = require("express");
const cors    = require("cors");
const helmet  = require("helmet");
const rateLimit = require("express-rate-limit");
const { connectMongo } = require("./config/mongo");

// Fail fast rather than silently run insecure: a forgeable JWT secret in
// production means anyone who reads this repo's source (which contains the
// dev fallback string) can mint a valid admin token. Dev/test keep the
// convenience fallback so local setup doesn't need a real secret on day one.
if (process.env.NODE_ENV === "production" && !process.env.JWT_SECRET) {
  console.error("FATAL: JWT_SECRET must be set in production. Refusing to start with the insecure dev fallback.");
  process.exit(1);
}

const app = express();
app.set("trust proxy", 1); // correct client IPs behind a reverse proxy/load balancer, needed for rate limiting to work per-client rather than per-proxy

app.use(helmet());

// CORS: restrict to known frontend origin(s) in production. Comma-separated
// list in ALLOWED_ORIGINS env var; falls back to permissive (any origin)
// only when unset, so local dev isn't broken by default.
const allowedOrigins = process.env.ALLOWED_ORIGINS?.split(",").map((o) => o.trim());
app.use(cors(allowedOrigins ? { origin: allowedOrigins } : {}));

// Global rate limit — generous, just a backstop against accidental loops/abuse
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 600, standardHeaders: true, legacyHeaders: false }));

// Tighter limit specifically on auth — this is the actual brute-force surface
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many auth attempts. Please try again later." },
});

// NOTE: default express.json() limit is 100KB — far too small for the
// base64 media uploads in routes/upload.js (POST /upload accepts up to
// 10MB raw files, which is ~13.3MB once base64-encoded). Without raising
// this, every real photo/video evidence upload would 413 here before ever
// reaching the upload route's own size check.
app.use(express.json({ limit: "15mb" }));
// USSD aggregators send form-encoded payloads
app.use(express.urlencoded({ extended: true }));

// ── ROUTES ────────────────────────────────────────────────────────────────────
const authRoutes         = require("./routes/auth");
const projectRoutes      = require("./routes/projects");      // Accountability Core
const reportRoutes       = require("./routes/reports");       // Evidence Layer → Verification Engine
const discussionRoutes   = require("./routes/discussions");   // 🧭 Civic Discussion Engine (Mongo) — async + live modes
const forumRoutes        = require("./routes/forum");         // DEPRECATED shim → DiscussionThread mode=async
const townhallRoutes     = require("./routes/townhall");      // DEPRECATED shim → DiscussionThread mode=live
const intelligenceRoutes = require("./routes/intelligence");  // Civic Intelligence Layer
const auditRoutes        = require("./routes/audit");         // Transparency / Audit Log
const leadersRoutes      = require("./routes/leaders");       // Leaders Registry
const oversightRoutes    = require("./routes/oversight");     // Election Stakeholder Oversight
const ussdRoutes         = require("./routes/ussd");          // USSD / SMS gateway stub
const uploadRoutes        = require("./routes/upload");         // Media Evidence Layer (Cloudinary)
const electionRoutes      = require("./routes/election");        // Election Cycle + Manifesto Engine
const systemRoutes        = require("./routes/system");          // 🧠 SautiCore — health + introspection

app.use("/auth", authLimiter, authRoutes);
app.use("/projects",    projectRoutes);
app.use("/reports",     reportRoutes);
app.use("/discussions", discussionRoutes); // 🧭 Civic Discussion Engine — canonical (mode=async|live)
app.use("/forum",       forumRoutes);      // deprecated alias, same underlying data
app.use("/townhall",    townhallRoutes);   // deprecated alias, same underlying data
app.use("/intelligence",intelligenceRoutes);
app.use("/audit",       auditRoutes);
app.use("/leaders",     leadersRoutes);
app.use("/oversight",   oversightRoutes);
app.use("/ussd",        ussdRoutes);
app.use("/upload",      uploadRoutes);  // Media Evidence Layer
app.use("/election",    electionRoutes); // Election Cycle + Manifesto Engine
app.use("/system",      systemRoutes);  // 🧠 SautiCore — health & consistency

app.get("/", (req, res) => {
  res.json({
    name:    "Sauti API",
    version: "2.0.0",
    engines: [
      "🧠 SautiCore (/system/health, /system/core-status, /system/consistency)",
      "Accountability Core (/projects)",
      "Verification Engine (auto-triggered on /reports POST)",
      "Corruption Signal Engine (auto-triggered on /reports POST)",
      "🧭 Civic Discussion Engine (/discussions?mode=async|live)",
      "  ↳ /forum and /townhall still work (deprecated aliases, same data)",
      "Civic Intelligence Layer (/intelligence)",
      "Leaders Registry (/leaders)",
      "Election Oversight (/oversight)",
      "Election Cycle Engine (/election/cycles)",
      "Manifesto Tracking Engine (/election/manifesto)",
      "USSD Gateway (/ussd)",
      "Media Evidence Layer (/upload)",
      "Audit Trail (/audit)",
    ],
    docs: "See README.md for full API reference",
  });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Something went wrong" });
});

const PORT = process.env.PORT || 5000;
let server;

async function start() {
  try {
    await connectMongo();
  } catch (err) {
    console.error(
      "MongoDB connection failed — forum and town hall routes will not work:",
      err.message
    );
  }

  server = app.listen(PORT, () => {
    console.log(`🏛️  Sauti API v2.0 running on port ${PORT}`);
    console.log(`   Accountability · Verification · Corruption Detection · USSD Ready`);
  });
}

// Without this, a container stop/redeploy sends SIGTERM and Node kills the
// process mid-request by default — including mid-write to the audit log,
// which undercuts its claim to be an immutable record. This stops accepting
// new connections, lets in-flight requests finish (up to the timeout), then
// exits cleanly.
function shutdown(signal) {
  console.log(`\n${signal} received — closing server gracefully…`);
  if (!server) { process.exit(0); return; }

  server.close(() => {
    console.log("HTTP server closed. Exiting.");
    process.exit(0);
  });

  // Don't hang forever if something never finishes
  setTimeout(() => {
    console.error("Forced shutdown after 10s timeout.");
    process.exit(1);
  }, 10_000).unref();
}

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));

start();
