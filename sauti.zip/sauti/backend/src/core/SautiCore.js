/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║                        🧠 SautiCore                               ║
 * ║                   Central Orchestration Layer — v4                       ║
 * ╠══════════════════════════════════════════════════════════════════════════╣
 * ║                                                                          ║
 * ║  Every significant civic event in the system passes through here.        ║
 * ║  The Core is the single authoritative source for:                        ║
 * ║                                                                          ║
 * ║  1. EVENT ROUTING      — one place to see what fires on what action      ║
 * ║  2. RULE ENFORCEMENT   — cross-cutting governance constraints             ║
 * ║  3. ENGINE TRIGGERING  — verification, corruption, intelligence           ║
 * ║  4. CONSISTENCY        — trust scores, accountability scores, lifecycle   ║
 * ║  5. AUDIT COMPLETENESS — every consequential action leaves a trail        ║
 * ║                                                                          ║
 * ║  Architecture:                                                           ║
 * ║                                                                          ║
 * ║    Route handler           SautiCore           Downstream engine   ║
 * ║    ─────────────  emit()→  ──────────────── →handle  ─────────────────   ║
 * ║    POST /reports           onReportSubmit()          Verification        ║
 * ║    POST /reports           onReportSubmit()          Corruption          ║
 * ║    POST /reports           onReportSubmit()          TrustScore          ║
 * ║    POST /reports/:upvote   onReportUpvote()          TrustScore          ║
 * ║    POST /projects          onProjectCreate()         AccountabilityScore ║
 * ║    PATCH /projects/:id     onProjectUpdate()         Verification        ║
 * ║    POST /discussions       onDiscussionCreate()      AuditTrail          ║
 * ║    POST /discussions/:id/entries onEntryAdd()        AuditTrail          ║
 * ║    PATCH /election/cycles  onElectionPhaseChange()   SystemAlert         ║
 * ║    POST /election/manifesto onPromiseCreate()        AuditTrail          ║
 * ║    PATCH /manifesto/:id    onPromiseStatusChange()   AccountabilityScore ║
 * ║    POST /oversight         onOversightPublish()      AuditTrail          ║
 * ║    POST /upload            onMediaUpload()           AuditTrail          ║
 * ║                                                                          ║
 * ║  Usage (in a route handler):                                             ║
 * ║                                                                          ║
 * ║    const core = require("../core/SautiCore");                      ║
 * ║    await core.emit("report.submit", { prisma, report, user, projectId }) ║
 * ║                                                                          ║
 * ║  The Core never throws into the caller — all handler failures are        ║
 * ║  logged and swallowed so a side-effect never breaks the HTTP response.   ║
 * ║                                                                          ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */

"use strict";

const { computeVerification, computeCorruptionRisk } = require("../services/verificationEngine");
const { logAction } = require("../services/auditLogger");

// ── Constants ─────────────────────────────────────────────────────────────────

const TRUST_UPVOTE_INCREMENT   = 0.5;   // per upvote
const TRUST_VERIFIED_INCREMENT = 1.0;   // when a report the user submitted feeds a "verified" project outcome
const TRUST_DISPUTED_DECREMENT = 0.5;   // when a report feeds a "disputed" outcome
const TRUST_CAP                = 100;
const TRUST_FLOOR              = 0;

// Governance rules: minimum reports before verification is meaningful
const MIN_REPORTS_FOR_VERIFIED  = 3;
const MIN_REPORTS_FOR_DISPUTED  = 2;

// Accountability score weights
const ACC_SCORE_WEIGHTS = {
  verifiedProjects:    3,
  ongoingProjects:     1,
  plannedProjects:     0.5,
  disputedProjects:   -2,
  corruptionFlags:    -4,
  manifestoDelivered:  2,
  manifestoBroken:    -3,
};

// ── Event Registry ────────────────────────────────────────────────────────────
//
// Maps event names → handler method names.
// Adding a new civic action means: (a) add the name here, (b) add the method below.

const EVENT_HANDLERS = {
  "report.submit":             "onReportSubmit",
  "report.upvote":             "onReportUpvote",
  "project.create":            "onProjectCreate",
  "project.update":            "onProjectUpdate",
  "project.recompute":         "onProjectRecompute",
  "discussion.create":         "onDiscussionCreate",
  "discussion.entry.add":      "onDiscussionEntryAdd",
  "discussion.status_change":  "onDiscussionStatusChange",
  "election.phase_change":     "onElectionPhaseChange",
  "election.cycle.activate":   "onElectionCycleActivate",
  "manifesto.promise.create":  "onManifestoPromiseCreate",
  "manifesto.promise.update":  "onManifestoPromiseUpdate",
  "oversight.publish":         "onOversightPublish",
  "media.upload":              "onMediaUpload",
  "user.role_change":          "onUserRoleChange",
};

// ── Helpers ───────────────────────────────────────────────────────────────────

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

/**
 * Run both Verification + Corruption engines on a project, persist the
 * results, and return the computed outcome.
 *
 * This is the ONLY place these engines are invoked — routes delegate here
 * instead of calling them directly so we never run half an update.
 */
async function runProjectEngines(prisma, projectId) {
  const project = await prisma.project.findUnique({
    where:   { id: projectId },
    include: {
      reports: {
        orderBy: { createdAt: "desc" },
        // Weight each report by the reporter's trust at submit time
        select: {
          content:             true,
          reporterTrustWeight: true,
          upvotes:             true,
          userId:              true,
        },
      },
    },
  });
  if (!project) return null;

  // Enforce governance rule: verification only meaningful above thresholds
  const totalReports = project.reports.length;
  const weightedReports = project.reports.map((r) => ({
    ...r,
    // Inject effective weight so engines can use it (currently engines use content only;
    // this readies the data contract for when they adopt weighted scoring)
    _weight: clamp((r.reporterTrustWeight ?? 50) / 100 + (r.upvotes ?? 0) * 0.02, 0.1, 2.0),
  }));

  const { status, score, breakdown }  = computeVerification(weightedReports);
  const { riskLevel, flags, flagCount } = computeCorruptionRisk(weightedReports);

  // Apply governance minimums — prevent a single report from marking verified/disputed
  let effectiveStatus = status;
  if (status === "verified"  && totalReports < MIN_REPORTS_FOR_VERIFIED) effectiveStatus = "partial";
  if (status === "disputed"  && totalReports < MIN_REPORTS_FOR_DISPUTED) effectiveStatus = "partial";

  await prisma.project.update({
    where: { id: projectId },
    data:  {
      verificationStatus:  effectiveStatus,
      verificationScore:   score,
      lastVerifiedAt:      new Date(),
      corruptionRiskLevel: riskLevel,
      corruptionFlags:     JSON.stringify(flags),
      lastCorruptionCheck: new Date(),
    },
  });

  return { effectiveStatus, score, breakdown, riskLevel, flags, flagCount };
}

/**
 * Recompute a leader's accountability score from their full project portfolio
 * and any manifesto promises.  Written back to User.accountabilityScore.
 */
async function recomputeAccountabilityScore(prisma, leaderId) {
  const [projects, promises] = await Promise.all([
    prisma.project.findMany({
      where:  { createdBy: leaderId },
      select: { verificationStatus: true, corruptionRiskLevel: true, corruptionFlags: true },
    }),
    prisma.manifestoPromise
      ? prisma.manifestoPromise.findMany({
          where:  { leaderId },
          select: { status: true },
        }).catch(() => [])
      : Promise.resolve([]),
  ]);

  let score = 0;

  for (const p of projects) {
    if (p.verificationStatus === "verified")  score += ACC_SCORE_WEIGHTS.verifiedProjects;
    if (p.verificationStatus === "partial")   score += ACC_SCORE_WEIGHTS.ongoingProjects;
    if (p.verificationStatus === "disputed")  score += ACC_SCORE_WEIGHTS.disputedProjects;
    if (p.verificationStatus === "unverified") score += ACC_SCORE_WEIGHTS.plannedProjects;

    // Each unique corruption flag category costs points
    const flags = p.corruptionFlags ? JSON.parse(p.corruptionFlags) : [];
    score += flags.length * ACC_SCORE_WEIGHTS.corruptionFlags;
  }

  for (const pr of promises) {
    if (pr.status === "delivered")           score += ACC_SCORE_WEIGHTS.manifestoDelivered;
    if (pr.status === "broken")              score += ACC_SCORE_WEIGHTS.manifestoBroken;
  }

  // Normalise to 0–100 range (raw score can go negative)
  const normalised = Math.round(clamp(50 + score * 2, 0, 100));

  await prisma.user.update({
    where: { id: leaderId },
    data:  { accountabilityScore: normalised },
  }).catch(() => {}); // non-fatal if user doesn't exist (edge case during seeding)

  return normalised;
}

// ── Core Class ────────────────────────────────────────────────────────────────

class SautiCore {
  /**
   * Emit a civic event.
   *
   * @param {string} event   — one of the keys in EVENT_HANDLERS
   * @param {object} payload — arbitrary context; see each handler for what it reads
   * @returns {Promise<object>}  result object (handler-specific) or {} on failure
   */
  async emit(event, payload = {}) {
    const handlerName = EVENT_HANDLERS[event];
    if (!handlerName) {
      console.warn(`[SautiCore] Unknown event "${event}" — no handler registered`);
      return {};
    }

    try {
      const result = await this[handlerName](payload);
      return result ?? {};
    } catch (err) {
      console.error(`[SautiCore] Handler ${handlerName} failed for event "${event}":`, err.message);
      // Never propagate — side effects must not break HTTP responses
      return { _error: err.message };
    }
  }

  // ── HANDLER: report.submit ─────────────────────────────────────────────────
  //
  // Fires when a citizen submits a new report.
  // Triggers: verification engine, corruption engine, trust score update,
  //           corruption audit log if risk detected, accountability score refresh.
  //
  async onReportSubmit({ prisma, report, userId, projectId, channel = "web" }) {
    const results = {};

    // Always increment reporter's report count (already done in route for web;
    // re-running here via upsert-style increment is idempotent through the flag below)

    if (projectId) {
      const engineResult = await runProjectEngines(prisma, projectId);
      if (!engineResult) return results;

      results.verification = {
        status: engineResult.effectiveStatus,
        score:  engineResult.score,
      };
      results.corruption = {
        riskLevel:  engineResult.riskLevel,
        flagCount:  engineResult.flagCount,
      };

      // Corruption audit event
      if (engineResult.riskLevel !== "none") {
        await logAction(prisma, {
          action:     "corruption.flagged",
          entityType: "Project",
          entityId:   projectId,
          userId,
          channel,
          meta: {
            riskLevel:    engineResult.riskLevel,
            flags:        engineResult.flags,
            triggeredBy:  "report.submit",
            reportCount:  engineResult.breakdown?.total,
          },
        });
        results.corruptionFlagged = true;
      }

      // Trust score feedback — reporter's accuracy influences their future weight
      await this._adjustTrustFromVerification(prisma, userId, engineResult.effectiveStatus);

      // Refresh the project owner's accountability score
      const project = await prisma.project.findUnique({
        where:  { id: projectId },
        select: { createdBy: true },
      });
      if (project?.createdBy) {
        results.accountabilityScore = await recomputeAccountabilityScore(prisma, project.createdBy);
      }
    }

    return results;
  }

  // ── HANDLER: report.upvote ─────────────────────────────────────────────────
  //
  // Community verification: upvoting a report nudges the reporter's trust score
  // and re-runs engines so the new weight is reflected.
  //
  async onReportUpvote({ prisma, report }) {
    const results = {};

    // Trust nudge for the report's original author
    if (report.userId) {
      const reporter = await prisma.user.findUnique({
        where:  { id: report.userId },
        select: { trustScore: true },
      });
      if (reporter) {
        const newScore = clamp((reporter.trustScore ?? 50) + TRUST_UPVOTE_INCREMENT, TRUST_FLOOR, TRUST_CAP);
        await prisma.user.update({
          where: { id: report.userId },
          data:  { trustScore: newScore },
        });
        results.newTrustScore = newScore;
      }
    }

    // Re-run engines so the upvote's weight bump propagates
    if (report.projectId) {
      const engineResult = await runProjectEngines(prisma, report.projectId);
      if (engineResult) {
        results.verification = { status: engineResult.effectiveStatus, score: engineResult.score };
      }
    }

    return results;
  }

  // ── HANDLER: project.create ────────────────────────────────────────────────
  //
  // Audit and initialise accountability score when a leader creates a project.
  //
  async onProjectCreate({ prisma, project, userId }) {
    // Initialise verification fields to a clean state
    await prisma.project.update({
      where: { id: project.id },
      data:  {
        verificationStatus:  "unverified",
        verificationScore:   0,
        corruptionRiskLevel: "none",
      },
    }).catch(() => {});

    const accountabilityScore = await recomputeAccountabilityScore(prisma, userId);
    return { accountabilityScore };
  }

  // ── HANDLER: project.update ────────────────────────────────────────────────
  //
  // When a leader updates a project (status, budget, etc.) re-run engines and
  // refresh accountability score.
  //
  async onProjectUpdate({ prisma, projectId, updatedBy }) {
    const engineResult = await runProjectEngines(prisma, projectId);
    const project = await prisma.project.findUnique({
      where:  { id: projectId },
      select: { createdBy: true },
    });
    const ownerId = project?.createdBy ?? updatedBy;
    const accountabilityScore = await recomputeAccountabilityScore(prisma, ownerId);
    return { engineResult, accountabilityScore };
  }

  // ── HANDLER: project.recompute ────────────────────────────────────────────
  //
  // Manual re-run (e.g. POST /projects/:id/recompute-verification).
  //
  async onProjectRecompute({ prisma, projectId, requestedBy }) {
    const engineResult = await runProjectEngines(prisma, projectId);
    await logAction(prisma, {
      action:     "project.recompute",
      entityType: "Project",
      entityId:   projectId,
      userId:     requestedBy,
      meta:       engineResult ?? {},
    });
    return engineResult ?? {};
  }

  // ── HANDLER: discussion.create ────────────────────────────────────────────
  //
  // Governance rule: a leader cannot create a live town hall during the
  // "polling" phase of an active election (to prevent electioneering).
  // Async forum threads are always allowed.
  //
  async onDiscussionCreate({ prisma, discussion, userId }) {
    if (discussion.mode === "live") {
      const activeCycle = await prisma.electionCycle
        .findFirst({ where: { activeFlag: true } })
        .catch(() => null);

      if (activeCycle?.phase === "polling") {
        // Return a structured rule violation — the route layer should check this
        return {
          ruleViolation: true,
          rule:          "NO_TOWNHALLS_DURING_POLLING",
          message:       `Town halls are suspended during the polling phase of "${activeCycle.name}".`,
        };
      }
    }

    await logAction(prisma, {
      action:     discussion.mode === "async" ? "discussion.forum.create" : "discussion.townhall.create",
      entityType: "DiscussionThread",
      entityId:   String(discussion._id),
      userId,
      meta:       { mode: discussion.mode, title: discussion.title },
    });

    return { ruleViolation: false };
  }

  // ── HANDLER: discussion.entry.add ─────────────────────────────────────────
  //
  // Log when a citizen contributes to a discussion. If the discussion is linked
  // to a project, bump that project's "engagement" signal in the audit trail.
  //
  async onDiscussionEntryAdd({ prisma, discussion, entry, userId }) {
    await logAction(prisma, {
      action:     `discussion.entry.${entry.kind}`,
      entityType: "DiscussionThread",
      entityId:   String(discussion._id),
      userId,
      meta:       {
        kind:      entry.kind,
        mode:      discussion.mode,
        projectId: discussion.projectId ?? null,
      },
    });
    return {};
  }

  // ── HANDLER: discussion.status_change ─────────────────────────────────────
  async onDiscussionStatusChange({ prisma, discussion, newStatus, userId }) {
    await logAction(prisma, {
      action:     "discussion.status_change",
      entityType: "DiscussionThread",
      entityId:   String(discussion._id),
      userId,
      meta:       { mode: discussion.mode, status: newStatus },
    });
    return {};
  }

  // ── HANDLER: election.phase_change ────────────────────────────────────────
  //
  // When an election moves into a new phase:
  //   - "polling"       → lock all live town halls (set scheduled ones to cancelled)
  //   - "post_election" → trigger a full intelligence refresh signal
  //   - "transition"    → deactivate cycle (admin should also do this manually)
  //
  async onElectionPhaseChange({ prisma, cycle, newPhase, adminId }) {
    const results = { phase: newPhase };

    if (newPhase === "polling") {
      // Soft-lock: cancel any town halls scheduled during polling window
      // (We can't write to Mongo from here cleanly without importing mongoose,
      //  so we emit a structured advisory the route layer can act on.)
      results.advisory = {
        action:  "CANCEL_SCHEDULED_TOWNHALLS",
        reason:  "Polling phase active — town halls suspended to prevent electioneering",
        cycleId: cycle.id,
      };
    }

    if (newPhase === "post_election") {
      results.advisory = {
        action:  "TRIGGER_INTELLIGENCE_REFRESH",
        reason:  "Post-election: all project performance data should be surfaced for accountability review",
        cycleId: cycle.id,
      };
    }

    await logAction(prisma, {
      action:     "election.phase_change",
      entityType: "ElectionCycle",
      entityId:   cycle.id,
      userId:     adminId,
      meta:       { from: cycle.phase, to: newPhase },
    });

    return results;
  }

  // ── HANDLER: election.cycle.activate ──────────────────────────────────────
  //
  // Governance rule: only ONE cycle may be active at a time.
  // The Core enforces this even if the route layer's check races.
  //
  async onElectionCycleActivate({ prisma, cycleId, adminId }) {
    // Deactivate all other cycles atomically
    await prisma.electionCycle.updateMany({
      where: { id: { not: cycleId }, activeFlag: true },
      data:  { activeFlag: false },
    });

    await logAction(prisma, {
      action:     "election.cycle.activated",
      entityType: "ElectionCycle",
      entityId:   cycleId,
      userId:     adminId,
      meta:       { enforcedBy: "SautiCore" },
    });

    return { enforced: true };
  }

  // ── HANDLER: manifesto.promise.create ─────────────────────────────────────
  //
  // Governance rule: promises may only be created during an active election cycle.
  //
  async onManifestoPromiseCreate({ prisma, promise, leaderId }) {
    const activeCycle = await prisma.electionCycle
      .findFirst({ where: { activeFlag: true } })
      .catch(() => null);

    if (!activeCycle) {
      return {
        ruleViolation: true,
        rule:          "NO_ACTIVE_ELECTION_CYCLE",
        message:       "Manifesto promises can only be created during an active election cycle.",
      };
    }

    await logAction(prisma, {
      action:     "manifesto.promise.create",
      entityType: "ManifestoPromise",
      entityId:   promise.id,
      userId:     leaderId,
      meta:       { cycleId: activeCycle.id, category: promise.category },
    });

    return { ruleViolation: false, cycleId: activeCycle.id };
  }

  // ── HANDLER: manifesto.promise.update ─────────────────────────────────────
  //
  // When a promise status changes (e.g. delivered / broken), update the
  // linked project's delivery score and refresh the leader's accountability.
  //
  async onManifestoPromiseUpdate({ prisma, promise, leaderId, newStatus }) {
    const results = {};

    // If there is a linked project, mirror the delivery state
    if (promise.linkedProjectId && newStatus === "delivered") {
      const project = await prisma.project.findUnique({
        where:  { id: promise.linkedProjectId },
        select: { verificationScore: true },
      });
      if (project) {
        await prisma.manifestoPromise.update({
          where: { id: promise.id },
          data:  { deliveryScore: project.verificationScore },
        }).catch(() => {});
      }
    }

    results.accountabilityScore = await recomputeAccountabilityScore(prisma, leaderId);

    await logAction(prisma, {
      action:     "manifesto.promise.status_change",
      entityType: "ManifestoPromise",
      entityId:   promise.id,
      userId:     leaderId,
      meta:       { status: newStatus, linkedProjectId: promise.linkedProjectId },
    });

    return results;
  }

  // ── HANDLER: oversight.publish ────────────────────────────────────────────
  //
  // When an election stakeholder publishes an oversight report, stamp it with
  // the active election cycle and log to audit trail.
  //
  async onOversightPublish({ prisma, report, publishedBy }) {
    const activeCycle = await prisma.electionCycle
      .findFirst({ where: { activeFlag: true } })
      .catch(() => null);

    if (activeCycle && !report.electionCycleId) {
      await prisma.oversightReport.update({
        where: { id: report.id },
        data:  { electionCycleId: activeCycle.id },
      }).catch(() => {});
    }

    await logAction(prisma, {
      action:     "oversight.report.published",
      entityType: "OversightReport",
      entityId:   report.id,
      userId:     publishedBy,
      meta:       { cycleId: activeCycle?.id ?? null, region: report.region },
    });

    return { linkedCycleId: activeCycle?.id ?? null };
  }

  // ── HANDLER: media.upload ─────────────────────────────────────────────────
  //
  // Media uploads linked to corruption-flagged projects get an escalated
  // moderation status instead of the default "pending".
  //
  async onMediaUpload({ prisma, media, uploadedBy }) {
    if (media.projectId) {
      const project = await prisma.project.findUnique({
        where:  { id: media.projectId },
        select: { corruptionRiskLevel: true },
      });
      if (project && ["high", "critical"].includes(project.corruptionRiskLevel)) {
        // Escalate to priority review (still pending, but flagged in meta)
        await logAction(prisma, {
          action:     "media.priority_review",
          entityType: "MediaEvidence",
          entityId:   media.id,
          userId:     uploadedBy,
          meta:       {
            reason:             "Project has high/critical corruption risk",
            corruptionRiskLevel: project.corruptionRiskLevel,
          },
        });
        return { priorityReview: true };
      }
    }

    return { priorityReview: false };
  }

  // ── HANDLER: user.role_change ─────────────────────────────────────────────
  //
  // Role promotions / demotions are always audit-logged.
  // A citizen promoted to leader gets an initial accountability score of 50.
  //
  async onUserRoleChange({ prisma, targetUserId, fromRole, toRole, changedBy }) {
    if (toRole === "leader" && fromRole !== "leader") {
      await prisma.user.update({
        where: { id: targetUserId },
        data:  { accountabilityScore: 50 },
      }).catch(() => {});
    }

    await logAction(prisma, {
      action:     "user.role_change",
      entityType: "User",
      entityId:   targetUserId,
      userId:     changedBy,
      meta:       { from: fromRole, to: toRole },
    });

    return {};
  }

  // ── Internal helpers ───────────────────────────────────────────────────────

  async _adjustTrustFromVerification(prisma, userId, verificationStatus) {
    if (!userId) return;
    const user = await prisma.user.findUnique({
      where:  { id: userId },
      select: { trustScore: true },
    }).catch(() => null);
    if (!user) return;

    let delta = 0;
    if (verificationStatus === "verified")  delta = +TRUST_VERIFIED_INCREMENT;
    if (verificationStatus === "disputed")  delta = -TRUST_DISPUTED_DECREMENT;
    if (delta === 0) return;

    const newScore = clamp((user.trustScore ?? 50) + delta, TRUST_FLOOR, TRUST_CAP);
    await prisma.user.update({
      where: { id: userId },
      data:  { trustScore: newScore },
    }).catch(() => {});
  }
}

// ── Singleton export ──────────────────────────────────────────────────────────
//
// The Core is stateless (all state lives in Prisma / Mongo).
// A single instance is fine — there's no per-request state to worry about.

const core = new SautiCore();

module.exports = core;
module.exports.runProjectEngines        = runProjectEngines;        // for tests
module.exports.recomputeAccountability  = recomputeAccountabilityScore; // for tests
module.exports.EVENT_HANDLERS           = EVENT_HANDLERS;           // registry introspection
