const mongoose = require("mongoose");

let connected = false;

async function connectMongo() {
  if (connected) return;

  const uri = process.env.MONGO_URL || "mongodb://localhost:27017/sauti_forum";

  await mongoose.connect(uri);
  connected = true;
  console.log("MongoDB connected (forum + town hall engine)");
}

module.exports = { connectMongo };
